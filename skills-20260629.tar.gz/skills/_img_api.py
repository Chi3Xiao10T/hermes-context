import json, urllib.request, base64, re, sys, io

# Read key from key file
with open(r'C:\Users\Administrator\AppData\Local\hermes\profiles\construction\skills\.img_key', 'r') as f:
    api_key = f.read().strip()

BASE = "https://yibuapi.com/v1"

def edit_image(img_path, prompt):
    with open(img_path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode()
    
    payload = {
        "model": "gpt-image-2",
        "messages": [{"role": "user", "content": [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}
        ]}],
        "n": 1
    }
    
    req = urllib.request.Request(f"{BASE}/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"})
    
    resp = urllib.request.urlopen(req, timeout=120)
    return json.loads(resp.read())

def save_img(result, out_path):
    choices = result.get('choices', [])
    if not choices:
        return None
    
    msg = choices[0].get('message', {})
    content = msg.get('content', '')
    
    # Try URL
    urls = re.findall(r'https?://[^\s"\']+\.(?:png|jpg|jpeg|webp)', content)
    if urls:
        urllib.request.urlretrieve(urls[0], out_path)
        return f"URL: {urls[0][:80]}"
    
    # Try b64
    m = re.search(r'data:image/[^;]+;base64,([^"\'\s]+)', content)
    if m:
        with open(out_path, 'wb') as f:
            f.write(base64.b64decode(m.group(1)))
        return "base64"
    
    # Direct URL content
    if content and (content.startswith('http://') or content.startswith('https://')):
        urllib.request.urlretrieve(content, out_path)
        return "direct"
    
    return f"unknown: {content[:200]}"

# Read command from stdin
cmd = sys.stdin.read().strip()
parts = cmd.split('|')
if parts[0] == 'edit' and len(parts) >= 4:
    inp, out, prompt = parts[1], parts[2], parts[3]
    r = edit_image(inp, prompt)
    info = save_img(r, out)
    print(f"SAVED:{out}|{info}")
elif parts[0] == 'gen' and len(parts) >= 3:
    out, prompt = parts[1], parts[2]
    payload = {
        "model": "gpt-image-2",
        "messages": [{"role": "user", "content": prompt}],
        "n": 1
    }
    req = urllib.request.Request(f"{BASE}/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"})
    resp = urllib.request.urlopen(req, timeout=120)
    r = json.loads(resp.read())
    info = save_img(r, out)
    print(f"SAVED:{out}|{info}")
else:
    print(f"BAD CMD: {cmd[:100]}")
