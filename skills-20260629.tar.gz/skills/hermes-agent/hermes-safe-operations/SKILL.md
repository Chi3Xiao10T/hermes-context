---
name: hermes-safe-operations
description: 操作 Hermes Agent 自身时的安全规则和风险清单——修改配置、升级、恢复、调试时，保护正在运行的 Hermes 不受影响
version: 1.4.0
metadata:
  hermes:
    tags: [safety, hermes, ops, config]
    category: hermes-agent
---

# 安全操作 Hermes Agent

> 第一优先级：**正在运行的 Hermes 不能受到任何影响。**

## 核心原则

1. **先评估再动手** — 任何操作前先问："这个会不会影响正在跑的 Hermes？"会就不干，或者先告诉用户
2. **不在生产环境中测试** — 测试性的操作先在隔离环境做
3. **不改正在用的配置文件** — 改 config.yaml 前先备份，或者在非生产环境测试
4. **不在不稳定的上下文中执行配置变更** — 尤其是 `curl | bash`、恢复脚本、容器初始化等环境
5. **主动关联已有知识** — 用户提到任何配置项、工具、操作流程时，不等对方提醒，**立即主动检查记忆/wiki/技能**中的相关知识，直接给出答案。不要等人说"你之前记过的那个"才去翻。触发词包括但不限于：Token/配置/恢复/备份/代理/端口/Key/价格/模型/QQ/Clash/GitHub/MEGA/中文化/皮肤/技能/cron/bash/Python/脚本/脱敏/看图/生图/TTS/搜索

### 🟢 安装 MCP 服务器

**前置条件：** 确保 `mcp` Python 包已装在 Hermes venv 中
```bash
/root/.hermes/hermes-agent/venv/bin/pip install mcp
```

**做法：**
1. 在 `config.yaml` 的 `mcp_servers` 下添加配置
2. **必须重启网关才能生效**
3. 重启后验证：在新的会话中检查工具列表是否出现 `mcp_*` 前缀的工具

**常见 MCP 服务器配置示例：**
```yaml
mcp_servers:
  sequential-thinking:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-sequential-thinking"]
    timeout: 180
```

**注意事项：**
- MCP 工具名前缀为 `mcp_{服务器名}_{工具名}`，下划线替代连字符
- 每个 MCP 服务器默认 120 秒超时，可单独设置
- 连接断开自动重试（最多 5 次，指数退避）
- 工具注入所有平台（CLI、QQ Bot、Telegram 等）
- 禁止写入含 token/密钥的脚本到文件系统，参见 `references/token-handling.md`

## 高危操作清单

### 🟢 操作 Hermes 插件系统

**风险：** 写坏的插件会让 Hermes 在启动时报错，但不会导致崩溃（每个插件有独立 try/except）。

**安装插件步骤：**

1. **创建插件目录** — `~/.hermes/plugins/<插件名>/`
2. **写 plugin.yaml** — 元数据 + 钩子声明：
   ```yaml
   name: my-plugin
   version: 1.0.0
   description: "..."
   hooks:
     - pre_llm_call
     - on_session_start
     - on_session_end
   ```
3. **写 `__init__.py`** — 实现钩子函数 + `register()` 入口：
   ```python
   def register(plugin_manager):
       plugin_manager.register_hook("pre_llm_call", on_pre_llm_call)
   ```
4. **启用插件** — 在 `config.yaml` 中添加：
   ```yaml
   plugins:
     enabled:
       - my-plugin
   ```
   **注意：** 直接用 `hermes config set plugins.enabled '["my-plugin"]'` 会写成字符串而非列表。正确做法是通过 Python yaml.dump 手动写入。
5. **重启网关生效** — 见下方重启方法。

**可用钩子（VALID_HOOKS）：**

| 钩子 | 触发时机 | 返回值作用 |
|------|----------|-----------|
| `pre_llm_call` | 每次 LLM 调用前 | 返回 `{"context": "文本"}` 注入用户消息 |
| `post_llm_call` | LLM 调用后 | — |
| `pre_tool_call` | 工具执行前 | 返回可阻断工具 |
| `post_tool_call` | 工具执行后 | — |
| `on_session_start` | 会话开始时 | — |
| `on_session_end` | 会话结束时 | — |
| `pre_gateway_dispatch` | 网关收到消息分发前 | `{"action": "skip"/"rewrite"/"allow"}` |
| `pre_approval_request` | 审批弹框前 | 观察者，不可阻断 |
| `post_approval_response` | 审批响应后 | 观察者 |
| `transform_llm_output` | LLM 输出返回用户前 | 返回替换文本 |

**`pre_llm_call` 返回值格式：**
```python
def on_pre_llm_call(**kwargs) -> Optional[Dict[str, str]]:
    messages = kwargs.get("messages", [])
    # 提取最后一条用户消息
    for msg in reversed(messages):
        if msg.get("role") == "user":
            user_msg = msg.get("content", "")
    # 返回 context 注入到用户消息（不修改 system prompt，保持 prompt cache）
    return {"context": "相关记忆文本..."}
```

**插件日志查看：**
```bash
grep "plugin\|插件名" ~/.hermes/logs/agent.log
```

**注意事项：**
- context 注入 user message 而非 system prompt（保持 prompt cache）
- 插件异常不会导致主进程崩溃（每个回调有独立 try/except）
- 插件目录有两处：`~/.hermes/hermes-agent/plugins/`（内建）和 `~/.hermes/plugins/`（用户安装）
- 修改插件代码后必须重启网关才能生效
- 语法检查：`python3 -c "import py_compile; py_compile.compile('<path>/__init__.py', doraise=True)"`

### 🟢 重启网关（配完后让用户无感重启）

**风险：** 重启期间 QQ Bot/其他平台离线 20-30 秒，但会自动重连。

**安全做法：** 配置完成后，用延迟重启让用户无感：

**方法一（推荐，systemd 服务时可用）：** `systemctl --user restart hermes-gateway`

**方法二（`at` 命令，通用）：** 网关以裸进程运行时（非 systemd），先用 `ps aux | grep "hermes.*gateway"` 找到 PID，再用 `at` 调度延迟重启：
```bash
# 先找到网关 PID
PID=$(ps aux | grep "hermes.*gateway.*run" | grep -v grep | awk '{print $2}')
echo "PID=$PID"

# 调度 1 分钟后重启（脱离当前 session）
echo "sleep 5 && kill $PID && sleep 3 && nohup hermes gateway run --replace > /dev/null 2>&1 &" | at now + 1 minute
```
⚠️ 注意：`at` 方案需要 `apt-get install -y at`（如果没装），且 `atd` 服务在运行。

**方法三（kill + 用户手动启动）：** 提醒用户在 Termius 上 `kill <PID> && hermes gateway run --replace`。仅在上述两法均不可行时使用。

**不需手动重启的场景：** 改 `config.yaml` 的 `mcp_servers`、`.env` 的 API key、皮肤文件 → 都需要重启才能生效。

### 🟢 持久化切换模型（推荐方案，替换手动改 config.yaml）

**比手动编辑 config.yaml 安全得多，零风险。**

新版行为（已修改源码）：`/model` **任何切换都会自动写回 config.yaml**，不需要加 `--global`。关掉重开，还是上次用的模型。

```
/model deepseek-v4-flash              # 切模型 + 自动写死到 config.yaml
/model claude-opus-4-8-thinking        # 再切回来也自动写死
```

效果：当前会话立即切换，同时更新 `config.yaml` 的 `model.default` 和 `model.provider`。下次打开会话，看到的还是上次用的模型。

**修改位置：** `cli.py` 两处 `/model` 处理，去掉了 `if persist_global:` 条件判断。详细改动见 `references/source-mod-persistence.md`。

**⚠️ 注意：** 这是自定义源码修改！`hermes update`（git pull）可能覆盖。有 post-merge hook 自动恢复，详见"修改Hermes源码"章节。

### 🔴 修改 config.yaml

**风险：** 写坏配置导致 Hermes 无法启动

- `hermes config set` 在标准 CLI 环境下安全
- **强烈建议优先用 `/model <name> --global` 来切换默认模型**，比手动改 config.yaml 安全且不易出错
- 在 `curl | bash`、恢复脚本（restore-hermes.sh）、后台进程、非标准 shell 中 **禁止** 执行 `hermes config set` — 可能写坏 yaml
- 改 `display.skin`、`providers`、`model` 等关键字段尤其危险
- 修改后验证：`hermes config show | grep <changed_field>`

#### 安全修改 config.yaml 标准流程（避坑版）

**背景：** Hermes 的 read_file/write_file/patch 工具会对输出中的 `sk-xxx` 格式字符串自动脱敏（替换为 `sk-xxx...xxx`），导致写入时覆盖原始 Key，所有 provider 密钥失效。

**正确步骤（用 Python 操作，绕过脱敏）：**

```python
import yaml, os

config_path = os.path.expanduser("~/.hermes/config.yaml")

# 1. 读配置
with open(config_path, 'r', encoding='utf-8') as f:
    config = yaml.safe_load(f)

# 2. 改数据（Python 字典操作，不碰字符串匹配）
for p in config.get('custom_providers', []):
    if p.get('name') == 'lingshu':
        if 'api_mode' in p:
            del p['api_mode']  # 示例：删掉 api_mode

config['model']['provider'] = 'lingshu-cc'
config['model']['default'] = 'claude-opus-4-8'

# 3. 写回（用 yaml.dump，不走 write_file/patch）
with open(config_path, 'w', encoding='utf-8') as f:
    yaml.dump(config, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

# 4. 验证
with open(config_path, 'r', encoding='utf-8') as f:
    verified = f.read()
print(f"api_mode 残留: {'api_mode' in verified}")   # 应 False
print(f"provider: {'provider: lingshu-cc' in verified}")  # 应 True
```

**如果 Key 已损坏**（配置文件中被脱敏覆盖了），从 CC-Switch DB 恢复：

```python
import json, sqlite3

db = sqlite3.connect(os.path.expanduser("~/.cc-switch/cc-switch.db"))
cursor = db.cursor()
cursor.execute("SELECT settings_config FROM providers WHERE id='lingshu'")
real_key = json.loads(cursor.fetchone()[0])['api_key']
db.close()

# 然后在 yaml.safe_load 后的 dict 里直接设 api_key:
for p in config.get('custom_providers', []):
    if p.get('name') == 'lingshu-cc':
        p['api_key'] = real_key
```

**禁止的操作：**
- ❌ `patch(file, old_string=..., new_string=...)` 改 config.yaml — Key 会被脱敏
- ❌ `write_file` 写 config.yaml — 同上
- ❌ `sed -i` / `grep` 在 shell 中改 — 引号/转义易错

**只能用 Python `open()` + `yaml.dump()` 操作 config.yaml 文件。**

### 🔴 修改 Hermes 源码（cli.py 等）

**风险：** git pull（`hermes update`）会覆盖修改，导致自定义行为丢失

**安全修改流程：**

1. 改完必须语法检查：`python3 -m py_compile <file>`
2. 必须重启网关才能生效（如果涉及服务端代码）：`systemctl --user restart hermes-gateway`
3. 如果同时改了皮肤和 i18n 路径，检查 key 名是否匹配

**防止升级覆盖的两种方法：**

**方法一：post-merge hook（推荐，自动恢复）**
```bash
# 位置：.git/hooks/post-merge
# 每次 git pull 后运行，检查自定义修改是否被覆盖，如有则重新打补丁
```
具体实现：写一个独立 Python 脚本（如 `scripts/patch-xxx.py`）执行补丁逻辑，hook 只调用该脚本。避免在 bash hook 中嵌入复杂的 Python 代码导致转义问题。

**方法二：独立补丁脚本（手动恢复）**
```python
# scripts/patch-xxx.py
# 用 re.subn 替换两处（count=2）以确保 CLI 命令和交互式弹框两个入口都被覆盖
```
手动运行：`python scripts/patch-xxx.py`

**已知修改记录：**

| 修改 | 文件 | 补丁脚本 | 说明 |
|------|------|---------|------|
| /model 自动持久化 | cli.py (2处) | `scripts/patch-model-persist.py` | 去掉 persist_global 判断，任何 /model 都写 config |

### 🔴 升级/重装 Hermes

- 先 `hermes config show > /tmp/hermes-config-backup.yaml` 备份配置
- 升级脚本可能覆盖 `~/.hermes/config.yaml`，确保备份后再跑
- 升级后验证：`hermes --version` 和 `hermes gateway status`

### 🟡 操作 .env 文件

- 改 API key 后需 `hermes gateway restart` 才能生效
- 不要在 `curl | bash` 中写 .env
- hex 编码写入 token 后，在 shell 中解码验证

### 🟡 修改 cron 任务

- 改已有 cron 时先 `cronjob action='list'` 查看当前列表
- 不要猜测 job_id
- 新增 cron 时 self-contained，不要在 cron 脚本里依赖当前会话的变量

### 🟡 操作 filesystem（备份/恢复）

- 备份前检查磁盘空间：`df -h /`
- state.db 很大（可能几百 MB），压缩后再上传
- 恢复时先停网关再覆盖 state.db，否则数据库可能损坏

## 安全操作流程

### 改配置前三思：
```
1. 这个操作会影响正在运行的 Hermes 吗？ → 会→停，告诉用户
2. 有没有备份方案？ → 没有→先备份
3. 能在不重启的情况下验证吗？ → 不能→安排低峰期操作
```

### 安全修改四步法：
1. **备份** — `cp ~/.hermes/config.yaml ~/.hermes/config.yaml.bak`
2. **修改** — 用 `hermes config set`（标准环境）或直接写文件
3. **验证** — `hermes config show` 检查语法是否正确
4. **重启**（如需） — `systemctl --user restart hermes-gateway`，然后 `hermes gateway status` 确认恢复

### 🟢 Windows gateway 服务脚本恢复

**风险：低** — 重新安装网关服务，不影响任何持久数据。

**场景 A：** `hermes gateway start` 返回 `No gateway process detected`，但 Scheduled Task 存在且指向的 `.cmd` 文件已丢失/目录为空。

**原因：** `gateway-service/` 目录被清理或损坏，Hermes_Gateway.cmd 启动脚本丢失。

**修复：**
```bash
printf "Y\nY\n" | hermes gateway install
```

**场景 B：** Gateway 状态显示 `✓ Scheduled Task registered` + `✗ No gateway process detected`，QQbot 无响应也不报错。

**根因：** `gateway-service/Hermes_Gateway.cmd` 启动脚本误用了 `pythonw.exe -m hermes_cli.main`（GUI 程序）而非 `hermes.exe`（控制台程序）。Windows 计划任务对 GUI 程序（pythonw.exe）的进程生命周期监控有问题——认为 pythonw.exe 启动即完成，**死后不会自动触发重启**。导致 gateway 进程死后 QQbot 永久失联。

**检查：**
```bash
# 看 gateway.cmd 内容
cat %LOCALAPPDATA%/hermes/gateway-service/Hermes_Gateway.cmd
# 问题行：用 pythonw.exe → 死后不自动重启
# 正确行：用 hermes.exe → 计划任务可跟踪进程生命周期
```

**修复（手动修改 `.cmd` 文件）：**
```bash
# 把 pythonw.exe -m hermes_cli.main 改回 hermes.exe
# ❌ C:\\...\\venv\\Scripts\\pythonw.exe -m hermes_cli.main gateway run
# ✅ C:\\...\\venv\\Scripts\\hermes.exe gateway run
```
修改后重启 gateway：`powershell.exe -Command "Stop-ScheduledTask -TaskName 'Hermes_Gateway'"` 再 `powershell.exe -Command "Start-ScheduledTask -TaskName 'Hermes_Gateway'"`。

**验证 gateway 正常运行且崩溃后自动重启：**
```bash
hermes gateway status
# → ✓ Scheduled Task registered
# → ✓ Gateway process running (PID: ...)
# LastTaskResult 应为 0（正常运行）
powershell.exe -Command "Get-ScheduledTask -TaskName 'Hermes_Gateway' | Get-ScheduledTaskInfo | Format-List"
```

**原理：** 计划任务后台运行本身不弹窗口（没有交互式桌面），所以不需要 pythonw.exe。使用 `hermes.exe`（控制台程序）让 Windows 计划任务能正确跟踪进程生命周期，崩溃后按 RestartCount/RestartInterval 设置（999次/1分钟）自动重启。

这会重新创建：
1. `gateway-service/Hermes_Gateway.cmd` — 启动脚本
2. Windows Scheduled Task `Hermes_Gateway` — 登录自动启动
3. 立即启动网关进程

**验证：**
```bash
hermes gateway status
# → ✓ Scheduled Task registered
# → ✓ Gateway process running (PID: ...)

# 检查平台连接
grep "Connected\|Ready" %HERMES_HOME%/logs/gateway.log | tail -3
# → ✓ qqbot connected
# → Ready, session_id=...
```

**注意：** gateway 安装过程有交互提示，用 `printf "Y\nY\n"` 管道传入避免阻塞。启动后需几个呼吸等待 WebSocket 连接完成。

### QQ Bot 配对审批

当新用户第一次给 QQ Bot 发私聊时，机器人返回配对码要求所有者批准。

**批准命令：**
```bash
hermes pairing approve qqbot <配对码>
```

**验证输出：** `Approved! User ... on qqbot can now use the bot~`

配对后用户发下一条消息即可正常对话。

### 🟢 处理 agent 卡死/不响应（跨平台中断）

**风险：低** — 只是停掉网关，不影响任何持久数据。

**场景：** 用户在 QQ Bot 上跟 agent 说话，agent 正在跑一个长时间任务（下载模型、批量生成配音等），不响应新消息。用户切到 CLI 说"停一下你正在进行的任务"。

**用户预期：** 她认为 CLI 和 QQ Bot 是同一个 agent，CLI 应该知道 QQ Bot 上 agent 在干什么。但实际上它们是不共享上下文的**不同会话**。

**处理步骤：**

1. **先不要回复"没有任务在跑"** — 用户说的"任务"可能在另一个平台（QQ Bot）上。先查网关日志确认：
   ```bash
   grep "inbound message:\|C2C message" /root/.hermes/logs/gateway.log | tail -10
   ```
2. **理解卡死原因** — 看最后几条日志，agent 是不是在跑下载、批处理等长时间操作，且用户的后续消息（"停一下"、"你听到没"、"卧槽了"）都没有得到回复
3. **停止网关解除卡死：**
   - 先尝试 `hermes gateway restart` — 可能被 active agent 卡住，进入 draining 状态
   - 如果 draining 状态不退：`kill <PID>`（可能卡住变 draining）→ `kill -9 <PID>`（强制杀）
   - 验证：`hermes gateway status` 显示 "Gateway is not running"
4. **确认用户意图后操作** — 有的用户只想停掉卡住的任务，有的想重启网关让 QQ Bot 恢复上线。问清楚再动。

**关键要点：**
- 网关的 draining 状态表示有 active agent 正在处理，需要强制杀死（kill -9）才能越过
- 用户可能跨平台（QQ→CLI、Telegram→CLI、微信→CLI）来呼叫你停止另一个平台的 agent，不要只盯着当前会话的空闲状态回答
- 卡死的 agent 会把新消息排队但不回复（日志显示 "After processing: images=0, voice=0" 循环但不发内容）

## 已知陷阱

| 场景 | 问题 | 解决 |
|---|---|---|
| `curl \| bash` 中跑 `hermes config set` | 写坏 yaml | 不要在非标准环境执行配置修改 |
| 升级 Hermes | 覆盖自定义配置 | 升级前手动备份全量配置 |
| 写 .env 用 echo/vim | 引号处理不当 | 用 `write_file` 工具或 printf |
| 直接改 state.db | 数据库损坏 | 先停网关，再操作 |
| 改皮肤文件后不重启 | 配置不会生效 | 改完必重启网关 |
| 用 write_file/heredoc 写含 token 的脚本 | Hermes 自动脱敏（ghp_ 串替换为 ***），文件损坏 | 用 `execute_code` + Python `open()` 或 `subprocess.run(['tee', path], input=content.encode())` 写文件 |
| 用 patch/write_file 修改 config.yaml | Hermes 脱敏系统把 api_key 值替换为 sk-xxx...xxx（字面量 ...），导致所有 provider 密钥失效 | 禁止用 patch/write_file 改 config.yaml！正确做法：从 CC-Switch 备份恢复或用 terminal Python 从 CC-Switch DB 读真 Key 写配置 |
| gateway.cmd 用 pythonw.exe 而非 hermes.exe | 计划任务无法跟踪 GUI 程序进程生命周期，死后不自动重启，QQbot 永久失联 | 改 .cmd 为 `hermes.exe gateway run`（计划任务后台不弹窗），再 `Stop-ScheduledTask` + `Start-ScheduledTask` |
| 开新窗模型还是旧的 | 代码已原生支持 /model 自动持久化，但可能存在多个 config.yaml 以及 profile 级配置覆盖 | 诊断三步：① `cat %LOCALAPPDATA%/hermes/config.yaml \| grep -A 3 "^model:"` 看全局；② `cat ~/.hermes/config.yaml \| grep -A 3 "^model:"` 检查旧位置是否残留不一致；③ **如果用了 profile**，检查 `%LOCALAPPDATA%/hermes/profiles/<profile>/config.yaml` — profile 级配置优先覆盖全局，即使全局设为 claude，profile 里写了 deepseek 就还是 deepseek。修正：Python yaml 改 profile 级 config 的 model.default + model.provider |
| terminal 中 source .env 后变量被脱敏 | 脱敏的 `${VAR}` 导致 shell 语法错误 | 直接用脚本文件 `$(cat file)` 读取，或 Python 读 hex |
| **写脚本时引用 token 文件** | Hermes 脱敏系统自动把 `$(cat ~/.config/xxx)` 替换成 `***`，导致脚本语法错误 | 用 `execute_code` + `subprocess.run(['tee', path])` 写脚本；读 token 用 `xxd -p <file>` + Python decode |
| **从中国大陆 push 到 GitHub** | TLS 握手失败（直连），git clone 超时 | 走代理 `HTTP_PROXY=http://127.0.0.1:7897`；需先设 `git config --global user.email/name` |

## 参考文件

本技能附带以下参考文件，介绍技术细节和工作原理：

- `references/token-handling.md` — Token 读写脱敏陷阱及绕过方法
- `references/mcp-setup.md` — MCP 服务器安装、配置、重启及排查
- `references/source-mod-persistence.md` — cli.py 源码修改详情（/model 自动持久化）
- `references/profile-config-hierarchy.md` — Profile vs 全局配置层级关系及排查步骤
