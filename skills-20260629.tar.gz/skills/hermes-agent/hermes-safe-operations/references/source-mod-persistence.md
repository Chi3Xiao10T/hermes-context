# /model 自动持久化到 config.yaml

## 修改内容

去掉 `cli.py` 中 `/model` 切换模型的 `if persist_global:` 条件判断，使**任何 `/model` 操作都自动写回 config.yaml**。

## 修改位置（两处）

### 位置一：`_handle_model_command()` — 命令行 `/model <name>` 入口

**旧代码（~6796-6802）：**
```python
if persist_global:
    save_config_value("model.default", result.new_model)
    if result.provider_changed:
        save_config_value("model.provider", result.target_provider)
    _cprint("    Saved to config.yaml (--global)")
else:
    _cprint("    (session only — add --global to persist)")
```

**新代码：**
```python
# Persist to config.yaml so the model sticks across sessions
save_config_value("model.default", result.new_model)
if result.provider_changed:
    save_config_value("model.provider", result.target_provider)
```

### 位置二：`_handle_model_picker_selection()` — 交互式选模型弹框入口

**旧代码（~7056-7062）：**
```python
if persist_global:
    save_config_value("model.default", result.new_model)
    if result.provider_changed:
        save_config_value("model.provider", result.target_provider)
    _cprint("    Saved to config.yaml (--global)")
else:
    _cprint("    (session only — add --global to persist)")
```

**新代码：** 同上（去掉 if/else，总是保存）。

### docstring 更新

`_handle_model_command()` 的 docstring 中：
- 原：`/model <name> — switch for this session only` 和 `/model <name> --global — switch and persist to config.yaml`
- 改为：`/model <name> — switch model and persist to config.yaml`

## 升级保护

### post-merge hook

位置：`.git/hooks/post-merge`
内容：调用 `scripts/patch-model-persist.py` 检查并恢复补丁

### 补丁脚本

位置：`scripts/patch-model-persist.py`

原理：
1. 检查 cli.py 是否已包含 "Persist to config.yaml so the model sticks across sessions" 标记文本
2. 如有 → 跳过（已打好补丁）
3. 如无 → 用 re.subn 匹配旧模式并替换（count=2 覆盖两个入口）

```python
OLD_PATTERN = re.compile(
    r'''        if result\.warning_message:
            _cprint\(f"    ⚠ \{result\.warning_message\}"\)
        if persist_global:
            save_config_value\("model\.default", result\.new_model\)
            if result\.provider_changed:
                save_config_value\("model\.provider", result\.target_provider\)
            _cprint\("    Saved to config\.yaml \(--global\)"\)
        else:
            _cprint\("    \(session only — add --global to persist\)"\)'''
)
```

## 注意事项

- 保留 `--global` 参数解析代码（`parse_model_flags` 中仍有 `persist_global` 变量和 `--global` flag 解析），以避免外部调用者因缺少参数而出错。只是不再根据它做分支。
- 交互式弹框的 `_handle_model_picker_selection(self, persist_global: bool = False)` 的 `persist_global` 参数也保留，不影响调用方。

## 诊断：切换后新窗还是旧模型

如果用户反馈「我切了模型但新窗口还是旧模型」，按以下步骤排查：

### 1. 确认代码是否已原生支持

当前版本两处 `/model` 处理均已无条件调用 `save_config_value`（不依赖 `persist_global`）：
- `cli.py:6797-6800` — `_apply_model_switch_result()` 内
- `cli.py:7052-7055` — `_handle_model_switch()` 内

如果这两处有 `if persist_global:` 包裹，说明需要重新打补丁（见上文的补丁脚本章节）。

### 2. 检查双配置文件

Windows 下可能存在两个不同的 config.yaml：

| 路径 | 作用 | 大小 |
|------|------|------|
| `%LOCALAPPDATA%/hermes/config.yaml` | 真正的配置文件（HERMES_HOME 指向这里） | ~16KB |
| `~/.hermes/config.yaml` | 旧版残留文件，不被加载 | ~696B |

检查命令：
```
cat "%LOCALAPPDATA%/hermes/config.yaml" | grep -A 3 "^model:"
ls -la ~/.hermes/config.yaml 2>/dev/null && echo "旧文件存在（不影响运行）"
```

### 3. 验证写入

先 `/model` 切换一个模型，然后：
```
cat "%LOCALAPPDATA%/hermes/config.yaml" | grep "default:\|provider:"
```

如果已写入但不生效，检查：HERMES_HOME 环境变量是否正确、是否有 cron 任务覆盖 config.yaml、是否在使用 profile 功能。
