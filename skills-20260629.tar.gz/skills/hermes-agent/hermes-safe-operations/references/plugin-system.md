# Hermes 插件系统参考

## 插件结构

```
~/.hermes/plugins/<name>/
├── plugin.yaml      — 元数据、钩子声明
└── __init__.py      — 实现 + register() 入口
```

## plugin.yaml 格式

```yaml
name: my-plugin
version: 1.0.0
description: "说明文字"
hooks:
  - pre_llm_call
  - on_session_start
  - on_session_end
pip_dependencies:   # 可选：需 pip 安装的依赖
  - some-package
```

## __init__.py 模板

```python
"""插件说明"""
from __future__ import annotations
import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

def on_pre_llm_call(**kwargs) -> Optional[Dict[str, str]]:
    """每次 LLM 调用前触发。可返回 context 注入到用户消息。"""
    try:
        messages = kwargs.get("messages", [])
        # 提取用户最后一条消息
        last_user = None
        for msg in reversed(messages):
            if msg.get("role") == "user":
                last_user = msg.get("content", "")
                break
        if not last_user or len(last_user) < 3:
            return None
        # ... 处理逻辑 ...
        return {"context": "注入的上下文文本"}
    except Exception as exc:
        logger.warning("Plugin error: %s", exc)
        return None

def on_session_start(**kwargs) -> None:
    """会话开始时触发。"""
    pass

def on_session_end(**kwargs) -> None:
    """会话结束时触发。"""
    pass

def register(plugin_manager) -> None:
    """注册所有钩子。"""
    plugin_manager.register_hook("pre_llm_call", on_pre_llm_call)
    plugin_manager.register_hook("on_session_start", on_session_start)
    plugin_manager.register_hook("on_session_end", on_session_end)
    logger.info("MyPlugin registered")
```

## 启用插件

在 `config.yaml` 中添加：

```yaml
plugins:
  enabled:
    - my-plugin
```

⚠️ 不要用 `hermes config set plugins.enabled '["my-plugin"]'` — 会存成字符串而非列表。**正确方式：** 通过 Python yaml 库写入。

## Active Memory 插件参考实现

位置：`~/.hermes/plugins/active-memory/`
功能：模仿 OpenClaw Basic Memory，自动注入历史上下文

核心逻辑：
1. `pre_llm_call` — 提取用户消息关键词 → FTS5 搜索 state.db → 注入相关历史
2. `on_session_start` — 加载近 3 天对话日志
3. `on_session_end` — 将最后一条问答写入每日日志文件

## 日志查看

```bash
grep -i "myplugin\|你的插件名" ~/.hermes/logs/agent.log
```
