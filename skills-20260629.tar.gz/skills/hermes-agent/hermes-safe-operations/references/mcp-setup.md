# MCP 服务器安装配置参考

## 前置条件

```bash
# 确认 MCP 包已装
/root/.hermes/hermes-agent/venv/bin/pip install mcp

# 确认 Hermes 版本支持 MCP
hermes --version  # v0.15.1+ 均可
```

## 配置方法

编辑 `~/.hermes/config.yaml`，在顶层添加 `mcp_servers` 字段：

```yaml
mcp_servers:
  sequential-thinking:
    command: "npx"
    args: ["-y", "@modelcontextprotocol/server-sequential-thinking"]
    timeout: 180
```

## 重启生效

所有 MCP 服务器在网关启动时加载。修改后必须重启：

```python
# execute_code 中
from hermes_tools import terminal
terminal("apt-get install -y at 2>/dev/null; atd 2>/dev/null", timeout=30)
terminal("echo 'hermes gateway run --replace > /tmp/gateway-auto.log 2>&1' | at now + 1 minute")
# 1 分钟后自动重启，用户无需操作
```

## 验证方法

重启后在新的会话中检查工具列表是否包含 `mcp_*` 前缀的工具。

## 已知 MCP 服务器

| 服务器 | 命令 | 用途 |
|---|---|---|
| sequential-thinking | `npx -y @modelcontextprotocol/server-sequential-thinking` | 逐步推理，复杂问题分解 |
| 时间 | `uvx mcp-server-time` | 时区/时间查询 |
| Filesystem | `npx -y @modelcontextprotocol/server-filesystem /path` | 文件系统访问 |
| GitHub | `npx -y @modelcontextprotocol/server-github` | GitHub 仓库管理 |

## 安全注意事项

- MCP 子进程继承过滤后的环境变量（仅 PATH/HOME/USER/LANG 等，不含 API Key）
- 敏感密钥通过 `env` 字段单独传入
- 连接断开时自动重试，最多 5 次
