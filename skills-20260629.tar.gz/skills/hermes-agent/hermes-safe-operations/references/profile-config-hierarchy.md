# Hermes 配置层级：Profile vs Global

## 文件位置

| 层级 | 路径 | 备注 |
|------|------|------|
| 全局（真） | `%LOCALAPPDATA%/hermes/config.yaml` | 默认配置，CLI 无 profile 时读这个 |
| 旧位置（残留） | `~/.hermes/config.yaml` | 旧版 Hermes 用的位置，新版可能残留不一致 |
| Profile 级 | `%LOCALAPPDATA%/hermes/profiles/<profile>/config.yaml` | **优先级最高**，覆盖全局 |

## 生效规则

- 无 profile 启动 → 读全局 `%LOCALAPPDATA%/hermes/config.yaml`
- 带 profile 启动（如 `hermes chat --profile construction`）→ 读 profile 级 config
- **profile 级配置 ≠ 增量覆盖**，而是独立完整的 yaml 文件。profile 里写了什么 model，就用什么 model，完全不看全局
- `~/.hermes/config.yaml`（旧位置）已经是历史残留，新 Hermes 根本不读它

## 排查步骤

当用户说"我改了模型但重启窗口又回去了"：

```
1. 确认当前走哪个 profile（看 banner 或问用户）
2. 无 profile → 查 %LOCALAPPDATA%/hermes/config.yaml 的 model.default
3. 有 profile → 查 %LOCALAPPDATA%/hermes/profiles/<profile>/config.yaml
4. 再查 ~/.hermes/config.yaml 是否有旧的不一致
```

## 安全修改 profile config

与全局 config 同理 — 必须用 Python yaml 读-改-写，**禁止**用 `write_file` / `patch` 直接操作，否则 API key 会被脱敏系统破坏。

```python
import yaml
path = r"C:\Users\Administrator\AppData\Local\hermes\profiles\construction\config.yaml"
d = yaml.safe_load(open(path, encoding='utf-8'))
d['model']['default'] = 'claude-opus-4-8'
d['model']['provider'] = 'custom:lingshu'
with open(path, 'w', encoding='utf-8') as f:
    yaml.dump(d, f, default_flow_style=False, allow_unicode=True)
```
