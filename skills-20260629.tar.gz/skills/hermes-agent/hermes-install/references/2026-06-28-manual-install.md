# 2026-06-28 手动安装实录

> 环境：Windows 云机（2核4G GPU），中国网络  
> 最终成功路径：ghfast.top下载zip → uv venv → pip install -e

## 问题链与解法

| # | 遇到的问题 | 根因 | 解法 |
|---|-----------|------|------|
| 1 | 桌面安装器卡 "Cloning Hermes repository" | GitHub直连被墙 | 跳过桌面安装器 |
| 2 | gitclone.com 代理 403 | 代理已失效 | 换ghfast.top ✅ |
| 3 | ghproxy.com 不通 | 同上 | ghfast.top ✅ |
| 4 | install.ps1 不在源码仓库 | 该文件是CDN网站独有 | 跳过，走pip手动装 |
| 5 | winget 装Python失败 (0x80040154) | App Installer损坏 | 用bootstrap残留的uv.exe |
| 6 | uv pip --system 报 "externally managed" | uv托管Python禁止系统安装 | 创建独立venv |
| 7 | PowerShell $env路径报红 | 变量含反斜杠，PS解析失败 | 用 `& "..."` 语法 |
| 8 | hermes_bootstrap.py 跑了但没效果 | bootstrap只下载依赖不装本体 | 跳过它 |

## 最终成功命令序列

```powershell
# 0. 清理
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\hermes" -ErrorAction SilentlyContinue

# 1. 浏览器下载zip
# https://ghfast.top/https://github.com/nousresearch/hermes-agent/archive/refs/heads/main.zip

# 2. 解压到 hermes-agent 根目录（注意去掉外层 hermes-agent-main 文件夹）

# 3. 用uv装Python
& "$env:LOCALAPPDATA\hermes\bin\uv.exe" python install 3.11

# 4. 创建venv
& "$env:LOCALAPPDATA\hermes\bin\uv.exe" venv "$env:LOCALAPPDATA\hermes\hermes-agent\venv"

# 5. 装Hermes到venv
& "$env:LOCALAPPDATA\hermes\bin\uv.exe" pip install -e "$env:LOCALAPPDATA\hermes\hermes-agent" --python "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe"

# 6. 加PATH
[Environment]::SetEnvironmentVariable("Path", "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts;" + [Environment]::GetEnvironmentVariable("Path", "User"), "User")

# 7. 关掉重开终端 → hermes --version
```
