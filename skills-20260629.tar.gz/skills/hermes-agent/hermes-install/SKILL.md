---
name: hermes-install
description: Hermes Agent 安装指南，含中国网络环境下的备选方案
triggers:
  - 安装Hermes
  - hermes安装
  - 装Hermes
  - hermes install
---

# Hermes Agent 安装指南

## 主方案：一键安装（可能被墙）

```powershell
iex (irm https://hermes-agent.nousresearch.com/install.ps1)
```

## 备选1：走GitHub克隆

```powershell
git clone https://github.com/nousresearch/hermes-agent.git $env:LOCALAPPDATA\hermes\hermes-agent
cd $env:LOCALAPPDATA\hermes\hermes-agent
.\install.ps1
```

## 备选2：桌面安装器

浏览器打开 https://hermes-agent.nousresearch.com → 点 Download → 下exe直接装

## 备选3：GitHub Proxy下载zip + 手动安装（最稳，绕过所有网络问题）

### 步骤1：清理旧目录
```powershell
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\hermes" -ErrorAction SilentlyContinue
```

安装脚本失败后会把残留重命名为 `hermes-agent.broken-YYYYMMDD-HHMMSS`，也需要清理。

### 步骤2：通过GitHub代理下载zip
浏览器打开：
```
https://ghfast.top/https://github.com/nousresearch/hermes-agent/archive/refs/heads/main.zip
```
备用代理：`ghproxy.com`（相同格式）

### 步骤3：解压
```powershell
New-Item -ItemType Directory -Force -Path "$env:LOCALAPPDATA\hermes\hermes-agent"
Expand-Archive -Path "$env:USERPROFILE\Downloads\main.zip" -DestinationPath "$env:LOCALAPPDATA\hermes\hermes-agent-temp"
Get-ChildItem "$env:LOCALAPPDATA\hermes\hermes-agent-temp\*" | Move-Item -Destination "$env:LOCALAPPDATA\hermes\hermes-agent" -Force
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\hermes\hermes-agent-temp"
```

⚠️ **install.ps1 不在 GitHub 仓库里！** 它在 CDN 网站上，zip 里没有。不要浪费时间找它。

### 步骤4：确保有Python

**优先：winget安装**
```powershell
winget install Python.Python.3.11
```
装完关掉重开终端。

**winget挂了（0x80040154 / App Installer损坏）：用bootstrap残留的uv**

安装脚本的bootstrap阶段会在 `$env:LOCALAPPDATA\hermes\bin\` 留下 `uv.exe`，即使安装失败它也在：

```powershell
# 用uv装Python 3.11
& "$env:LOCALAPPDATA\hermes\bin\uv.exe" python install 3.11
```

### 步骤5：安装Hermes

**有pip时：**
```powershell
cd $env:LOCALAPPDATA\hermes\hermes-agent
pip install -e .
```

**pip不可用 / Python被uv托管阻止--system安装时：创建独立venv**
```powershell
# 创建虚拟环境
& "$env:LOCALAPPDATA\hermes\bin\uv.exe" venv "$env:LOCALAPPDATA\hermes\hermes-agent\venv"

# 在venv中安装
& "$env:LOCALAPPDATA\hermes\bin\uv.exe" pip install -e "$env:LOCALAPPDATA\hermes\hermes-agent" --python "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\python.exe"
```

### 步骤6：验证并加PATH
```powershell
# 验证安装
& "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts\hermes.exe" --version

# 加PATH（关掉重开终端生效）
[Environment]::SetEnvironmentVariable("Path", "$env:LOCALAPPDATA\hermes\hermes-agent\venv\Scripts;" + [Environment]::GetEnvironmentVariable("Path", "User"), "User")
```
关掉重开终端后直接用 `hermes --version` 验证。

### 步骤7：配置Hermes
```powershell
hermes setup
# 选 2 (Full setup — 配自己的API Key/QQ Bot)
# 不要选 1 (Quick Setup — 绑Nous模型，不是你的Key)
# 不要选 3 (Blank Slate — 什么都没有)
```

### 步骤8：配QQ Bot
在Full Setup流程中选QQ Bot，填AppID和Token。

## 中国网络注意事项

| 工具 | 代理地址 | 说明 |
|------|---------|------|
| GitHub Proxy | `ghfast.top` | git clone / wget / curl / zip下载 |
| 备用代理 | `ghproxy.com` | 同上格式，ghfast挂了用这个 |
| gitclone.com | ❌ 已失效 | 不要用 |
| 本地代理 | `$env:HTTPS_PROXY='http://127.0.0.1:7890'` | 走Clash |

## 常见报错

**"对路径...访问被拒绝"**
残留旧目录，先清理。

**安装失败后出现 `hermes-agent.broken-*` 目录**
安装脚本自动重命名失败目录。全部删掉重来。

**`install.ps1` 找不到**
它在 CDN 网站（`hermes-agent.nousresearch.com`），**不在 GitHub 仓库里**。zip/clone 下来的源码没有这个文件。不要浪费时间找它——走备选3手动安装。

**`hermes_bootstrap.py` 跑了但没反应**
bootstrap只是下载前置依赖（Git/Python/Node/uv），不会安装Hermes本身。跳过它，直接走 pip install。

**`pip install -e .` 报 "No module named pip"**
uv托管的Python不带pip。用 `uv pip install` 代替。

**`uv pip install --system` 报 "externally managed"**
uv的Python禁止系统级安装。必须创建独立venv（见步骤5备选）。

**路径混淆：`hermes-agent` vs `hermes`**
- 源码目录是 `$env:LOCALAPPDATA\hermes\hermes-agent`（两层）
- 最终可执行文件在venv里

**PowerShell中 `$env:LOCALAPPDATA\...` 路径报红**
用 `& "..."` 格式包裹，加双引号和 `&` 调用运算符。

## 跨机器部署提示

- 新机只需装Hermes+配QQ，不需要迁移记忆/技能
- 同一QQ Bot，两台机器都能收到消息
