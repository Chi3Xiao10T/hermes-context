# Memory Merging 系统

## 为什么需要合并

向量库是追加模式，同一个话题聊多次会产生多条高度相似的条目：

```
用户问充电桩安装费用 → 存1条
用户问装充电桩多少钱 → 又存1条  
用户请教充电桩流程   → 又存1条
```

搜索结果里有3条几乎一样的信息，既不经济（占用上下文 token）也
没必要（降低信噪比）。

## 合并算法

### 分组

```python
def _find_similar_groups(vectors, threshold=0.85, min_group_size=3):
    # 1. 归一化所有向量
    normalized = vectors / norms
    
    # 2. 余弦相似度矩阵 (N×N)
    sim_matrix = np.dot(normalized, normalized.T)
    
    # 3. 贪心分组：从第一条开始，把所有相似度 > threshold 的归为一组
    for i in range(n):
        if assigned[i]:
            continue
        similar = np.where((sim_matrix[i] > threshold) & (~assigned))[0]
        if len(similar) >= min_group_size:
            assigned[similar] = True
            groups.append(similar.tolist())
```

**注意**：这是贪心算法，分组顺序依赖索引顺序。对于<1000条的数据集，
结果足够好。如果需要更精确的聚类（如 DBSCAN/HDBSCAN），后续可升级。

### LLM 合并

每组发送给 DeepSeek API：

```json
{
  "model": "deepseek-v4-flash",
  "messages": [
    {"role": "system", "content": "把下面几段相似的记忆合并成一段简洁精华的文字..."},
    {"role": "user", "content": "- 用户想问充电桩多少钱\n- 充电桩安装费用和手续\n- 装充电桩要多少钱"}
  ],
  "temperature": 0.3  // 低温度保证稳定性
}
```

合并示例（实测）：

```
输入3条小米双卡设置 → 输出:
"小米手机双卡双待设置方法：进入设置，选择"双卡与移动网络"，
根据需要开启双卡并设置默认卡。"
```

### 替换

1. 从 npy 矩阵中删除被合并的行
2. 从 SQLite 删除对应元数据
3. 对新合并的文本做 embedding
4. 追加到 npy + SQLite

## 参数调优指南

| 场景 | threshold | min-group | 效果 |
|------|-----------|-----------|------|
| 默认 | 0.85 | 3 | 只合并几乎一样的条目，极保守 |
| 激进 | 0.70 | 2 | 连"充电桩"和"电动车"都可能合在一起 |
| 新装后首次 | 0.70 | 2 | 快速清理首次积累的重复 |
| 稳定运行 | 0.90 | 4 | 几乎不合，留给每周预设的保守合并 |

## 综合阈值建议

- **搜索过滤阈值**（`_SIMILARITY_THRESHOLD`）= 0.30
  - 低于此值视为不相关，不注入上下文
  - 0.35 更严格但可能漏掉相关结果
  
- **合并阈值**（`--threshold`）= 0.85
  - 高于此值视为重复，准备合并
  - 0.70 会合并更多但可能误合

## cronjob 配置

```bash
# 每周日凌晨3点
0 3 * * 0

# 通过 no_agent=true 直接输出合并统计，不消耗 LLM token
```

所需文件（均在 `~/.hermes/scripts/` 下）：
- `merge_memories.sh` — cronjob wrapper
- `merge_memories.py` — 主体逻辑
- `vector_store.py` — 依赖的 Embedder 类

## 边界情况

1. **向量库为空** → 跳过，不报错
2. **DeepSeek API 超时** → 跳过当前组，继续下一组
3. **合并后只剩1条** → 保留该条，非空向量库
4. **全部被合并** → 不会发生，因为 group 只分组 ≥ min_group_size 的条目，剩下的保留
5. **VISION_API_KEY 未设** → 新合并的条目 embedding 全零 → 下次搜索命中不了 → 但日志记录仍在

## 与 OpenClaw Basic Memory 的对比

| 功能 | 龙虾 | 小橙v3 |
|------|------|--------|
| 合并频率 | 每次 session_end 后 | 每周 |
| 合并策略 | 按时间窗口+语义 | 按相似度矩阵 |
| LLM 耗用 | 每次合并都调 | 每周调1-N次 |
| 去重精度 | 好（LLM+向量混合） | 中（纯向量分组） |
| 碎片控制 | 自动 | 手动（cron） |

## 其他摘要和关键发现

### 路径配置（Path resolution）
当 HERMES_HOME 环境变量未设置时，`Path(os.environ.get("HERMES_HOME",""))`
返回的不是假值而是 Path(".") 即当前工作目录，会导致向量库存储到错误位置。
一定要用 `Path(raw) if raw.strip() else Path.home() / ".hermes"`。

### 低相关过滤
余弦相似度阈值设为 0.30 时仍然会有极低相关的误报（如"电脑怎么装系统"对"充电桩"
得 0.323），这是 embedding 模型的局限——两个不相关的短文本也可能因为都包含动词
“怎么装”而产生非零相似度。

### 未来改进
1. 本地 embedding 模型（去掉远程 API 依赖）
2. 使用 ANN 索引（如 faiss）支持更大规模
3. DBSCAN/HDBSCAN 代替贪心分组
4. 自省能力（知道自己知道什么，支持删除/修改）
