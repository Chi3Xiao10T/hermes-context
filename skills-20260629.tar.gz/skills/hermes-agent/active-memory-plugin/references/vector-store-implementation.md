# Lightweight Vector Store 原理与实现

## 为什么不用 ChromaDB？

ChromaDB 的 `embedding_function` 接口有兼容性问题：
- 需要自定义 embedding function 有 `.name` 属性（字符串）
- 但有 `.name` 后 ChromaDB 又把它当字符串模型名去调用（`'str' object is not callable`）
- 版本升级后行为不稳定

## 自建方案架构

```
numpy 矩阵 (vectors.npy)     SQLite 表 (metadata.db)
┌─────────────────┐         ┌──────────────────────────┐
│ N×512 float32    │    ←→  │ id | text | ts | source  │
│ 每条=2KB          │         │ rowid == npy 行索引     │
└─────────────────┘         └──────────────────────────┘
```

## 核心操作代码

### 存储（add）

```python
# 1. 算向量
vec = embedder.embed([text])  # → [[0.053, -0.012, ...]] (512维)

# 2. 写元数据
conn.execute("INSERT INTO entries (id, text, created_at, source) VALUES (?,?,?,?)",
             (doc_id, text[:2000], now, metadata.get("source", "")))

# 3. 追加向量
vectors = np.load("vectors.npy")  # 已有矩阵
new_vec = np.array(vec[0], dtype=np.float32).reshape(1, -1)
vectors = np.vstack([vectors, new_vec])
np.save("vectors.npy", vectors)
```

### 搜索（search）

```python
# 1. 算查询向量
q = np.array(embedder.embed([query])[0], dtype=np.float32)

# 2. 余弦相似度
norms = np.linalg.norm(vectors, axis=1)
norms[norms == 0] = 1  # 防除零
scores = np.dot(vectors, q) / (norms * np.linalg.norm(q))

# 3. 取 top-K
top_indices = np.argsort(scores)[-limit:][::-1]

# 4. 过滤低相关
for idx in top_indices:
    if scores[idx] < 0.30:  # 阈值
        continue
    # 通过 rowid = idx 取元数据
    row = conn.execute("SELECT ... FROM entries ORDER BY rowid LIMIT 1 OFFSET ?", (idx,))
```

## 为什么 npy 索引要和 SQLite rowid 对齐？

`rowid` 是 SQLite 隐藏自增列，从1开始
`npy` 矩阵的行索引从0开始
所以 `rowid = numpy_idx + 1`

**重要**：确保 `INSERT` 和 `npy.append` 在同一个事务中完成，否则索引漂移。

### 安全性考虑

由于向量存储是**追加模式**，npy 行索引始终和 SQLite rowid 对齐（都是顺序递增），不存在碎片问题。但如果需要删除功能，需要重建索引。

## 性能

- 1万条 × 512维 = 20MB，全量余弦相似度耗时 < 50ms（纯 numpy）
- 10万条 = 200MB，耗时 ~500ms，仍然可接受
- 超过10万条应考虑分片或近似搜索（ANN）

## 远程 Embedding API

### GitHub Models（当前使用）

```
Endpoint: https://models.inference.ai.azure.com
Model: text-embedding-3-small
Dimensions: 512  (可选 256/512/1024/3072)
Auth: Bearer token（GitHub PAT）
Cost: 免费（Rate-limited）
```

### 备选 API

| 提供商 | 模型 | 维度 | 中文效果 | 国内访问 |
|--------|------|------|---------|---------|
| GitHub Models | text-embedding-3-small | 512 | 好 | ✅ 直连 |
| SiliconFlow | BAAI/bge-large-zh-v1.5 | 1024 | 很好 | ✅ 直连 |
| DeepSeek | (尚无独立embedding API) | - | - | - |
