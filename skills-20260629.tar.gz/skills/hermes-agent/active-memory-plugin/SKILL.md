---
name: active-memory-plugin
description: 维护和升级 Active Memory 插件（自动记忆注入 + FTS5 + 向量搜索 + 自动捕获）。
category: hermes-agent
triggers:
  - 用户提到「记忆」「记住」「忘记」「回忆」「插件」「升级插件」
  - 需要修改 ~/.hermes/plugins/active-memory/ 下的文件
  - 需要理解 Active Memory v1/v2/v3 行为差异
---

# Active Memory 插件维护

## 概述

Active Memory 是安装在 `~/.hermes/plugins/active-memory/` 的自定义 Hermes 插件，注册了一个 `memory_search` 工具和三个钩子实现记忆功能：

| 钩子 | 触发时机 | 行为 |
|------|---------|------|
| `on_session_start` | 新对话开始时 | 加载近3天对话日志到系统提示 |
| `pre_llm_call` | 每次 LLM 调用前 | 同时查 FTS5 关键词 + 向量语义搜索，注入上下文 |
| `on_session_end` | 对话结束时 | 写入日常日志 + 写入向量库 |

## 文件结构

```
~/.hermes/plugins/active-memory/
├── __init__.py              — 插件入口，注册钩子（版本号在 log 中定义）
├── vector_store.py          — 自建轻量向量库（numpy + sqlite）
├── merge_memories.py        — 记忆合并工具（LLM去重）
├── merge_memories.sh        — cronjob wrapper
├── plugin.yaml              — Hermes 插件声明
└── active-memory-logs/      — 每日日志（自动生成）
```

## 版本演变

| 版本 | 新增能力 | 状态 |
|------|---------|------|
| v1 | FTS5关键词搜索 + 上下文注入 | 已弃用 |
| v2 | on_session_end 自动捕获 + on_session_start 加载近期 | 已弃用 |
| **v3（当前）** | 向量语义搜索 + FTS5/向量结果合并去重 + 记忆自动合并 | **当前版本** |

## 向量搜索架构

### 核心思路
不用 ChromaDB 内置的 embedding_function（兼容性问题），而是自己算好向量后存储：

1. **Embedding 生成**：调用远程 API（GitHub Models `text-embedding-3-small`，免费）
2. **向量存为 numpy 矩阵**：`vectors.npy`（N×512 float32），直接 `np.load`/`np.save`
3. **元数据用 SQLite**：`metadata.db`（id, text, created_at, source）
4. **搜索**：余弦相似度 = `dot(vectors, q) / (norms * ||q||)`，取 top-K

### ChromaDB 替代方案 vs 自建方案

| 方案 | 优点 | 缺点 |
|------|------|------|
| ChromaDB + embedding_function | 官方推荐 | embedding_function 接口有兼容bug（需name属性且被当字符串调用） |
| ChromaDB + 自己算向量 | 存储查询可靠 | 依赖 ChromaDB 版本 |
| **numpy + sqlite（当前）** | 零依赖，完全可控，适合小规模（<10万条） | 无索引，全量扫描，但512维×N条足够快 |

### 本地 ONNX Embedding（当前方案）

使用 **fastembed** + `BAAI/bge-small-zh-v1.5`（百度出品的中文专用 ONNX 模型）：

```python
from fastembed import TextEmbedding
model = TextEmbedding(model_name='BAAI/bge-small-zh-v1.5')
vec = list(model.embed(['充电桩要多少钱']))[0]  # 512维, ~11ms
```

- 首次运行自动下载 ~90MB ONNX 模型，缓存到 `~/.cache/huggingface/`
- 完全离线运行，断网不影响
- onnxruntime 已预装（1.23.2 或更高）

### 旧方案（已废弃）

之前用的远程 GitHub Models `text-embedding-3-small`（通过 `VISION_API_KEY` 环境变量访问）。已全部切换为本地 ONNX 方案。

### 语义搜索优势

示例测试结果证明向量搜索能匹配「不同词同义」的场景：

| 搜索词 | FTS5结果 | 向量结果 | 最佳分数 |
|--------|---------|---------|---------|
| 「怎么给车充电」 | ❌ 无 | ✅ 续航+充电桩 | 0.64 |
| 「出去走走」 | ❌ 无 | ✅ 天气相关 | 0.37 |
| 「特斯拉没电了」 | ❌ 无 | ✅ 续航相关 | 0.35 |
| 「充电桩费用」 | ✅ 充电桩 | ✅ 充电桩+新对话 | 0.78 |

## 记忆合并（Memory Merging）

### 为什么要合并

向量库是追加模式，多条相似的记忆（如3条关于"充电桩安装费用"）会分别存储，
导致搜索时重复出现。需要定期清理。

### 合并流程

```
读取所有向量 → 余弦相似度矩阵 → 按阈值分组 → 每组调LLM合并 → 替换
```

### 参数

```
merge_memories.py --threshold 0.85 --min-group 3   # 默认：保守模式
merge_memories.py --threshold 0.70 --min-group 2   # 激进模式
merge_memories.py --dry-run                          # 预览不执行
```

- **threshold**: 0.85（默认，只合并高度相似的），0.70（激进合并）
- **min-group**: 最少几条才合并（默认3，激进2）
- **DeepSeek API** 负责把多条合并为一条精华

### 合并效果（实测）

```
7条 → 找到2组(充电桩3条+小米双卡3条) → 合并后3条
搜索质量验证：合并后搜索「装充电桩要多少钱」仍能 0.729 命中 ✅
```

### 每周自动合并（cronjob）

```bash
# 已在 cron 中注册，每周日凌晨 3 点运行
# script: ~/.hermes/scripts/merge_memories.sh
# no_agent: true（直接输出合并统计）
```

**注意**：`merge_memories.py` 依赖 `vector_store.py` 的 `Embedder` 类，
两者都需要复制到 `~/.hermes/scripts/` 目录下才能被 cronjob 调用。

### PATH/HERMES_HOME 大坑

`Path("")` 在 Python 中是 truthy！不要这样写：

```python
# ❌ 错误：HERMES_HOME 为空字符串时 Path("") 返回 Path(".") 不是假值
home = Path(os.environ.get("HERMES_HOME", "")) or Path.home() / ".hermes"

# ✅ 正确：先检查字符串是否为空
raw = os.environ.get("HERMES_HOME", "")
home = Path(raw) if raw.strip() else Path.home() / ".hermes"
```

## 插件入口（register 函数）

```python
def register(plugin_manager) -> None:
    plugin_manager.register_tool(
        name="memory_search",
        toolset="active-memory",
        schema=_MEMORY_SEARCH_SCHEMA,
        handler=_handle_memory_search,
    )
    plugin_manager.register_hook("on_session_start", on_session_start)
    plugin_manager.register_hook("pre_llm_call", on_pre_llm_call)
    plugin_manager.register_hook("on_session_end", on_session_end)
```

`memory_search` 工具注册在 `active-memory` toolset 中。工具描述、参数 schema 在 `__init__.py` 的 `_MEMORY_SEARCH_SCHEMA` 定义。handler 执行 FTS5 + 向量双通道搜索后合并返回 JSON。

## 合并搜索（FTS5 + Vector）

`on_pre_llm_call` 同时执行两种搜索后合并：

```python
fts5_results = _search_session_history(query, limit=3)
vector_results = vs.search(query, limit=5)
merged = _merge_results(fts5_results, vector_results, max_total=5)
```

合并去重逻辑：向量结果优先（带分数），FTS5 结果补充未重复的，按分数降序排列。

## 关键常量

```python
_SIMILARITY_THRESHOLD = 0.30  # 余弦相似度阈值，低于此值过滤
_EMBEDDING_DIM = 512          # text-embedding-3-small 维度
_MAX_RESULTS = 5              # 搜索结果上限
```

## 重启网关（通知模式）

由于重启网关会杀掉当前 Hermes 会话，用户收不到重启完成的确认消息。  
**标准流程**：重启前先创建一个一次性 cronjob（1分钟后触发），cronjob 检查网关是否已成功启动并加载了所需插件/配置，确认后通过 `send_message` 通知用户。

```python
# 伪代码 — 重启网关前先建通知 cronjob
1. cronjob action=create name="notify-restart" schedule="+1min" \
     prompt="检查网关是否已启动且ActiveMemory已加载，通知用户" \
     deliver=origin

2. 然后执行重启：
   kill [PID]
   hermes gateway run --replace &
```

注意：`systemctl --user restart hermes-gateway` 可能找不到 service（如果网关是直接进程方式运行的），改用 `kill PID` + `hermes gateway run --replace`。

## 注意事项

1. **numpy 必须提前装好**：vector_store.py 依赖 numpy（`import numpy as np`）
2. **VISION_API_KEY 环境变量**：插件运行时由 Hermes 自动注入，不需要手动设
3. **第一次测试时**：先手动设 `os.environ["VISION_API_KEY"]` 再 import，否则 embedding 调用返回全零
4. **向量文件会增长**：每条512维×4字节=2KB+SQLite元数据，10000条约20MB。每周自动合并会压缩
5. **deepseek-v4-flash 用于合并**：merge_memories.py 直接调 DeepSeek API（读 .env 的 DEEPSEEK_API_KEY），不走 Hermes 上下文
6. **on_session_start 和 pre_llm_call 都不阻塞 LLM 调用**——返回 None 则正常继续
7. **网关重启后上下文丢失**：QQ 用户可能在网关重启期间通过 QQ 回答了问题，但重启后 CLI 会话看不到那条消息。**不要重复问用户**——先查 `grep "用户ID" /root/.hermes/logs/{gateway,agent}.log | tail -20` 找回丢失的上下文。用户 QQ ID 固定为 `ECE3D29B1F49BC3108BFC157ECCC8F4E`。
