---
name: systematic-debugging
description: "4-phase root cause debugging: understand bugs before fixing."
version: 1.2.0
author: Hermes Agent (adapted from obra/superpowers)
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [debugging, troubleshooting, problem-solving, root-cause, investigation]
    related_skills: [test-driven-development, writing-plans, subagent-driven-development]
---

# Systematic Debugging

## Overview

Random fixes waste time and create new bugs. Quick patches mask underlying issues.

**Core principle:** ALWAYS find root cause before attempting fixes. Symptom fixes are failure.

**Violating the letter of this process is violating the spirit of debugging.**

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

If you haven't completed Phase 1, you cannot propose fixes.

## When to Use

Use for ANY technical issue:
- Test failures
- Bugs in production
- Unexpected behavior
- Performance problems
- Build failures
- Integration issues
- **Network failures (timeouts, auth errors, connection drops)**
- **API errors that look like capacity/resource problems (503, 429, "No available accounts")**

**Use this ESPECIALLY when:**
- Under time pressure (emergencies make guessing tempting)
- "Just one quick fix" seems obvious
- You've already tried multiple fixes
- Previous fix didn't work
- You don't fully understand the issue
- The failure is intermittent or environment-dependent
- **An API returns a resource/capacity error (503, "no accounts") — don't assume it's truly a capacity issue**

**Don't skip when:**
- Issue seems simple (simple bugs have root causes too)
- You're in a hurry (rushing guarantees rework)
- Someone wants it fixed NOW (systematic is faster than thrashing)

## The Four Phases

You MUST complete each phase before proceeding to the next.

---

## Phase 1: Root Cause Investigation

**BEFORE attempting ANY fix:**

### 1. Read Error Messages Carefully

- Don't skip past errors or warnings
- They often contain the exact solution
- Read stack traces completely
- Note line numbers, file paths, error codes
- **For network errors: distinguish between timeout, auth, connection-refused, and DNS failure**

#### 🚩 Pitfall: API 503/429 errors are NOT always resource/capacity problems

When an API returns `503 "No available accounts"` or `429 "Rate limited"`, the natural assumption is resource exhaustion. **This is often wrong.** Many API gateways use these same status codes for **key permission denial**:

**Test it:** Send the same request to **different model types** through the same endpoint. If ALL models (image, text, chat) return the same 503, the key simply **doesn't have permission** for those models — it's an auth/scope issue, not capacity. A genuinely resource-starved service will return errors only on the affected model class while other models still work.

| Test | All models 503 | Only image models 503 |
|------|---------------|-----------------------|
| Likely cause | Key permission denied | GPU capacity shortage |
| Fix | Get broader-scoped API key | Retry or switch relay |

**Golden rule:** If you can't explain WHY only the target model would be out of capacity while others are fine, you haven't ruled out key-scope rejection.

**Another critical rule:** Before asserting something "doesn't work" or diagnosing WHY, check YOUR OWN HISTORY first. If you claimed X worked yesterday, don't claim it's a permission issue today without verifying the actual past session records. Contradictory explanations (X is broken because of A, then B, then C) destroy trust. Do ONE thorough verification pass, present ONE consistent conclusion, or say "I'm not sure, let me investigate".

#### 🧩 "It Worked Before" Pattern — The Session-History Trap

**The user's insight you must internalize:** "不应该是这种情况，能用就能用，不能用就不能用，不可能会是你用了然后才不能用" — A working API/service doesn't stop working from a few normal calls. If a service returned 200 yesterday and 503 today, 3 more calls today didn't cause the outage. The root cause is always external.

**Your mandatory response when user says "it worked before":**

1. **Immediately verify via session search** — `session_search(query="<service/model name> success <date>", sort="newest")` to locate the actual success records. Do NOT rely on your memory or summary knowledge.
2. **Compare the exact call signatures** — Was the same endpoint used? Same model name? Same auth header? Same API format (chat/completions vs messages)? Extract the literal curl/Python call from the success session.
3. **Check for API format mismatch** — Sometimes a service supports both OpenAI chat/completions AND Anthropic messages. Success in one format doesn't guarantee the other has the same upstream backend. Test BOTH formats before concluding "channel is dead".
4. **Distinguish between 3 failure signatures from the provider:**

| Yesterday | Today | Likely Root Cause |
|-----------|-------|-------------------|
| 200 (success) | 503 "No available accounts" (different error message from other models) | Upstream provider removed/disabled this model tier on the relay. Not your usage. |
| 200 | 503 (SAME error as other models) | Relay-wide upstream failure. |
| 200 | 503 "All accounts exhausted" | Temporary capacity crunch — retry later. |

5. **NEVER say "GPU shortage", "Key permission", or "upstream removed" without evidence** — each of these is a specific claim that requires proof. If you can't verify (e.g. no dashboard access), say so directly: "I can confirm X and Y but can't determine Z without dashboard access."

**Red flags that you're guessing instead of investigating:**
When the user challenges your conclusion ("it can't be that"), your response must NOT be another guess. Follow this checklist:

1. **Pause and check past session records** — `session_search(query="<model/service name> success test", sort="newest")` to confirm what actually happened
2. **Re-verify the current state** — Don't just retry the same call; test a CONTROL (a model type that SHOULD work alongside the one that doesn't) to distinguish scope from capacity
3. **Check environment state** — Is the proxy running? Are env vars correct? (`http_proxy` set but Clash dead = all calls fail silently through dead proxy)
4. **Present ONE diagnosis** — If you're not sure, say "I've verified X and Y but can't determine Z without [additional access]" — do NOT give 3 alternative theories

#### 🧩 "It Worked Before" Pattern — The Session-History Trap

**The user's insight you must internalize:** "不应该是这种情况，能用就能用，不能用就不能用，不可能会是你用了然后才不能用" — A working API/service doesn't stop working from a few normal calls. If a service returned 200 yesterday and 503 today, 3 more calls today didn't cause the outage. The root cause is always external.

**Your mandatory response when user says "it worked before":**

1. **Immediately verify via session search** — `session_search(query="<service/model name> success <date>", sort="newest")` to locate the actual success records. Do NOT rely on your memory or summary knowledge.
2. **Compare the exact call signatures** — Was the same endpoint used? Same model name? Same auth header? Same API format (chat/completions vs messages)? Extract the literal curl/Python call from the success session.
3. **Check for API format mismatch** — Sometimes a service supports both OpenAI chat/completions AND Anthropic messages. Success in one format doesn't guarantee the other has the same upstream backend. Test BOTH formats before concluding "channel is dead".
4. **Distinguish between 3 failure signatures from the provider:**

| Yesterday | Today | Likely Root Cause |
|-----------|-------|-------------------|
| 200 (success) | 503 "No available accounts" (different error message from other models) | Upstream provider removed/disabled this model tier on the relay. Not your usage. |
| 200 | 503 (SAME error as other models) | Relay-wide upstream failure. |
| 200 | 503 "All accounts exhausted" | Temporary capacity crunch — retry later. |

5. **NEVER say "GPU shortage", "Key permission", or "upstream removed" without evidence** — each of these is a specific claim that requires proof. If you can't verify (e.g. no dashboard access), say so directly: "I can confirm X and Y but can't determine Z without dashboard access."

**Red flags that you're guessing instead of investigating:**
- You've given 2+ different explanations in the same conversation
- The user says "you tested this successfully yesterday" and you haven't checked session history
- You're suggesting a fix without knowing WHICH of several possible root causes is real
- You're attributing the same error code to different causes for different models without testing all models the same way

**Action:** Use `read_file` on the relevant source files. Use `search_files` to find the error string in the codebase.

### 1b. ⚠️ Diagnostic Tool Reliability — Guard Against Hallucination

**WHEN your diagnostic tool itself is unreliable** (e.g. visual screenshot analysis from a vision model that knows what content SHOULD be on the page):

**The vision model hallucination pattern:** A vision model with prior knowledge of expected page content may report "all Chinese text displays normally" even when the actual screenshot shows garbled characters, blocks, or question marks. The model "sees" what it expects to see, not what's actually rendered.

**Detection signals:**
- Model gives a vague "looks fine" answer but can't produce specific text on request
- Description matches the *expected* page content, not evidence of *rendered* content
- User consistently reports the image looks bad despite model saying it's fine
- Model describes "clear text" but can't read individual characters when asked to spell them out

**Cross-verification techniques:**

1. **Ask for literal transcription:** Request character-by-character reading ("逐字读出来") — if the model can't do it or changes its answer, the image is likely garbled
2. **Use CDP to read DOM text:** The accessibility tree (`browser_snapshot`) and CDP `Runtime.evaluate` return the actual text Nodes regardless of font rendering — compares what SHOULD be visible vs what the screenshot renders
3. **CSS font audit via CDP:** Check what fonts are actually being used by the page:
   ```
   // Check computed font-family on an element
   getComputedStyle(document.querySelector('h1')).fontFamily
   ```
4. **Use a completely independent tool:** If the vision model and screenshot are both from the same pipeline, route through a different tool (e.g. `vision_analyze` vs `browser_vision` may use different backends)
5. **Check for font availability on the OS:** Before assuming screenshot quality, verify the rendering engine has fonts installed:
   ```bash
   # Check if Chinese fonts are available
   fc-list :lang=zh | head -5
   # If empty, install fonts
   apt-get install -y fonts-wqy-zenhei fonts-wqy-microhei
   ```

**Golden rule:** If you've asked the model to verify screenshot quality twice and it keeps saying "fine" while the user says it's garbled, the model is almost certainly hallucinating. Switch verification method immediately — do not send another "is it fine now?" screenshot without cross-verifying first.

### 2. Reproduce Consistently

- Can you trigger it reliably?
- What are the exact steps?
- Does it happen every time?
- If not reproducible → gather more data, don't guess
- **For network issues: test with small payloads first, then scale up**

**Action:** Use the `terminal` tool to run the failing test or trigger the bug:

```bash
# Run specific failing test
pytest tests/test_module.py::test_name -v

# Run with verbose output
pytest tests/test_module.py -v --tb=long
```

### 3. Check Recent Changes

- What changed that could cause this?
- Git diff, recent commits
- New dependencies, config changes

**Action:**

```bash
# Recent commits
git log --oneline -10

# Uncommitted changes
git diff

# Changes in specific file
git log -p --follow src/problematic_file.py | head -100
```

### 4. Gather Evidence in Multi-Component Systems

**WHEN system has multiple components (API → service → database, CI → build → deploy):**

**BEFORE proposing fixes, add diagnostic instrumentation:**

For EACH component boundary:
- Log what data enters the component
- Log what data exits the component
- Verify environment/config propagation
- Check state at each layer

Run once to gather evidence showing WHERE it breaks.
THEN analyze evidence to identify the failing component.
THEN investigate that specific component.

### 5. Trace Data Flow

**WHEN error is deep in the call stack:**

- Where does the bad value originate?
- What called this function with the bad value?
- Keep tracing upstream until you find the source
- Fix at the source, not at the symptom

**Action:** Use `search_files` to trace references:

```python
# Find where the function is called
search_files("function_name(", path="src/", file_glob="*.py")

# Find where the variable is set
search_files("variable_name\\s*=", path="src/", file_glob="*.py")
```

### Phase 1 Completion Checklist

- [ ] Error messages fully read and understood
- [ ] Issue reproduced consistently
- [ ] Recent changes identified and reviewed
- [ ] Evidence gathered (logs, state, data flow)
- [ ] Problem isolated to specific component/code
- [ ] Root cause hypothesis formed

**STOP:** Do not proceed to Phase 2 until you understand WHY it's happening.

---

## Phase 2: Pattern Analysis

**Find the pattern before fixing:**

### 1. Find Working Examples

- Locate similar working code in the same codebase
- What works that's similar to what's broken?

**Action:** Use `search_files` to find comparable patterns:

```python
search_files("similar_pattern", path="src/", file_glob="*.py")
```

### 2. Compare Against References

- If implementing a pattern, read the reference implementation COMPLETELY
- Don't skim — read every line
- Understand the pattern fully before applying

### 3. Identify Differences

- What's different between working and broken?
- List every difference, however small
- Don't assume "that can't matter"

### 4. Understand Dependencies

- What other components does this need?
- What settings, config, environment?
- What assumptions does it make?

---

## Phase 3: Hypothesis and Testing

**Scientific method:**

### 1. Form a Single Hypothesis

- State clearly: "I think X is the root cause because Y"
- Write it down
- Be specific, not vague

### 2. Test Minimally

- Make the SMALLEST possible change to test the hypothesis
- One variable at a time
- Don't fix multiple things at once

### 3. Verify Before Continuing

- Did it work? → Phase 4
- Didn't work? → Form NEW hypothesis
- DON'T add more fixes on top

### 4. When You Don't Know

- Say "I don't understand X"
- Don't pretend to know
- Ask the user for help
- Research more

---

## Phase 4: Implementation

**Fix the root cause, not the symptom:**

### 1. Create Failing Test Case

- Simplest possible reproduction
- Automated test if possible
- MUST have before fixing
- Use the `test-driven-development` skill

### 2. Implement Single Fix

- Address the root cause identified
- ONE change at a time
- No "while I'm here" improvements
- No bundled refactoring

### 3. Verify Fix

```bash
# Run the specific regression test
pytest tests/test_module.py::test_regression -v

# Run full suite — no regressions
pytest tests/ -q
```

### 4. If Fix Doesn't Work — The Rule of Three

- **STOP.**
- Count: How many fixes have you tried?
- If < 3: Return to Phase 1, re-analyze with new information
- **If ≥ 3: STOP and question the architecture (step 5 below)**
- DON'T attempt Fix #4 without architectural discussion

### 5. If 3+ Fixes Failed: Question Architecture

**Pattern indicating an architectural problem:**
- Each fix reveals new shared state/coupling in a different place
- Fixes require "massive refactoring" to implement
- Each fix creates new symptoms elsewhere

**STOP and question fundamentals:**
- Is this pattern fundamentally sound?
- Are we "sticking with it through sheer inertia"?
- Should we refactor the architecture vs. continue fixing symptoms?

**Discuss with the user before attempting more fixes.**

This is NOT a failed hypothesis — this is a wrong architecture.

---

## Network Issue Investigation

When debugging network-related failures (timeouts, auth errors, connection drops):

### Progressive Payload Testing

1. Start with a **minimal request** (GET /status or < 1KB payload POST) on both direct and proxy paths
2. Verify basic connectivity and auth work before scaling up
3. Scale payload size progressively: 100B → 10KB → 100KB → target size
4. Each step isolates whether the failure is auth, connectivity, timeout, or payload-size related

### Direct-vs-Proxy Comparison

- Always test BOTH paths — they fail differently
- **Direct may timeout** while proxy passes (good route exists)
- **Proxy may return 401** while direct passes 200 (proxy corrupts headers/auth)
- A proxy-passing 401 while direct passes 200 signals header/credential interference through proxy

### Timeout Diagnosis

| Symptom | Likely Cause |
|---------|-------------|
| `write timeout` | Upload stall — network can't push data fast enough |
| `read timeout` | Server processing stall — request arrived but response delayed |
| Connection reset | Middlebox (GFW, ISP) interrupted connection mid-transfer |
| 401 after proxy | Proxy's IP or auth headers altered by intermediate gateway |

### Tool Choice from Restrictive Networks (China)

For large file uploads to GitHub:

| Method | Behavior |
|--------|----------|
| GitHub REST API `/git/blobs` (5MB+) | ❌ Times out from Chinese networks — single POST can't complete |
| Git CLI push via HTTPS | ✅ Reliable — 67s for 5.7MB, built-in compression + chunked transfer |

### Hypothesis Formation for Network Issues

**Bad hypothesis:** "Upload is slow, use proxy"
- Skips verifying whether proxy changes auth headers
- Skips testing whether small payloads work on either path

**Good hypothesis:** "Direct connection can't maintain throughput for >1MB uploads because the network drops the TCP connection mid-transfer"
- Verified by: small payloads pass, large payloads timeout consistently
- Evidence: timeout always at similar transfer duration, not data size
- Fix targets the transport layer (switch to git push), not the endpoint

---

## Red Flags — STOP and Follow Process

If you catch yourself thinking:
- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "Skip the test, I'll manually verify"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- "Pattern says X but I'll adapt it differently"
- "Here are the main problems: [lists fixes without investigation]"
- Proposing solutions before tracing data flow
- **"One more fix attempt" (when already tried 2+)**
- **Each fix reveals a new problem in a different place**

**ALL of these mean: STOP. Return to Phase 1.**

**If 3+ fixes failed:** Question the architecture (Phase 4 step 5).

## Common Rationalizations

| Excuse | Reality |
|--------|---------|
| "Issue is simple, don't need process" | Simple issues have root causes too. Process is fast for simple bugs. |
| "Emergency, no time for process" | Systematic debugging is FASTER than guess-and-check thrashing. |
| "Just try this first, then investigate" | First fix sets the pattern. Do it right from the start. |
| "I'll write test after confirming fix works" | Untested fixes don't stick. Test first proves it. |
| "Multiple fixes at once saves time" | Can't isolate what worked. Causes new bugs. |
| "Reference too long, I'll adapt the pattern" | Partial understanding guarantees bugs. Read it completely. |
| "I see the problem, let me fix it" | Seeing symptoms ≠ understanding root cause. |
| "One more fix attempt" (after 2+ failures) | 3+ failures = architectural problem. Question the pattern, don't fix again. |
| **"Just add proxy, that's the fix"** | Must verify both paths fail differently first. Blind proxy addition masks root cause. |

## Quick Reference

| Phase | Key Activities | Success Criteria |
|-------|---------------|------------------|
| **1. Root Cause** | Read errors, reproduce, check changes, gather evidence, trace data flow | Understand WHAT and WHY |
| **2. Pattern** | Find working examples, compare, identify differences | Know what's different |
| **3. Hypothesis** | Form theory, test minimally, one variable at a time | Confirmed or new hypothesis |
| **4. Implementation** | Create regression test, fix root cause, verify | Bug resolved, all tests pass |

## Context Loss Recovery (Gateway Restart / Session Interruption)

**WHEN you resume a conversation after the gateway restarted, was force-killed, or context was compacted/truncated:**

The user's most recent messages may have contained decisions, answers, or instructions that are no longer visible in your context. **Do NOT re-ask already-decided questions.**

### Recovery Steps

1. **Check gateway logs for inbound messages**
   ```bash
   grep "inbound message:" ~/.hermes/logs/gateway.log | tail -10
   ```
   This shows the last messages the user sent from connected platforms (QQ, Telegram, etc.) — including those that arrived and were processed between the restart and your current context.

2. **Check agent logs for completed sessions**
   ```bash
   grep -i "completed\|registered\|done" ~/.hermes/logs/agent.log | tail -5
   ```
   Confirms whether setup steps, tool registrations, or background operations completed before the restart.

3. **Determine completion status**
   - If the last inbound message was an answer/decision → do not re-ask, act on it
   - If the last inbound message was a question → the restart lost your pending response; answer it fresh
   - If the gateway log shows an empty message (user sent media) → check `attachments` field in the log for context

### Common Pitfalls

| Mistake | Why It Happens | Correct Action |
|---------|---------------|----------------|
| Asking "do you want X?" when user already said yes | Gateway restarted mid-response; user's yes arrived in a new agent session | Check `inbound message:` in gateway.log before asking |
| Repeating a pitch the user already rejected | Same root cause | Log first, ask later |
| Claiming "we haven't decided" when user already decided | Context compaction dropped the decision message | Check log timestamps — recent messages survive restart even if compacted from current view |
| Not seeing a user's image/screenshot | Image received as attachment, agent session didn't process it fully | Check gateway.log for `attachments=` field after restart |

### When in Doubt

If the logs are unclear or the user sends a message like "你自己看" ("look for yourself"), search the session history rather than asking again:

```python
session_search(query="<most likely topic>", limit=3)
```

This searches the SQLite message store for the actual past conversation, not your truncated context.

---

## Hermes Agent Integration

### Investigation Tools

Use these Hermes tools during Phase 1:

- **`search_files`** — Find error strings, trace function calls, locate patterns
- **`read_file`** — Read source code with line numbers for precise analysis
- **`terminal`** — Run tests, check git history, reproduce bugs
- **`web_search`/`web_extract`** — Research error messages, library docs

### With delegate_task

For complex multi-component debugging, dispatch investigation subagents:

```python
delegate_task(
    goal="Investigate why [specific test/behavior] fails",
    context="""
    Follow systematic-debugging skill:
    1. Read the error message carefully
    2. Reproduce the issue
    3. Trace the data flow to find root cause
    4. Report findings — do NOT fix yet

    Error: [paste full error]
    File: [path to failing code]
    Test command: [exact command]
    """,
    toolsets=['terminal', 'file']
)
```

### With test-driven-development

When fixing bugs:
1. Write a test that reproduces the bug (RED)
2. Debug systematically to find root cause
3. Fix the root cause (GREEN)
4. The test proves the fix and prevents regression

## Real-World Impact

From debugging sessions:
- Systematic approach: 15-30 minutes to fix
- Random fixes approach: 2-3 hours of thrashing
- First-time fix rate: 95% vs 40%
- New bugs introduced: Near zero vs common

**No shortcuts. No guessing. Systematic always wins.**
