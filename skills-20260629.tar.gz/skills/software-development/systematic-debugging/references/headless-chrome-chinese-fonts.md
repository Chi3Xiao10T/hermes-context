# Headless Chrome Chinese Font Rendering Debugging

## Problem
Screenshots from headless Chrome render Chinese characters as garbled text (boxes/question marks). Vision models may initially report "looks fine" due to hallucination (they know what text *should* be there).

## Root Cause
The system has Chinese fonts installed (`fonts-wqy-*`), but:
- **Snap Chromium** is sandboxed and CANNOT access `/usr/share/fonts/` — even after `apt install fonts-wqy-*`
- Copying fonts to `~/snap/chromium/common/.fonts/` doesn't help because the snap's fontconfig still can't see them properly
- The fix is to **not use snap Chromium** at all

## Fix

### Install Non-Snap Google Chrome
```bash
# Download Google Chrome .deb (not snap)
wget -q -O /tmp/chrome.deb https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb

# Install (may fail on deps, then fix them)
dpkg -i /tmp/chrome.deb
apt-get install -y -f        # fixes missing deps

# Install Chinese fonts
apt-get install -y fonts-wqy-zenhei fonts-wqy-microhei
```

### Start Headless Chrome with CDP
```bash
# Background mode
google-chrome-stable --headless --disable-gpu --no-sandbox \
  --remote-debugging-port=9222 --disable-dev-shm-usage
```

### Verify Fonts Are Available to Chrome
```bash
# Check system font list for Chinese
fc-list :lang=zh | head -5

# Verify Chrome started on CDP port
curl -s http://127.0.0.1:9222/json/version | python3 -m json.tool | head -5
```

### Verify Screenshot Rendering (Not via Vision Model!)
DO NOT trust the vision model's first answer. Cross-verify:

1. **CDP DOM check** — read actual DOM text via CDP:
   ```
   Target.getTargets → pick page target → Runtime.evaluate
   document.querySelector('h2').textContent
   ```

2. **Request literal transcription** — ask the vision model to "read each character one by one" — if it can't, the image is garbled

3. **Compare with expected text** — if the model says "上传工程量清单" but you know the page has different text, it's hallucinating

## Snap vs Non-Snap Chrome Comparison

| Aspect | Snap Chromium | Google Chrome (deb) |
|--------|--------------|-------------------|
| System font access | ❌ Sandboxed — can't read `/usr/share/fonts/` | ✅ Reads system fonts normally |
| Chinese font rendering | ❌ Garbled | ✅ Works with WQY fonts |
| Install method | Pre-installed on Ubuntu | `wget .deb + dpkg -i` |
| Startup command | `snap run chromium ...` | `google-chrome-stable ...` |
| Version checked | 148.0.7778.167 | 149.0.7827.53 |

## Key Takeaway
When debugging headless browser screenshot issues on Linux:
1. **Always use non-snap Chrome** — the sandbox blocks font access
2. **Install Chinese fonts system-wide** before starting Chrome
3. **Cross-verify vision model output** — it may hallucinate readable text when the image is actually garbled
4. **CDP DOM inspection** is the reliable fallback to verify page content independent of rendering
