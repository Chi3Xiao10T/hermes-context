---
name: windows-shell-debugging
description: "Diagnose and fix common Windows shell/terminal issues — PowerShell not accepting keyboard input, PSReadLine corruption, QuickEdit mode, console focus problems."
version: 1.0.0
author: Hermes Agent
platforms: [windows]
triggers:
  - user reports "can't type in PowerShell" or "keyboard doesn't work in terminal"
  - user says "only paste works" or "I can paste but not type"
  - cmd works but PowerShell broken
  - new PowerShell window still has same problem
---

# Windows Shell/Terminal Debugging

Diagnostic guide for Windows shell input failures — the "I can paste but not type" class of problem.

## Signal Pattern

- **PowerShell**: keyboard input doesn't work, but **paste works**
- **cmd**: works fine (typing OK)
- New PowerShell window: same problem (rules out process-stuck)
- Cursor blinks normally, interface looks fine — just doesn't accept keystrokes

## Diagnostic Flow (eliminate in order)

### Step 1: QuickEdit Mode

QuickEdit is on by default in classic PowerShell console. Mouse click enters selection mode, blocking keyboard input.

**Test**: Press **Esc** or **Enter** — if typing recovers, QuickEdit is the cause.

**Fix**: PowerShell window title bar → **Right-click → Properties → Options** tab → Uncheck **"QuickEdit Mode"** → OK.

For **Windows Terminal** (wt.exe): Settings → Interaction → Disable "Enable mouse input" or set mouse interaction to "pass to application".

### Step 2: $PROFILE Corruption

A module in `$PROFILE` (oh-my-posh, posh-git, PSReadLine, zoxide, etc.) may be hanging during initialization, blocking stdin.

**Test**: Win+R → `powershell -noprofile`

**Fix**: Backup profile and narrow down culprit:
```powershell
Rename-Item $PROFILE "$PROFILE.bak"
```
Restart PowerShell. If fixed, add modules back one by one.

### Step 3: PSReadLine Module Corruption

PSReadLine is the built-in module that handles ALL keyboard input in PowerShell. If it's corrupted, the shell looks normal but keystrokes are silently dropped. This is the most common root cause when Steps 1 and 2 pass.

**Test**: Even `powershell -noprofile` doesn't work (rules out profile), cmd works fine, and new windows also broken.

**Fix**: In **cmd** (not PowerShell), run:
```powershell
powershell -Command "Install-Module PSReadLine -Force -AllowClobber -SkipPublisherCheck"
```
Close ALL PowerShell windows, reopen.

**Verify**: New PowerShell window accepts keyboard input.

### Step 4 (Rare): Console Mode Corruption

If PSReadLine reinstall didn't work, try PowerShell v2 mode (which uses a completely different input stack):
```cmd
powershell -version 2
```
If v2 works, the PSReadLine install itself may have a version mismatch.

## Pitfalls

- **Don't confuse PSReadLine with $PROFILE.** Even `-noprofile` loads PSReadLine. A broken PSReadLine blocks ALL PowerShell, not just the user's profile.
- **Don't reinstall from PowerShell** when the shell itself can't type. Always use `cmd` or `powershell -Command "..."` from cmd.
- **Yellow font after PSReadLine reinstall** is cosmetic — default console color was reset. Run `[Console]::ForegroundColor = 'White'` in the fixed shell to restore, or ignore it.
- **Windows Terminal (wt.exe) RDP focus bug**: On remote desktop, clicking a WT window with the mouse can cause keyboard focus to be swallowed without blocking paste. Fix: Alt+Tab to cycle focus, or `Ctrl+Shift+T` to open a new tab, rather than clicking the window.

## Related

- `hermes-agent` skill has a **Windows-Specific Quirks** section covering UTF-8 BOM, WinError 10106, Alt+Enter behavior, and test suite nuances
