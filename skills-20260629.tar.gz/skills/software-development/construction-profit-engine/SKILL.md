---
name: construction-profit-engine
description: Build and maintain construction profit estimation engines — BOQ parsing, market-price matching, cost decomposition, and profit calculation for Chinese construction projects.
version: 1.0.0
author: Hermes Agent
tags: [construction, profit, cost-estimation, quota, BOQ, engineering]
---

# Construction Profit Estimation Engine

Build an engine that estimates construction project profit from a **工程量清单 (Bill of Quantities / BOQ)** Excel file. The engine parses each line item, matches it to real market prices, decomposes costs (material + labor + machine + overhead), and calculates estimated net profit.

## Core Architecture

```
User Excel (.xlsx)
    │
    ▼
[Parse BOQ]  →  Extract items: code, name, unit, qty, unit-price, total-price
    │
    ▼
[Match Market Prices]  →  For each item, find real material cost:
                          1. Primary: prices.json (住建局信息价)
                          2. Fallback: category-based estimation
                          3. Last resort: percentage of bid total
    │
    ▼
[Cost Decomposition]  →  materialCost + laborCost + machineCost + overhead
    │
    ▼
[Profit Calculation]  →  profit = bidTotal - totalCost - tax
```

## Cost Decomposition Model

```\ntotalCost = materialCost + laborCost + machineCost + overhead\n\nmaterialCost = marketPrice × quantity (with unit conversion)\nlaborCost    = actual worker wages (not quota rates)\n               ≈ 60% of quota labor (when user says 150元/天), or 10-55% of bidTotal per category\nmachineCost  = actual equipment hours × hourly rate (NOT quota × 0.7!)\n               → see references/machinery-efficiency-rates.md\noverhead     = (laborCost + machineCost) × 16%\ntax          = grossProfit × 3% (简易计税)\n```

### Material Cost Rules

| Item Category | Material Cost Source |
|---------------|---------------------|
| Concrete (m³) | 信息价: C20=¥480, C25=¥495, C30=¥510 |
| Rebar (t) | 信息价: Φ≤10=¥3,186, Φ12~14=¥2,920, Φ16~25=¥2,832 |
| Earthwork | ~10% of bidTotal (mostly labor+machine) |
| Stone paving | 80元/m² (granite), 55元/m² (bluestone), 35元/m² (permeable brick) |
| Gravel base | ¥108/m³ |
| Landscaping | Nursery prices per item (e.g., 银杏 ¥900/株, 麦冬 ¥7/m²) |
| Brickwork | ~40% of bidTotal |
| Formwork | ~30% of bidTotal |
| Preserved wood | ~20% of bidTotal |
| Unmatched | ~45% of bidTotal (conservative default) |

### Unit Conversion Pitfall (CRITICAL)

**The #1 cause of inflated material costs.** When the BOQ item's unit differs from the market price's unit, you MUST convert:

| BOQ Unit | Market Price Unit | Conversion |
|----------|-------------------|-----------|
| m² (e.g., 混凝土基层100mm) | m³ | volume = area × thickness(mm) / 1000 |
| 块 (bricks) | 千块 | quantity / 1000 |
| kg (rebar) | t | quantity / 1000 |

**Example:** C25混凝土地面基层100mm, 320m²
- Market price: C25混凝土 = ¥495/m³ (from prices.json)
- Volume = 320m² × 100mm / 1000 = 32m³
- Material cost = ¥495 × 32 = ¥15,840 ✅
- WRONG: ¥495 × 320 = ¥158,400 ❌ (5x inflated!)

### Labor Double-Counting Pitfall (CRITICAL)

**The #2 cause of wrong results.** Never include labor inside the "market price" AND also add laborCost separately.

Rules:
- Market prices from `prices.json` are **RAW MATERIAL prices only** (钢筋多少钱一吨, 混凝土多少钱一立方米). They DO NOT include labor.
- Category-based fallback functions must also return **material-only** prices.
- If a fallback function bundles labor into the per-unit price (like old concretePrice did), it DOUBLE COUNTS when laborCost is added in calculateItem.

**Wrong pattern (v3/v4):**
```js
function concretePrice(item) { 
  return matPrice + laborRate;  // ← WRONG: bundles labor into "material cost"
}
// Then in calculateItem:
materialCost = concretePrice × qty;  // includes labor
laborCost = item.laborCost;          // separate labor → DOUBLE COUNT
```

**Correct pattern (v5):**
```js
function categoryMaterialCost(item) {
  if (/混凝土/.test(n)) {
    // Return material price ONLY
    return { cost: matPrice × volume, source: '混凝土(C25 495元/m³)' };
  }
}
// Then in calculateItem:
materialCost = matResult.cost;        // material only
laborCost = calcLaborCost(item);      // separate labor
// No overlap → correct total
```

## Data Sources

### Primary: 住建局信息价 (prices.json)

Structure:
```json
{
  "四川省": {
    "南江县": {
      "2026-03": [
        {"name": "螺纹钢 HRB400E Φ16～25", "spec": "HRB400E Φ16～25", "unit": "t", "marketPrice": 2831.86, "source": "巴中市住建局2026年3月信息价"},
        {"name": "普通商品砼 C25 碎石最大粒径40mm", "unit": "m3", "marketPrice": 495.0}
      ]
    }
  }
}
```

The loader flatten this into an array (latest period per city) for easy searching.

### Fallback: Category Functions

When `prices.json` doesn't have a match, estimate by category:
- Concrete: C20=480, C25=495, C30=510 元/m³
- Rebar: by diameter (3185 for small, 2831 for medium, 3149 for large)
- Stone: 35-100 元/m² depending on material
- Earthwork: 10% of bidTotal

### Last Resort: Percentage of Bid

For completely unknown items, use 45% of bidTotal as material cost estimate.

## Implementation Pattern

### 1. Parse BOQ Excel

Use `xlsx` library. Auto-detect columns by header keywords:
- "项目编码" → item code
- "项目名称" → item name
- "计量单位" → unit
- "工程量" → quantity
- "综合单价" → bidPrice (unit price)
- "合价" → bidTotal (total price, or computed from qty × unitPrice)
- "人工费" / "定额人工费" → laborCost
- "机械费" / "定额机械费" → machineCost

### 2. Market Price Search

Search `prices.json` by item name. Sort candidates by name length descending (more specific first). Check if item name contains the price entry name, or vice versa.

### 3. Calculate Each Item

For each item (skipping 规费/措施费 items like 安全文明, 夜间施工, 二次搬运):

```
1. Find material price → calc materialCost
2. Estimate laborCost (use actual labor: ~55% of quota, or category-based % of bidTotal)
3. Estimate machineCost (use actual: ~70% of quota, or category-based % of bidTotal)
4. overhead = (labor + machine) × 16%
5. totalCost = material + labor + machine + overhead
6. profit = bidTotal - totalCost
```

### 4. Return Summary

```js
{
  summary: {
    totalBid, totalCost, 
    grossProfit, netProfit, netProfitRate,
    matchStats: { matched, unmatched, skipped, total },
    costBreakdown: { material, labor, machine, overhead }
  },
  items: [ /* per-item detail */ ]
}
```

## Delivery Mode: Direct Agent Calculation Preferred

**This user explicitly rejected building a PWA/website tool.** The user said: *"算了不做程序了 做不出来 直接你帮我算很省事"* (forget building the program, just calculate directly when I ask).

Workflow:
1. User sends the BOQ (Excel or PDF) in the chat
2. Agent extracts items using pymupdf (for PDF) or the existing upload API (for Excel)
3. Agent calls the calculation engine and organizes results
4. Agent presents the profit breakdown by category and highlights top/bottom items
5. If the user says a number is wrong (e.g., "钢筋高了"), adjust the parameter and recalculate

This conversational loop is faster and preferred over building a permanent UI.

## Delivery Mode: Not a PWA

The user also corrected that PWA delivery is not desired: *"不做程序了"* — just calculate on demand in the chat. Do not suggest building a web app, Excel template, or any permanent tool. The value is in the calculation itself, not the packaging.

## User-Period Cost Parameters (四川南江/巴中)

When the user provides actual cost data, use these as overrides:

**Labor (包工模式):**
- Actual labor cost: **150元/人/天** (用户提供)
- Quota daily rate (for cost ratio): **250元/工日** (标准定额)
- Labor cost ratio: 150/250 = 0.6 (60% of quota)

**Concrete (自搅拌 vs 商品砼):**
| Grade | 商品砼 (信息价) | 自搅拌 (用户自报) |
|-------|----------------|-------------------|
| C20 | 480 元/m³ | **280 元/m³** |
| C25 | 495 元/m³ | **300 元/m³** |
| C30 | 510 元/m³ | **320 元/m³** |

Cement price reference: **280元/吨** (用户提供)

**Two Calculation Modes:**

1. **包工模式 (Labor Only):** Revenue = 定额人工费 (from BOQ), cost = 定额人工费 × (150/250), no material costs.
   - Profit = 定额人工费 - 实际工资 - 管理费
   - Example: 琉璃寺口袋公园 → 包工利润¥55,325 (35%)

2. **包工包料 (Full Contract):** Standard material + labor + machine + overhead decomposition.
   - Material: use 自搅拌 prices for concrete, information prices for others
   - Labor: 定额人工费 × (150/250)
   - Machine: 定额机械费 × 0.70
   - Overhead: (labor + machine) × 16%
   - Tax: grossProfit × 3%
   - Example: 琉璃寺口袋公园 → 包工包料利润¥412,665 (37%)

## PDF BOQ Extraction (pymupdf)

Chinese construction BOQ PDFs have a complex two-column layout that breaks pdftotext. Use **pymupdf** directly:

```bash
pip install pymupdf
python3 -c "
import pymupdf
doc = pymupdf.open('boq.pdf')
for page_num in range(len(doc)):
    text = doc[page_num].get_text()
    if '分部分项工程和单价措施项目清单与计价表' in text:
        # Extract items: number → code → name (multi-line) → desc (multi-line) → unit → qty → unitPrice → total → labor → machine
        lines = text.split('\\n')
        # Look for 8-12 digit codes, then collect subsequent data lines
"
```

**Extraction pattern:** Each BOQ item follows: `item_number` → `project_code(8-12 digits)` → `name (multi-line)` → `description (multi-line)` → `unit (m/m2/m3/t/株)` → `quantity` → `unitPrice` → `total` → `laborCost` → `machineCost`.

## Testing & Verification

### Quick Sanity Check

Profit rates for common project types in 四川 (based on 巴中/南江 data):
- 房建: 15-25%
- 市政道路: 10-20%
- 公园绿化: 25-40%
- 桥梁: 10-20%

If the engine shows a LOSS on a real project that was built and profitable, the cost estimates are WRONG. Common causes:
1. **Unit conversion error** (m²→m³ missing) → material cost inflated 5x
2. **Labor double-counting** → cost inflated 10-20%
3. **Hardcoded prices too high** → check against real 住建局信息价
4. **Item classified incorrectly** → check name matching rules

### Debug Method

Print every item's match source to spot problems:
```
挖一般土方         投标6000 成本4498 利润1502 | 土方类(10%)
C25混凝土地面基层100mm 投标17600 成本17447 利润153 | 混凝土(C25 495元/m³) ← thin margin is OK for thin layer
混凝土路缘石         投标8320 成本5057 利润3263 | 路缘石(28元/m估算) ← correctly classified as precast product
```

If any item shows profit of 0 or a match source like "系数兜底", check the name matching rules.

## Pitfalls

- **Unit conversion is not optional**: Every item where BOQ unit ≠ market-price unit needs a conversion rule. Missing conversions produce wildly wrong costs.
- **Labor in prices**: Never embed labor in a function that returns "material price." The `concretePrice` function in v3/v4 bundled labor into the unit price, then calculateItem added labor again separately → 10-20% cost inflation.
- **Rebar classification**: 路缘石 (curb stone) has "混凝土" in its name but is a precast product, not poured concrete. Check for specific product names BEFORE generic category matches.
- **Q&A tool integration**: When the user uploads a BOQ Excel and the API returns results, verify the numbers look sane before presenting them. If something looks off (negative profit on a real project), check the match sources line by line.
- **Caching**: After changing the calculation engine (`quota-calculator.js`), the Next.js build caches the old code in `.next/`. Run `rm -rf .next && npx next build` to force a full rebuild, or the API will serve stale results.
