---
name: proactive-research
description: >-
  When the user mentions an unfamiliar term, tool, service, or concept,
  proactively investigate using available tools (browser navigation, terminal
  API calls, JS bundle inspection, docs sites) before asking the user for
  clarification.
version: 1.0
created_by: agent
---

# Proactive Research

## When to Use

- User mentions a tool, API, service, or concept you don't recognize
- User asks "do you know X" or references something outside your knowledge
- User mentions a configuration option, setting, or feature you haven't seen before
- **You've hit a wall with current tools/approach** — proactively research alternatives instead of asking the user what to use instead

## Steps

1. **Browser search first** — navigate to a search engine (Bing, Google) and search for the term with relevant context
2. **Check the user's configured endpoints** — if their `base_url` points to a custom API, check that site's docs or public config
3. **Inspect SPA bundles** — for single-page apps (Vue/React admin panels), the `__APP_CONFIG__` global in the JS or inline `<script>` tags often contains feature flags and settings (e.g. `hide_ccs_import_button`)
4. **Extract clues from bundled JS** — `curl -s <url> | tr ';' '\\n' | grep -i "<keyword>"` to find feature references in minified JS
5. **Check GitHub** — search repositories for the term. Use `api.github.com/search/repositories?q=<query>&sort=stars` for structured results.
6. **Check the project's docs site** — if it's an open-source project, their docs
7. **Check page source for embedded config** — curl the page and look for `<script>` blocks containing `__APP_CONFIG__`, `window.__`, or inline JSON. Vue SPA pages often embed feature flags directly in the HTML that the snapshot tool can't see
8. **Try direct endpoint checks** — test `/v1/models`, `/api/health`, `/api/v1/status` or similar common public endpoints. Some services expose model lists or status without auth

## Pitfalls

- **Don't ask the user first.** If you haven't tried at least 2-3 research approaches, don't default to "what is X?"
- **Don't give up after one failed search.** Try different search terms, different sites, different angles.
- **SPA pages will appear empty in browser_snapshot** — use `terminal` with `curl` to get the raw HTML and extract the embedded config
- **Chinese API services** may use different names for the same concept (e.g. "CC-Switch" / "CCS" in Sub2API UIs)
- **Wall-hitting = research trigger** — when your current approach fails 3+ times (tool blocked, API unreachable, model underperforms), the right response is NOT to ask "what should I use instead?". Research alternatives proactively and present options with facts (accessible? cost? API support?).
- **Don't ask the user to find tools for you** — the user explicitly said "更好的工具不是你去找？我不知道什么工具啊". Tool discovery is YOUR job.
- **GitHub search for alternative services** — when looking for Chinese AI API relay services, use these search patterns on `api.github.com/search/repositories`:
  - `gpt-image-2 中转`, `gpt-image API 中转站`, `API中转 大模型`
  - `whataicc/gpt-image-api`, `Token173/gpt-image-api` (specific repos)
  - Cross-ref with relay aggregators like `relayradar.dev`, `relaypulse.top`, `hvoy.ai`
- **Don't accept a single API error as final** — HTTP 503 "No available accounts" ≠ dead permanently. It means GPU capacity is temporarily full. Retry 15+ times with 5-second gaps before declaring it dead. 404 "Images API not supported" IS final though.

## User Preference (this user)

This user uses Chinese and expects you to research unknown terms proactively before asking them. They signaled frustration when asked directly about "CC-Switch" instead of being investigated first.
