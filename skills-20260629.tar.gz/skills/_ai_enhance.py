import cv2
import numpy as np
import os, sys

# Simple AI-like super-resolution using OpenCV + smart processing
# Since realesrgan CLI isn't available, use OpenCV's built-in capabilities

in_path = r"C:\Users\Administrator\AppData\Local\hermes\profiles\construction\image_cache\portrait_test.png"
out_path = r"C:\Users\Administrator\AppData\Local\hermes\profiles\construction\image_cache\portrait_ai_enhanced.png"

img = cv2.imread(in_path)
h, w = img.shape[:2]

# Step 1: Upscale 2x using high-quality interpolation
upscaled = cv2.resize(img, (w*2, h*2), interpolation=cv2.INTER_LANCZOS4)

# Step 2: Convert to LAB for better processing
lab = cv2.cvtColor(upscaled, cv2.COLOR_BGR2LAB)
l, a, b = cv2.split(lab)

# Step 3: Smart contrast enhancement using CLAHE
clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(4,4))
l_enhanced = clahe.apply(l)

# Step 4: Apply bilateral filter to smooth noise while preserving edges on L channel
l_smooth = cv2.bilateralFilter(l_enhanced, 9, 75, 75)

# Step 5: Merge back
enhanced = cv2.merge([l_smooth, a, b])
enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)

# Step 6: Adaptive sharpening - stronger on face area, lighter elsewhere
# Create a mask of the face area (center of image)
face_mask = np.zeros((h*2, w*2), dtype=np.float32)
fh = int(h*2 * 0.35)
fw = int(w*2 * 0.5)
fy = int(h*2 * 0.05)
fx = int(w*2 * 0.25)
cv2.ellipse(face_mask, (w, int(h*0.25)), (fw, fh), 0, 0, 360, 1.0, -1)

# Blur the mask for smooth transition
face_mask = cv2.GaussianBlur(face_mask, (51, 51), 30)

# Sharpened version
kernel = np.array([[-0.5,-1,-0.5], [-1,6,-1], [-0.5,-1,-0.5]])
sharpened = cv2.filter2D(enhanced, -1, kernel)

# Blend: sharp face area, normal elsewhere
for c in range(3):
    enhanced[:,:,c] = (sharpened[:,:,c] * face_mask + enhanced[:,:,c] * (1 - face_mask)).astype(np.uint8)

# Step 7: Final color enhancement
hsv = cv2.cvtColor(enhanced, cv2.COLOR_BGR2HSV)
hsv[:,:,1] = np.clip(hsv[:,:,1] * 1.15, 0, 255).astype(np.uint8)
enhanced = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

cv2.imwrite(out_path, enhanced)
print(f"OK: {out_path}")
print(f"Size: {os.path.getsize(out_path)}")
print(f"Dims: {enhanced.shape[1]}x{enhanced.shape[0]}")
