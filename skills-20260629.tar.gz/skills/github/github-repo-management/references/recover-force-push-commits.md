# Recovering Lost Commits After Force Push

## Problem

A force push (`git push --force`) overwrote the remote branch history. The old commits are not accessible via `git log` on the ref, but GitHub **does not immediately garbage-collect** dangling objects. They remain in the object store for some time.

## Recovery Method

### 1. Find Old Commit SHA from PushEvent History

Use GitHub's Events API. Each PushEvent contains `before` (the previous HEAD SHA):

```bash
curl -s -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/events?per_page=30" | \
  python3 -c "
import sys, json
data = json.load(sys.stdin)
for e in reversed(data):
    if e['type'] == 'PushEvent':
        p = e['payload']
        print(f\"时间: {e['created_at']}\")
        print(f\"before: {p['before']}\")
        print(f\"head: {p['head']}\")
        for c in p.get('commits', []):
            print(f\"  {c['sha'][:7]} {c['message'][:60]}\")
        break
"
```

### 2. Verify the Old Commit Exists

GitHub may still serve the old commit even if it's not on any branch:

```bash
curl -s -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/git/commits/$OLD_SHA"
```

If it returns 200 with a `tree` field, the objects are still there. ✅

### 3. Get the Full File Tree

```bash
curl -s -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/$OWNER/$REPO/git/trees/$TREE_SHA?recursive=1"
```

### 4. Restore by Creating a New Branch

Create a branch pointing to the old commit — this makes it visible in the UI and clonable:

```bash
curl -s -X POST -H "Authorization: token $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"ref\":\"refs/heads/restore-old-project\",\"sha\":\"$OLD_SHA\"}" \
  https://api.github.com/repos/$OWNER/$REPO/git/refs
```

Then clone that branch:

```bash
git clone -b restore-old-project --single-branch \
  https://$OWNER:$TOKEN@github.com/$OWNER/$REPO.git /path/to/restore
```

## Why This Works

- GitHub stores all git objects (commits, trees, blobs) in a content-addressable store
- `git push --force` only updates the **ref pointer** — the old objects remain referenced by their SHAs
- GitHub's garbage collection runs periodically (not immediately), so objects are typically available for days to weeks after a force push
- The Events API preserves push journal entries indefinitely, so old `before` SHAs are findable

## Limitations

- If the old push was the **first** push to the repo (before was `0000...`), there's no prior SHA to recover
- If too much time has passed, GitHub may have garbage-collected the dangling objects
- The Events API returns at most 300 events — oldest entries may be dropped
- This only works for commits that were PUSHED; local-only commits that were never pushed cannot be recovered

## Alternative: Local Recovery

If you have a local clone with a reflog:

```bash
git reflog  # shows all local HEAD movements including pulled commits
git checkout <SHA>  # check out a lost commit
git branch recover-this <SHA>  # create a named branch for it
```
