# Pushing to GitHub Through a Chinese HTTP Proxy

## Environment

- **Proxy**: Clash/verge-mihomo at `http://127.0.0.1:7897`
- **Direct TLS**: Fails with `gnutls_handshake() failed: The TLS connection was non-properly terminated.` (Ubuntu gnutls compat issue)
- **Proxy + git push**: Returns `HTTP 408` (Request Timeout) on pushes >~1MB
- **Proxy + curl**: Works fine for REST API calls

## Workaround: Git Data API via curl

Use GitHub's Git Data API (`POST /git/blobs`, `POST /git/trees`, `POST /git/commits`, `PATCH /git/refs`) to bypass the git protocol entirely.

### Full Python script pattern

```python
import subprocess, json, os, base64, time

with open('/root/.config/github-token') as f:
    token = f.read().strip()

repo = 'Owner/RepoName'
branch = 'main'
base_api = f'https://api.github.com/repos/{repo}'
proxy = 'http://127.0.0.1:7897'

def gh(method, endpoint, data=None, data_binary=False, timeout=60):
    """GitHub API call via curl through proxy."""
    cmd = ['curl', '-s', '-X', method, '--proxy', proxy,
           '-H', f'Authorization: token {token}',
           '-H', 'Accept: application/vnd.github.v3+json']
    stdin_data = None
    if data is not None:
        if data_binary:
            # Use stdin pipe to avoid 'Arg list too long' for large base64 blobs
            cmd += ['--data-binary', '@-', '-H', 'Content-Type: application/json']
            stdin_data = json.dumps(data).encode()
        else:
            cmd += ['-d', json.dumps(data)]
    proc = subprocess.run(cmd + [f'{base_api}{endpoint}'],
                         capture_output=True, text=False,
                         input=stdin_data, timeout=timeout)
    return proc.stdout.decode('utf-8', errors='replace')

# Step 1: Get current ref
out = gh('GET', f'/git/refs/heads/{branch}')
ref = json.loads(out)
latest_sha = ref['object']['sha']

# Step 2: Get parent tree
out = gh('GET', f'/git/commits/{latest_sha}')
parent_tree_sha = json.loads(out)['tree']['sha']

# Step 3: Create blobs for each file
blobs = {}
for rel_path, raw_bytes in files:  # your file list
    b64 = base64.b64encode(raw_bytes).decode('ascii')
    out = gh('POST', '/git/blobs',
             data={'content': b64, 'encoding': 'base64'},
             data_binary=True, timeout=300)
    blobs[rel_path] = json.loads(out)['sha']
    time.sleep(0.3)

# Step 4: Get existing tree (keep non-updated files)
out = gh('GET', f'/git/trees/{parent_tree_sha}?recursive=1')
tree_entries = []
for entry in json.loads(out).get('tree', []):
    if not entry['path'].startswith('your-backup-dir/'):
        tree_entries.append({'path': entry['path'],
                             'mode': entry['mode'],
                             'type': entry['type'],
                             'sha': entry['sha']})

# Add new blob entries
for rel_path, sha in blobs.items():
    tree_entries.append({'path': rel_path,
                         'mode': '100644',
                         'type': 'blob',
                         'sha': sha})

# Step 5: Create new tree
out = gh('POST', '/git/trees', data={'tree': tree_entries})
new_tree_sha = json.loads(out)['sha']

# Step 6: Create commit
out = gh('POST', '/git/commits', data={
    'message': 'backup: update via API',
    'tree': new_tree_sha,
    'parents': [latest_sha]
})
new_commit_sha = json.loads(out)['sha']

# Step 7: Update branch ref
out = gh('PATCH', f'/git/refs/heads/{branch}',
         data={'sha': new_commit_sha, 'force': True})
print(json.loads(out).get('ref', 'FAILED'))
```

## Alternative: SSH Through Proxy

Requires SSH key to be added as a **deploy key** to the repo first.

### 1. Generate SSH key
```bash
ssh-keygen -t ed25519 -f ~/.ssh/github_proxy -N ""
```

### 2. Add as deploy key via API (token needs repo scope)
```python
import subprocess, json
with open('/root/.config/github-token') as f: token = f.read().strip()
with open(os.path.expanduser('~/.ssh/github_proxy.pub')) as f: pubkey = f.read().strip()
data = json.dumps({"title": "hermes-push", "key": pubkey, "read_only": False})
subprocess.run(['curl', '-s', '-X', 'POST', '--proxy', 'http://127.0.0.1:7897',
    '-H', f'Authorization: token {token}',
    'https://api.github.com/repos/Owner/Repo/keys', '-d', data], timeout=15)
```

### 3. Configure SSH proxy command
```bash
cat >> ~/.ssh/config << 'EOF'
Host github.com
    HostName github.com
    User git
    IdentityFile ~/.ssh/github_proxy
    ProxyCommand nc -X connect -x 127.0.0.1:7897 %h %p
    StrictHostKeyChecking no
EOF
```

### 4. Push via SSH
```bash
cd /path/to/repo
git remote set-url origin git@github.com:Owner/Repo.git
git push
```

## Pitfalls

- **Git Data API practical blob size limit**: There IS a practical limit. Blobs up to ~500KB raw (666KB base64 JSON) work reliably. Blobs over ~800KB raw (1.1MB+ JSON payload) return HTTP 400 "Bad request" from GitHub, even via `--data-binary @-`. There's no documented limit, but in practice 800KB+ PNG files fail. Workaround: compress large images before backup, or push them separately in smaller batches.
- **Important**: `--data-binary @-` defaults to `Content-Type: application/x-www-form-urlencoded`. GitHub API returns a "Bad request" HTML page with this content type. Always add `-H 'Content-Type: application/json'` when piping JSON via stdin.
- **Args too long**: `subprocess.run` with large `-d` data hits `OSError: [Errno 7] Argument list too long`. Always use `data_binary=True` for base64 blobs >~50KB raw.
- **Rate limiting**: GitHub API has rate limits (5000/hr). Add `time.sleep(0.3)` between blob creations.
- **Token scope**: Fine-grained tokens scoped only to a repo cannot add deploy keys (need `user:keys` scope or `Administration: Write` for the repo). Use classic PAT with `repo` scope for deploy key addition.
- **408 vs TLS fail**: The proxy returns 408 for slow git smart-HTTP uploads. Direct TLS fails because Ubuntu's gnutls has compatibility issues with GitHub's TLS termination. The Git Data API via curl works because curl uses OpenSSL (not gnutls) and the proxy handles CONNECT tunnels differently for proper HTTPS clients.
- **Free-tier git push alternative**: GitHub's Contents API (`PUT /repos/{owner}/{repo}/contents/{path}`) works for individual files under 1MB. For larger files or bulk uploads, the Git Data API (blobs → tree → commit → ref) is the way to go, subject to the practical blob size limit above.
