# quota-calculator.js v5 修复记录

## 问题
原 v3/v4 版硬编码建材价格比巴中实际信息价高 40-50%，导致算出亏损（徐家坝口袋公园显示亏24万）。

## 根因
1. **价格虚高**：钢筋硬编码 4300-4500 元/t，实际巴中 2831-3185 元/t
2. **单位不匹配**：混凝土 m² 项当 m³ 算，材料费多10倍
3. **人工费双重计算**：市场价函数打包了人工，后面又单独加人工
4. **路缘石误分类**：名字带"混凝土"但实际是预制件

## 修复方案（v5）
文件：`/root/my-ai-app/lib/quota-calculator.js`

### 核心改动
1. 优先查 `prices.json`（巴中住建局信息价），匹配不到再走函数估算
2. 材料费 = 纯材料价格（不含人工）
3. 人工/机械费单独估算（定额×55%、定额×70%）
4. 单位换算：m²→m³ 按厚度/1000
5. 路缘石独立分类（28元/m）
6. 土方材料费≈投标×10%（纯土方材料很少）

### 重新构建
```bash
cd /root/my-ai-app
rm -rf .next
npx next build
# 杀掉旧服务器进程，重启
fuser -k 3000/tcp
cd /root/my-ai-app && NODE_ENV=production node node_modules/.bin/next start --port 3000
```

### 测试
```bash
curl -s "http://localhost:3000/api/calculate" \
  -H "Content-Type: application/json" \
  -d '{"projectId":"<id>","taxRate":0.03,"mode":"quota"}'
```
