# GPT Image Relay & GUI Shell Test Results

Last updated: 2026-06-26

## Relay/GUI Services Tested

### lingshuai.cc (灵枢AI)

| Test | Date | Result |
|------|------|--------|
| gpt-image-1 text-to-image | 2026-06-24 | ✅ Success (semi-realistic, Japanese-leaning) |
| gpt-image-2 extreme Q版 | 2026-06-24 | ✅ Success (1:3 chibi, too short) |
| gpt-image-2 balanced donghua | 2026-06-24 | ✅ Success (tall slender, style leaned Japanese) |
| All subsequent gpt-image calls | 2026-06-24→26 | ❌ 503 "No available accounts" |
| Non-Claude text models | 2026-06-26 | ❌ Same 503 — key is Claude-only scope |

**Key finding:** Key `sk-b7f4b6340...` is scoped to Claude models ONLY. The 3 successful gpt-image calls on June 24 consumed the upstream channel's quota, and it's been disabled since.

### img.222250.xyz (GPT Image Generation GUI)

| Test | Date | Result |
|------|------|--------|
| Registration (no CAPTCHA) | 2026-06-24 | ✅ Success |
| Configure gpt-image-2 with OpenAI key (sk-b1516a75e...) | 2026-06-26 | ❌ 401 via api.openai.com (invalid key) |
| Configure gpt-image-2 with lingshuai key | 2026-06-26 | ❌ 404 via lingshuai (Images API not supported) |

**Conclusion:** The GUI shell works but we have no valid upstream key for it.

### 神马聚合中转

| Test | Date | Result |
|------|------|--------|
| Registration check | 2026-06-24 | ❌ Stopped new registration |

### Token173

| Test | Date | Result |
|------|------|--------|
| Domain check | 2026-06-24 | ❌ Server timed out, unreachable |

### Token云桥 (api.0029.org)

| Test | Date | Result |
|------|------|--------|
| Registration (temp email) | 2026-06-24 | ✅ Success |
| gpt-image-2 support (docs) | 2026-06-24 | ✅ Confirmed |
| Payment status | 2026-06-24 | ❌ Payment disabled on main domain |
| Recharge page (jiba.0029.org) | 2026-06-24 | ✅ Found, min ¥100/month |

### Atlas Cloud (atlascloud.ai)

| Test | Date | Result |
|------|------|--------|
| Registration | 2026-06-24 | ❌ Blocked by Cloudflare CAPTCHA |
| Pricing found | 2026-06-24 | gpt-image-2 from $0.009/image |

## Available Key Inventory (2026-06-26)

| Key ID | Source | Works for | Fails for |
|--------|--------|-----------|-----------|
| `sk-b7f4b6340...aa6f` | CC-Switch OpenAI Official / lingshuai config | Claude models via lingshuai | ✗ OpenAI API (401), ✗ lingshuai gpt-image (503), ✗ api.openai.com images (401) |
| `sk-b1516a75e...a5f3` | CC-Switch codex "123" | Nothing confirmed | ✗ lingshuai (401), ✗ api.openai.com (401) |
| `ghp_JU...uVba` | GitHub Models (Azure AI) | gpt-4o vision (auxiliary) | ✗ gpt-image-2 (400 unknown_model), ✗ dall-e-3 (400 unknown_model) |
| Gemini Key | User-owned, not yet configured | Imagen 3 (unconfirmed) | — |
