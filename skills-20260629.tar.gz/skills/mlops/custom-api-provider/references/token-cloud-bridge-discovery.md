# Token云桥 (api.0029.org) Discovery

Discovered: 2026-06-25 via GitHub search (whataicc/gpt-image-api repo)

## Overview

Token云桥 is a Sub2API-based relay service supporting gpt-image-2 via standard OpenAI images API.

- **Website:** https://api.0029.org
- **Documentation:** https://www.0029.org/guide
- **Alternative endpoint (CF proxied):** https://0029.zhongzhuan.wang (note: "生图容易出错，cloudflare超时时间是100秒")

## Registration

- Simple email + password registration
- No email verification required (`email_verify_enabled: false`)
- No free credits on registration (balance starts at $0.00)
- **Payment currently disabled** (`payment_enabled: false`) — cannot recharge

## Confirmed gpt-image-2 Endpoints

From their official documentation (https://www.0029.org/guide):

### Generation
```bash
POST /v1/images/generations
{
  "model": "gpt-image-2",
  "prompt": "...",
  "n": 1,
  "size": "1024x1024"
}
```

### Editing
```bash
POST /v1/images/edits
-F "model=gpt-image-2"
-F "image=@source.png"
-F "prompt=Modify the character to be more slender..."
```

## SPA Routing

Built with Vue.js + Vite. Direct URL navigation (/pricing, /chat, /images) returns 404 — all routes handled client-side from the root path.

## Page Source Config

Extracted from index.html:
- `registration_enabled: true`
- `email_verify_enabled: false`
- `payment_enabled: false`
- `password_reset_enabled: false`
- `turnstile_enabled: false`

## Comparison with lingshuai.cc

| Feature | lingshuai.cc | Token云桥 |
|---------|-------------|-----------|
| Image gen path | /v1/chat/completions (non-standard) | /v1/images/generations (standard) |
| Image edit path | /v1/images/edits | /v1/images/edits |
| GPU availability | 503 (no accounts) | N/A (can't test, no balance) |
| Registration | Via CC-Switch | Email+password |
| Payment | Pre-paid via account | Disabled |
