# Chinese AI API Relay Service Comparison

Source: https://aiproxy.best (discovered 2026-06-26)
Lists 25 Chinese AI API relay/aggregation services with price tier, trust score, channel type, and highlights.

## Top-Rated Services (Trust Score ≥ 40)

| Service | Price | Trust | Channel | Highlights |
|---------|-------|:-----:|:-------:|-----------|
| **OfoxAI** (ofoxai.com) | 8折 | **90** | 官方 | SLA 99.9%, 可退款, 模型已验证 |
| **OpenRouter** (openrouter.ai) | 加价5% | 78 | 官方 | 可退款, 模型已验证, 工商可查 |
| **DMXAPI** (dmxapi.com) | 7折 | 53 | 官方 | SLA 99% (SSVIP), 可退款, 可开票 |
| **云雾API** (yunwuapi.com) | 原价 | 53 | 混合 | SLA 99.9%, 可开票, 工商可查 |
| **API易** (apiyi.com) | 原价 | 51 | 官方 | 可开票 |
| **OhMyGPT** (ohmygpt.com) | 加价10% | 48 | 混合 | 可开票, 工商可查 |
| **302.AI** (302.ai) | 原价 | 48 | 混合 | 工商可查 |
| **ChatfireAPI** (火宝AI) | 原价 | 43 | 官方 | 可开票 |

## Budget Options (Cheapest)

| Service | Price | Trust | Notes |
|---------|:-----:|:-----:|-------|
| **一步API** (yibuapi.com) | **1折** | 25 | 混合渠道, 0门槛, 可开票, SLA 99.9% |
| **YuegleAPI** | **3折** | 13 | 逆向渠道 (unreliable) |
| **GPTGOD** | 加价20% | 16 | 混合渠道 |
| **OfoxAI** | 8折 | 90 | Best quality-price ratio |

## Other Services in Comparison

| Service | Price | Trust | Channel |
|---------|:-----:|:-----:|:-------:|
| CloseAI | 加价50% | 36 | 官方 |
| API2D | 加价50% | 28 | 官方 |
| 柏拉图AI | N/A | 21 | 混合 |
| NekoAPI | 原价 | 13 | 混合 |
| KFCV50 | 原价 | 36 | 官方 |
| 灵芽API | N/A | 18 | 混合 |
| Pro API | 原价 | 8 | 混合 |
| AiHubMix | 原价 | 36 | 混合 |
| V-API | N/A | 5 | 混合 |
| 神马API | N/A | 13 | 混合 |
| APIMart | N/A | 26 | 混合 |
| YuegleAPI | 3折 | 13 | 逆向 |

## Access Notes

- **Cloudflare blocker:** Most of these sites are behind Cloudflare and will time out from the Hermes browser tool. Users need to register from their own browser.
- **API endpoints:** Most are OpenAI-compatible. Test via `/v1/models` first, then `/v1/chat/completions`.
- **gpt-image-2 support:** Not explicitly listed on aiproxy.best. Must be verified by testing `/v1/images/generations` or `/v1/chat/completions` with model name `gpt-image-2`.
- **Payment:** Most support Alipay/WeChat Pay. Minimum top-up varies (often ¥10-¥100).

## Recommended Probing Order

1. aiproxy.best → identify top candidates by trust score + price
2. User registers at chosen service → provides API key
3. Configure in img.222250.xyz or Hermes provider directly
4. Test gpt-image-2 generation
