# Atlas Cloud — Full-Modal AI Platform

URL: https://www.atlascloud.ai
API: https://api.atlascloud.ai/v1 (OpenAI-compatible)
Key Format: `apikey-...`
Discovered: 2026-06-26

## Pricing (from website)

| Model | Text/Image Generation | 
|-------|----------------------|
| gpt-image-2 | $0.009/image |
| gpt-image-2 edit | $0.01/image |
| gpt-image-2 developer (text-to-image) | $0.004/image |
| gpt-image-2 developer (edit) | $0.005/image |
| gpt-5.4-image-2 | Chat-compatible format |
| Various text models | Per-token pricing |

## Registration

- URL: https://www.atlascloud.ai
- **Blocked by Cloudflare** — Hermes browser tool can't load the page (times out). curl through proxy also blocks with "error code: 1010" (Cloudflare).
- **User needs to register from their own browser** → login, create API key
- API Key format: `apikey-<hex>` (not `sk-...`)

## Verdict

**Too expensive for casual use.** Minimum top-up is $25 (~¥180). For occasional image generation (say 50-100 images/month), this is overkill compared to alternatives like AtlasCloud's own web UI or Gemini's free tier.

## Options for Image Generation

| Path | Cost | Requires |
|------|------|----------|
| **Gemini Imagen 3** | Free tier available | Gemini API Key (user has one) |
| **即梦** (Jimeng) | Per-image credits | Already set up, credits may remain |
| **AtlasCloud** | $0.009/image + $25 min top-up | User registers via browser |
| **Img.222250.xyz + relay** | Relay API cost + GUI | Working relay API key |
| **LiblibAI** | Per-generation | Phone registration, SMS code |
