# img.222250.xyz — GPT Image Generation GUI Shell

Discovered/Tested: 2026-06-24 (registration), 2026-06-26 (configuration)
URL: https://img.222250.xyz

## What It Is

A web frontend ("GPT 图片生成") that provides a browser-based GUI for generating and editing images. It does NOT provide its own API — it's a shell that routes requests to user-configured upstream API keys.

## Registration

- **Status:** ✅ Registration successful (2026-06-24), no email verification or CAPTCHA
- **Login:** session-based (cookies), not API-key-based
- **Test account:** testhermes / test123456 (created 2026-06-26)
- **UI language:** Chinese

## Models Available (from `/api/settings/models`)

After login, the settings page lists these models:

| Model Name | Endpoint Type | Needs API Key |
|-----------|--------------|---------------|
| `gpt-image-2` | image-generation | Yes (OpenAI or compatible) |
| `gpt-5.4` | chat-completion | Yes |
| `gpt-5.5` | chat-completion | Yes |
| `grok-imagine-image-lite` | image-generation | Yes (xAI/Grok key) |

## Upstream Key Configuration

Each model has its own `base_url` and `api_key` setting in the `/settings` page. The system automatically appends `/v1/...` to the base URL based on endpoint type:
- **image-generation** → appends `/v1/images/generations`
- **chat-completion** → appends `/v1/chat/completions`

### API Save Endpoint
```bash
POST /api/settings/models
{
  "model_name": "gpt-image-2",
  "base_url": "https://api.openai.com",
  "api_key": "sk-...",
  "keep_api_key": false
}
```

## Test Results with Available Keys (2026-06-26)

| Key | Source | gpt-image-2 Result | Error |
|-----|--------|-------------------|-------|
| `sk-b1516a75e...` | CC-Switch codex "123" | ❌ Failed | HTTP 401 via api.openai.com (Invalid API key) |
| `sk-b7f4b6340...` | lingshuai / CC-Switch OpenAI Official | ❌ Failed | HTTP 401 via api.openai.com (Invalid API key) |
| `sk-b7f4b6340...` | (same) configured with lingshuai base_url | ❌ Failed | HTTP 404 — Images API not supported on lingshuai |

**Conclusion:** Neither locally-stored API key works with img.222250.xyz for image generation. The codex keys are not valid OpenAI API keys, and lingshuai's key doesn't support the images/generations endpoint.

## Image Generation API

Once a model is configured, `/api/generate` requires:
```json
POST /api/generate
{
  "model": "gpt-image-2",
  "prompt": "...",
  "size": "1024x1024",
  "quality": "medium",
  "n": 1
}
```

Returns images as URLs (not base64), served from the img.222250.xyz server.

## Notes

- The site shows user ID formatted as "sk-***" — this is a DISPLAY format, not a usable API key
- No API endpoint is exposed for external use — the site is purely a web GUI tool
- If you have a valid OpenAI API key (or any key that works with /v1/images/generations), img.222250.xyz can serve as a handy frontend for generating and browsing results
