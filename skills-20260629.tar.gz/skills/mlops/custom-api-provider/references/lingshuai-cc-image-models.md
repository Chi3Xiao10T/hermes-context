# lingshuai.cc Image Model Discovery

Discovered: 2026-06-24 via Hermes Agent (deepseek-v4-flash)
Last updated: 2026-06-26

## Platform Identity

- **Site name:** 灵枢AI (Lingshu AI)
- **Domain:** api.lingshuai.cc → CNAME to `cdn.9986oo.net` (IPs: 156.245.245.19, 103.42.30.244, 156.245.245.25, 165.99.43.159)
- **Framework:** Sub2API/NewAPI (Chinese open-source AI API gateway)
- **Detectable via:** `window.__APP_CONFIG__` in page HTML — shows registration, payment, channel monitoring config
- **Server stack:** nginx/1.18.0 (Ubuntu) → Kangle web server (reverse proxy) — detectable via `X-Cache: MISS from kangle web server` response header
- **Web interface:** Vue.js SPA at root domain (pages: /login, /register, /dashboard)
- **Dashboard:** Requires user registration; registration API endpoint unknown (SPA routes return HTML, not JSON)

## Available Image Models on lingshuai.cc

From `/v1/models` response (via OpenAI SDK, GET request):
- **Claude models only** (15 models: claude-3-5-*, claude-opus-4-*, claude-sonnet-4-*, claude-haiku-4-5*, claude-fable-5)
- **NO gpt-image-2 in the model list** — confirmed on 2026-06-26. When gpt-image-2 is NOT in the model list, the platform has no capacity/is not configured for image generation.

## API Access Details

- **Base URL:** `https://api.lingshuai.cc`
- **Auth:** OpenAI-compatible `Authorization: Bearer <key>` header (also accepts `x-api-key` header)
- **Key format:** `sk-b7f4...` (same key used for both Anthropic-messages and OpenAI-chat endpoints)
- **Key scope (confirmed):** The key `sk-b7f4b6340...` is **Claude-only**. All non-Claude model calls return 503.

## Key Behavior Observed (2026-06-24 → 2026-06-26)

### Day 1 (June 24): gpt-image-2 WORKED (3 successful calls via curl)

1. `gpt-image-1` → returned semi-realistic illustration (Japanese-leaning style) ✅
2. `gpt-image-2` extreme Q版 prompt → returned chibi (1:3 head-body) ✅
3. `gpt-image-2` balanced donghua prompt → returned tall slender character ✅

All succeeded via `/v1/images/generations` endpoint with standard bearer auth.

After 3 successful calls → 15+ subsequent calls all returned **503 "No available accounts"**.

### Day 2 (June 25): Persistent 503

All gpt-image-2 calls returned 503. All non-Claude models (gpt-4o, gpt-5.4, dall-e-3, grok-imagine) also returned the same 503.
Claude models intermittently available ("All available accounts exhausted" vs "No available accounts").

### Day 3 (June 26): Service instability

- Claude: 503 "All available accounts exhausted" (intermittent, sometimes works)
- gpt-image-2: 503 "No available accounts" (permanent)
- ALL non-Claude models: same 503
- Service health: `/health` endpoint returns `{"status":"ok"}` but model endpoints unstable
- Connection issues: Goes up and down — sometimes returns 503, sometimes connection reset

### Key Distinction: Two Different 503 Error Messages

| Error | Models affected | Meaning |
|-------|----------------|---------|
| `"All available accounts exhausted"` | Claude only (claude-*) | Accounts EXIST but all in use — temporary concurrency limit. Retry works after a delay. |
| `"No available accounts: no available accounts"` | Everything else (gpt-*, dall-e-*, grok-*) | Accounts DON'T EXIST — upstream channels disabled/depleted. Same key, different backend. |

This ERROR PATTERN confirms lingshuai uses **separate upstream providers** for Claude (AWS Kiro Anthropic) vs non-Claude models (unknown relay/gateway). The non-Claude upstream has been disabled since the quota was consumed on June 24.

## Technical Architecture

### Route Discovery (from JS bundle at `/assets/index-D_vvntId.js`)

The SPA supports extensive admin functionality:
- `admin/channels/` — channel management (model, monitor, pricing)
- `admin/accounts/` — upstream account management
- `admin/dashboard/` — realtime stats, user metrics, model usage
- `admin/affiliates/` — affiliate/invite system
- `admin/backups/` — backup management
- `admin/gemini/oauth` — Gemini OAuth integration

### Web App Config (from inline script in page HTML)

```javascript
window.__APP_CONFIG__ = {
  registration_enabled: true,
  payment_enabled: true,        // Payment system active
  channel_monitor_enabled: true, // Channel health monitoring
  available_channels_enabled: true,
  site_name: "灵枢AI",
  api_base_url: "https://api.lingshuai.cc",
  custom_menu_items: [{ id: "lingshu_ai_assistant", label: "灵枢AI助手" }]
}
```

## Proxy Environment Poisoning — Critical Finding

The terminal/bash environment on this machine has:
```
http_proxy=http://127.0.0.1:7897
https_proxy=http://127.0.0.1:7897
```

**When Clash (the proxy) is NOT running:**
- ALL curl/urllib/requests calls to lingshuai.cc fail with `Connection refused` (curl exit code 7)
- OpenAI SDK silently fails with `APIConnectionError`
- The user sees no error — just "service down"

**When Clash IS running:**
- Requests go through proxy → different IP → lingshuai may behave differently (routing, CDN, geo-blocking)

**Diagnostic:**
1. Check env: `echo "$http_proxy"`
2. Check proxy process: check port 7897
3. Compare with/without proxy: `unset http_proxy https_proxy` → test → restore

## Current Status (as of 2026-06-26)

- ❌ gpt-image-2: 503 "No available accounts" (upstream depleted since June 24)
- ⚠️ Claude models: Intermittent "All available accounts exhausted" (concurrency)
- ⚠️ Direct connection works but unstable (service flapping)
- ❌ Proxy (Clash) not running → All terminal-based calls fail silently
- ⏳ Non-Claude upstream channels may come back if admin replenishes them
