# Sub2API / 灵枢AI Platform Details

Discovered during a Hermes restore + CC-Switch troubleshooting session on Windows.

## Identifying a Sub2API Instance

The lingshuai.cc site (灵枢AI) is a **Sub2API** instance — an open-source API gateway project popular in Chinese AI circles.

Key identifiers in the page HTML:
```javascript
window.__APP_CONFIG__ = {
  site_name: "灵枢AI",
  api_base_url: "https://api.lingshuai.cc",
  // ...
  hide_ccs_import_button: true,  // Hides the "CCS Import" UI
  custom_menu_items: [           // Custom features
    { id: "lingshu_ai_assistant", label: "灵枢AI助手", url: "https://api.lingshuai.cc/lingshu/" }
  ],
  // ...
}
```

## API Mode

These gateways require **Anthropic Messages API format**, not OpenAI chat completions:

```yaml
custom_providers:
- name: lingshu
  base_url: https://api.lingshuai.cc
  api_key: sk-xxx
  api_mode: anthropic_messages   # CRITICAL — not 'openai'
model:
  default: claude-sonnet-4
  provider: lingshu
```

Without `api_mode: anthropic_messages`, the gateway returns protocol errors.

## CC-Switch

CC-Switch is a Sub2API feature that routes between upstream Claude Code subscriptions. The UI has a "CCS import" button that can be hidden by the admin (`hide_ccs_import_button: true`). When configured, Hermes just uses it as a regular Anthropic-compatible API.

## PowerShell Encoding on Windows

When restoring via PowerShell scripts on Windows from git-bash (MSYS2):

1. **UTF-8 BOM needed**: PowerShell 5.1 cannot parse Chinese characters in UTF-8 without BOM
2. **Fix**: `printf '\xef\xbb\xbf' > file.ps1 && cat original.ps1 >> file.ps1`
3. **Invoke from bash**: `cmd //c "powershell -ExecutionPolicy Bypass -File C:\path\to\file.ps1"`
4. **Token file**: Write GitHub PAT to `%USERPROFILE%\.config\github-token` so scripts read it automatically

## Diagnostic Findings (2026-06)

### Available Models (as of 2026-06-18)

Calling `/v1/models` with a valid API key returns:

- `claude-3-5-haiku-20241022`
- `claude-3-5-sonnet-20240620`
- `claude-3-5-sonnet-20241022`
- `claude-3-7-sonnet-20250219`

**Not available:** `claude-opus-4-8-thinking` — not in the model list. If Hermes is configured with this model, it will fail.

### Upstream Failure Pattern

When lingshuai.cc's upstream Anthropic account is broken:

- `/v1/models` → HTTP 200 ✅ (API key valid, gateway alive)
- `/v1/messages` with any model → timeout or HTTP 502 "Upstream access forbidden" ❌

This means: the API key is fine, but the gateway cannot reach Anthropic for actual completions. Contact the lingshuai.cc administrator — no config change on Hermes side will fix this.

The restore-windows.ps1 script from private repo `Chi3Xiao10T/my-ai-app`:
- Checks prerequisites (PS 5.1+, git, curl, tar, hermes)
- Reads GitHub token from `%USERPROFILE%\.config\github-token`
- Tests direct + proxy (Clash/127.0.0.1:7897) connectivity
- Downloads backup archive from `hermes-backup/` path in the repo
- Restores: memories, skills, wiki, config, scripts
- Configures: GitHub token file, QQ Bot, gateway service, CDP desktop script
- The config write is minimal — only the `custom_providers` + `model` sections — so the full config needs manual merging from backup files
