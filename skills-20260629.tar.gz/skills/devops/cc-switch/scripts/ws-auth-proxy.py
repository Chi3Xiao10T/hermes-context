"""WebSocket auth-injecting proxy for tools that can't pass API keys directly.

Reads the API key at runtime from CC-Switch database, then forwards
WebSocket connections to the upstream with Authorization header injected.

Usage:
    python ws-auth-proxy.py [--port 15723] [--provider-id dab0b619...]

The proxy accepts plain ws:// connections from the local tool and forwards
them as wss:// to the upstream with Bearer auth. Use when:
- The tool can't be configured with API key directly (e.g., Codex's
  config.toml api_key field is ignored)
- Hermes secret redaction blocks extracting the key and passing via env var
- The upstream supports WebSocket but the tool needs an auth injection layer

Requirements: pip install websockets
"""

import sqlite3, json, asyncio, websockets, urllib.parse, argparse, os, sys

DB_PATH = os.path.expanduser(r"~\.cc-switch\cc-switch.db")
DEFAULT_PORT = 15723
CLASH_PROXY = "http://127.0.0.1:7897"


def get_key(provider_id):
    db = sqlite3.connect(DB_PATH)
    cursor = db.cursor()
    cursor.execute(
        "SELECT settings_config FROM providers WHERE id=?",
        (provider_id,)
    )
    row = cursor.fetchone()
    if not row:
        db.close()
        raise ValueError(f"Provider '{provider_id}' not found in CC-Switch DB")
    cfg = json.loads(row[0])
    db.close()
    # Codex providers store key under auth.OPENAI_API_KEY
    auth = cfg.get("auth", {})
    if "OPENAI_API_KEY" in auth:
        return auth["OPENAI_API_KEY"]
    # Flat api_key (Hermes-style providers)
    if "api_key" in cfg:
        return cfg["api_key"]
    raise ValueError(f"No API key found in provider '{provider_id}'")


async def ws_handler(websocket_client, path, target, api_key, clash_proxy):
    """Forward WebSocket connection to upstream with auth headers."""
    target_url = target + path
    ws_kwargs = {
        "additional_headers": {"Authorization": f"Bearer {api_key}"},
        "ping_interval": None,
    }
    if clash_proxy:
        pu = urllib.parse.urlparse(clash_proxy)
        ws_kwargs["proxy"] = f"http://{pu.hostname}:{pu.port}"

    try:
        async with websockets.connect(target_url, **ws_kwargs) as ws_target:
            async def forward(src, dst):
                try:
                    async for msg in src:
                        await dst.send(msg)
                except Exception:
                    pass

            await asyncio.gather(
                forward(websocket_client, ws_target),
                forward(ws_target, websocket_client),
            )
    except Exception as e:
        try:
            await websocket_client.close(1011, str(e)[:100])
        except Exception:
            pass


async def main():
    parser = argparse.ArgumentParser(description="WS Auth Proxy")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument("--provider-id", default="dab0b619-a406-4ccb-b4db-ce055bbbc0d4")
    parser.add_argument("--target", default="wss://api.lingshuai.cc")
    parser.add_argument("--no-clash", action="store_true")
    args = parser.parse_args()

    api_key = get_key(args.provider_id)
    clash = None if args.no_clash else CLASH_PROXY

    # Partial application of ws_handler with fixed params
    async def handler(ws, path):
        await ws_handler(ws, path, args.target, api_key, clash)

    server = await websockets.serve(handler, "127.0.0.1", args.port)
    print(
        f"WS Auth Proxy: ws://127.0.0.1:{args.port} → {args.target}"
        f"{' via ' + clash if clash else ''}",
        flush=True,
    )
    await server.wait_closed()


if __name__ == "__main__":
    asyncio.run(main())
