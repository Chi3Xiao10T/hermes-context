"""HTTP + WebSocket bridge for Codex -> lingshuai.cc

Single server on one port handles:
- WebSocket /v1/responses: bridge to lingshuai.cc REST SSE
- HTTP ANY: proxy to lingshuai.cc (models, probes, responses, etc.)

See references/codex-integration.md for full setup instructions.
"""
import asyncio, json, sqlite3, sys
import aiohttp
from aiohttp import web

PORT = 15724
TARGET = "https://api.lingshuai.cc"
CLASH_PROXY = "http://127.0.0.1:7897"

# Read API key from CC-Switch DB
db_path = r"C:\Users\Administrator\.cc-switch\cc-switch.db"
db = sqlite3.connect(db_path)
cursor = db.cursor()
cursor.execute(
    "SELECT settings_config FROM providers "
    "WHERE id='dab0b619-a406-4ccb-b4db-ce055bbbc0d4'"
)
cfg = json.loads(cursor.fetchone()[0])
API_KEY = cfg["auth"]["OPENAI_API_KEY"]
db.close()

masked = API_KEY[:7] + "..." + API_KEY[-4:]
print(f"[bridge] Key: {masked}", flush=True)


# ── HTTP handler (proxy all requests) ───────────────────

async def http_handler(request):
    """Proxy HTTP requests to lingshuai.cc, inject auth, stream response."""
    target_url = TARGET + request.path_qs
    body = await request.read()

    headers = {}
    for name, value in request.headers.items():
        low = name.lower()
        if low in ("host", "connection", "proxy-connection",
                    "transfer-encoding", "upgrade"):
            continue
        headers[name] = value
    headers["Authorization"] = f"Bearer {API_KEY}"

    timeout = aiohttp.ClientTimeout(total=600, connect=30)

    async with aiohttp.ClientSession(timeout=timeout) as session:
        try:
            async with session.request(
                request.method, target_url,
                data=body, headers=headers, proxy=CLASH_PROXY,
            ) as upstream:
                resp = web.StreamResponse(
                    status=upstream.status,
                    headers={
                        k: v for k, v in upstream.headers.items()
                        if k.lower() not in ("transfer-encoding", "connection")
                    },
                )
                await resp.prepare(request)
                async for chunk in upstream.content.iter_chunked(8192):
                    await resp.write(chunk)
                await resp.write_eof()
                return resp
        except aiohttp.ClientError as e:
            return web.Response(status=502, text=str(e))


# ── WebSocket handler (bridge WS -> HTTP SSE) ───────────

async def ws_handler(request):
    """Handle Codex WebSocket connection -> lingshuai.cc REST SSE."""
    ws = web.WebSocketResponse(ping_interval=None)
    await ws.prepare(request)
    print(f"[bridge] WS connected from {request.remote}", flush=True)

    try:
        raw = await asyncio.wait_for(ws.receive(), timeout=30)
        if raw.type != aiohttp.WSMsgType.TEXT:
            print(f"[bridge] WS unexpected msg type: {raw.type}", flush=True)
            return ws

        req = json.loads(raw.data)
        req["stream"] = True
        body = json.dumps(req).encode()
        model = req.get("model", "?")
        input_len = len(str(req.get("input", "")))
        print(f"[bridge] WS model={model}, input_len={input_len}", flush=True)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {API_KEY}",
        }
        timeout = aiohttp.ClientTimeout(total=600, connect=30)

        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post(
                TARGET + "/v1/responses",
                data=body, headers=headers, proxy=CLASH_PROXY,
            ) as upstream:
                print(
                    f"[bridge] WS upstream -> HTTP {upstream.status}, "
                    f"CT: {upstream.headers.get('Content-Type', '?')}",
                    flush=True,
                )

                if upstream.status != 200:
                    err = await upstream.text()
                    print(f"[bridge] WS upstream error: {err[:300]}", flush=True)
                    await ws.send_str(
                        f"event: error\ndata: "
                        f"{json.dumps({'error': err[:500]})}\n\n"
                    )
                    return ws

                event_count = 0
                buffer = ""
                async for chunk in upstream.content.iter_chunked(8192):
                    text = chunk.decode("utf-8", errors="replace")
                    buffer += text
                    while "\n\n" in buffer:
                        event, buffer = buffer.split("\n\n", 1)
                        event = event.strip()
                        if event:
                            await ws.send_str(event + "\n\n")
                            event_count += 1

                if buffer.strip():
                    await ws.send_str(buffer.strip() + "\n\n")
                    event_count += 1

                print(f"[bridge] WS done: {event_count} events", flush=True)

    except asyncio.TimeoutError:
        print(f"[bridge] WS timeout waiting for Codex", flush=True)
    except aiohttp.ClientError as e:
        print(f"[bridge] WS HTTP error: {e}", flush=True)
    except ConnectionResetError:
        print(f"[bridge] WS Codex disconnected", flush=True)
    except Exception as e:
        print(f"[bridge] WS error: {type(e).__name__}: {e}", flush=True)

    return ws


# ── Main ─────────────────────────────────────────────────

async def main():
    app = web.Application()
    app.router.add_route("GET", "/v1/responses", ws_handler)
    app.router.add_route("*", "/{tail:.*}", http_handler)

    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", PORT)
    await site.start()

    print(f"[bridge] Ready on http://127.0.0.1:{PORT}", flush=True)
    print(f"[bridge] -> {TARGET} via {CLASH_PROXY}", flush=True)

    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(main())
