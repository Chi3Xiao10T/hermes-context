# CC-Switch Database Inspection Queries

Quick-reference SQL and Python snippets for inspecting CC-Switch state.

## Dump all proxy config

```sql
SELECT app_type, proxy_enabled, enabled, listen_port, live_takeover_active
FROM proxy_config;
```

## Dump all providers with current status

```sql
SELECT id, app_type, name, is_current FROM providers;
```

## Extract lingshu config (Python)

```python
import sqlite3, json
db = r"C:\Users\Administrator\.cc-switch\cc-switch.db"
conn = sqlite3.connect(db)
cur = conn.cursor()
cur.execute("SELECT settings_config FROM providers WHERE id='lingshu';")
cfg = json.loads(cur.fetchone()[0])
print(f"base_url: {cfg['base_url']}")
print(f"api_mode: {cfg['api_mode']}")
print(f"api_key: {cfg['api_key']}")
print(f"models: {[m['id'] for m in cfg.get('models', [])]}")
conn.close()
```

## Check proxy port availability

```python
import socket
for port in [15721, 49848, 60639]:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    result = sock.connect_ex(('127.0.0.1', port))
    print(f"127.0.0.1:{port}: {'OPEN' if result == 0 else 'CLOSED'}")
    sock.close()
```

## Read latest Hermes backup

```python
import os, glob
backup_dir = r"C:\Users\Administrator\.cc-switch\backups\hermes"
files = sorted(glob.glob(os.path.join(backup_dir, "hermes_*.yaml")), reverse=True)
if files:
    with open(files[0]) as f:
        print(f.read())
```
