"""Diagnose a CC-Switch Hermes provider by testing all API endpoints.

Usage: python diagnose-provider.py [provider_id]
Default provider_id: lingshu

Tests /v1/models, /v1/messages (Anthropic), /chat/completions (OpenAI),
and /responses (Codex) against the provider's base_url with its api_key.
Reports HTTP status and response body for each.
"""

import sqlite3, json, urllib.request, urllib.error, sys, os

DB_PATH = os.path.expandvars(r"%USERPROFILE%\.cc-switch\cc-switch.db")
PROVIDER_ID = sys.argv[1] if len(sys.argv) > 1 else "lingshu"

def get_provider_config(provider_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute(
        "SELECT settings_config FROM providers WHERE id=? AND app_type='hermes'",
        (provider_id,)
    )
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise SystemExit(f"Provider '{provider_id}' not found in CC-Switch DB")
    return json.loads(row[0])

def test(url, data=None, headers=None, timeout=15):
    req = urllib.request.Request(url, data=data, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return resp.status, resp.read().decode()[:500]
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:500]
    except Exception as e:
        return None, f"{type(e).__name__}: {e}"

def main():
    cfg = get_provider_config(PROVIDER_ID)
    base = cfg["base_url"].rstrip("/")
    api_key = cfg["api_key"]
    models = [m.get("id", m.get("name", "?")) 
              for m in cfg.get("models", [])]
    
    print(f"Provider: {PROVIDER_ID}")
    print(f"Base URL: {base}")
    print(f"Key length: {len(api_key)}")
    print(f"api_mode: {cfg.get('api_mode', 'default')}")
    print(f"Models: {models}")
    print()

    # 1. Models list
    print("1. GET /v1/models (Anthropic auth)")
    status, body = test(f"{base}/v1/models", headers={"x-api-key": api_key})
    print(f"   HTTP {status}: {body[:200]}")
    print()

    # 2. Anthropic Messages
    test_model = models[0] if models else "claude-3-7-sonnet-20250219"
    print(f"2. POST /v1/messages (model={test_model})")
    data = json.dumps({
        "model": test_model,
        "max_tokens": 10,
        "messages": [{"role": "user", "content": "hi"}]
    }).encode()
    status, body = test(
        f"{base}/v1/messages",
        data=data,
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json"
        },
        timeout=30
    )
    print(f"   HTTP {status}: {body[:200]}")
    print()

    # 3. OpenAI Chat Completions
    print(f"3. POST /v1/chat/completions (model={test_model})")
    data = json.dumps({
        "model": test_model,
        "max_tokens": 10,
        "messages": [{"role": "user", "content": "hi"}]
    }).encode()
    status, body = test(
        f"{base}/v1/chat/completions",
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "content-type": "application/json"
        },
        timeout=15
    )
    print(f"   HTTP {status}: {body[:200]}")
    print()

    # 4. Responses (codex_responses)
    print(f"4. POST /responses (model={test_model})")
    data = json.dumps({
        "model": test_model,
        "input": [{"role": "user", "content": "hi"}],
        "max_output_tokens": 10
    }).encode()
    status, body = test(
        f"{base}/responses",
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "content-type": "application/json"
        },
        timeout=15
    )
    print(f"   HTTP {status}: {body[:200]}")

if __name__ == "__main__":
    main()
