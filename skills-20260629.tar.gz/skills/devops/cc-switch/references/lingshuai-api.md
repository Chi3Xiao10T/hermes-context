# Lingshuai.cc REST API Internals

The lingshuai.cc web app is a Vue SPA that's too heavy for browser
automation. Use the REST API directly for diagnosis.

## Auth

```
POST /api/v1/auth/login
Content-Type: application/json
{"email": "...", "password": "..."}

Response: {"code": 0, "data": {"access_token": "<jwt>"}}
```

Token goes in `Authorization: Bearer <token>` for all subsequent calls.

## Key inspection

```
GET /api/v1/keys
Authorization: Bearer <token>

Response:
{
  "items": [{
    "id": 2277,
    "user_id": 1501,
    "key": "sk-b7f...",      // actual API key
    "name": "Hermes.",
    "group_id": 21,
    "status": "active",
    "last_used_at": "2026-06-18T17:25:06+08:00",
    "group": {
      "id": 21,
      "name": "默认opus-4.8",
      "description": "（该分组为kiro企业）",
      "platform": "anthropic",
      "rate_multiplier": 0.8,
      "status": "active",
      "subscription_type": "standard"
    }
  }]
}
```

## Key findings from group inspection

- `group.status: "active"` means the group config isn't disabled — it
  does NOT guarantee upstream accounts have capacity
- `group.platform` is the upstream provider (anthropic, openai, etc.)
- `group.description` may hint at the account source (e.g., "kiro企业")

## Error message catalog

| Error | Endpoint | Root cause |
|-------|----------|------------|
| "Upstream access forbidden" (502) | /v1/messages | Anthropic API rejected the upstream account |
| "Upstream service temporarily unavailable" (502) | /v1/messages | Anthropic API unreachable from lingshuai.cc's server |
| "All available accounts exhausted" (503) | /chat/completions, /responses | All upstream API keys in the group are rate-limited or drained |
| "No available accounts" (503) | /v1/messages | No accounts in group can serve the request |
| Timeout (no response) | /v1/messages | TCP connection to upstream hangs — likely IP block or network issue |
| \"no available account\" (WS close 1013) | wss://.../responses | WebSocket upstream pool exhausted (separate from REST pool) |
| HTML returned instead of JSON | /chat/completions | Endpoint not implemented — the SPA catches the route |

## HTTP vs WebSocket: separate account pools (critical)

lingshuai.cc routes REST (HTTP) and WebSocket through **different upstream
account pools**. A successful REST test does NOT guarantee WebSocket will work:

| Protocol | Test | Result example |
|----------|------|----------------|
| REST `POST /responses` | `urllib.request` | HTTP 200 ✓ |
| WS `wss://.../responses` | `websockets.connect()` | Close 1013 "no available account" |

Verified with `websockets` v15 + `additional_headers` parameter: TCP+TLS
handshake succeeds, then server immediately closes with code 1013.

This is why Codex (which requires WebSocket for Responses API) can fail even
when `curl` REST tests against the same endpoint succeed. Only lingshuai.cc
admin can fix the WebSocket upstream pool.

## Diagnosis workflow

1. `GET /v1/models` with `x-api-key` → confirms key is valid
2. `POST /v1/messages` (Anthropic format) → tests the anthropic_messages pathway
3. `POST /v1/chat/completions` (OpenAI format) → tests the OpenAI pathway
4. `POST /responses` (Codex Responses format) → tests the codex_responses REST pathway
5. **WebSocket test** → `websockets.connect()` to `wss://api.lingshuai.cc/responses`
   with auth headers — confirms WS upstream pool separately from REST

If `/v1/models` works but all three POST endpoints fail → upstream issue.
If REST POST works but WebSocket doesn't → WS-specific pool exhaustion.
If `/v1/models` fails with 403 → invalid/expired API key.
