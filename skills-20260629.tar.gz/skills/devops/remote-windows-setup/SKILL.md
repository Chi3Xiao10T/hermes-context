---
name: remote-windows-setup
description: Connect to a remote Windows machine (cloud PC, VPS) via Tailscale VPN + SSH. Covers Tailscale setup on both Linux and Windows, Windows OpenSSH server config, SSH key auth, and file transfer strategies over slow relay connections.
---

# Remote Windows Setup via Tailscale + SSH

Use this when the user has a Windows cloud PC (云电脑) and needs me (the Linux agent) to SSH into it.

## Prerequisites

- Windows cloud PC accessible via RDP/WinAPP (用户买好的云电脑)
- Linux machine with internet (this Hermes agent's host)
- Tailscale is free and works in China (may use relay/DERP servers)

## Step-by-Step

### 1. Install Tailscale on Linux (this machine)

```bash
curl -fsSL https://tailscale.com/install.sh | sh
```

Fix broken deps if needed (common on Ubuntu 22.04 — proxychains4 may conflict):

```bash
apt --fix-broken install -y
apt-get install -y tailscale
systemctl start tailscaled
```

### 2. Get auth URL

```bash
tailscale up
# → https://login.tailscale.com/a/<code>
```

Give the URL to the user — they open it and log in with their GitHub/Google/email account. **Critical**: The Linux machine uses whatever account the user logged in with. The Windows machine must log into the **same** Tailscale account.

### 3. Install Tailscale on Windows

User downloads from https://tailscale.com/download/windows, installs, and logs in with the same account.

### 4. Verify connection

```bash
tailscale status
# Both machines should show up with 100.x.x.x IPs
```

### 5. Enable OpenSSH on Windows

**Method A — PowerShell (quickest):**

```powershell
# Install OpenSSH server (Admin PowerShell)
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# Start and enable
Start-Service sshd
Set-Service -Name sshd -StartupType 'Automatic'

# Firewall rule
New-NetFirewallRule -DisplayName 'OpenSSH Server (sshd)' -Direction Inbound -Protocol TCP -LocalPort 22 -Action Allow
```

**Method B — GUI (if PowerShell unavailable):**
1. Win+R → `services.msc`
2. Find `OpenSSH SSH Server`, start it, set to Automatic
3. Firewall: allow port 22 inbound

### 6. SSH Key Authentication (Recommended)

Generate key on Linux:

```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""
cat ~/.ssh/id_ed25519.pub
```

**On Windows, for Administrator accounts**, OpenSSH reads authorized keys from `C:\ProgramData\ssh\administrators_authorized_keys` (NOT `%USERPROFILE%\.ssh\authorized_keys`). Pass this command for the user to run in Admin PowerShell:

```powershell
$pubkey = "<public key from Linux>"
$keyPath = "C:\ProgramData\ssh\administrators_authorized_keys"
$pubkey | Set-Content -Path $keyPath -Encoding ASCII -NoNewline
icacls $keyPath /inheritance:r /grant "SYSTEM:(R)" /grant "Administrator:(R)"
Restart-Service sshd
```

**Pitfall**: For non-admin users, the path IS `%USERPROFILE%\.ssh\authorized_keys`. For admin users, it MUST be `C:\ProgramData\ssh\administrators_authorized_keys`.

### 7. File Transfer (Big Files)

Tailscale relay connections (DERP) are **very slow** (~4-500 KB/s). For files >1MB:

**Best approach**: Download directly on Windows from a Chinese mirror:

```bash
ssh Admin@<windows_ip> "curl -L -o C:\file.zip https://mirrors.tuna.tsinghua.edu.cn/..."
```

**Alternative — serve from Linux, curl on Windows**:

On Linux:
```bash
python3 -m http.server 8888
```

On Windows:
```bash
curl -o C:\file.zip http://<linux_tailscale_ip>:8888/file.zip
```

**Slow fallback** — base64 pipe through SSH (for files <5MB only):

```bash
ssh -C Admin@<windows_ip> 'powershell -Command "[Convert]::ToBase64String([IO.File]::ReadAllBytes(\"C:\\file.png\"))"' > /tmp/b64.txt
# Then decode on Linux:
base64 -d /tmp/b64.txt > /tmp/file.png
```

### 8. Tailscale Relay Speed Issues

If `tailscale status` shows `relay "xxx"`, the connection goes through a relay server and will be slow. This is normal for cloud PCs behind CGNAT.

Check status:
```bash
tailscale status
# Look for "relay" in the Windows machine's line
```

## Pitfalls

- **Windows Update may break SSH**: After major Windows updates, the OpenSSH service may reset or stop. Check `Get-Service sshd`.
- **iphlpsvc dependency**: Tailscale on Windows may complain about disabled `IP Helper` service. Fix: `services.msc` → start `IP Helper`, set to Automatic.
- **Tailscale MSI安装1603错误（中国云机常见）**: 精简版Windows云机可能缺少MSI安装组件，Tailscale exe和msi都报1603。日志显示 `MainEngineThread is returning 1603` 无进一步细节。这是Windows Installer服务层面的失败，非Tailscale问题。绕过方案：① 用Microsoft Store搜Tailscale安装；② 用 `winget install tailscale.tailscale`；③ 搜索便携版/绿色版。不要反复尝试exe/msi——底层Install服务坏了。
- **PowerShell encoding**: Windows OpenSSH may garble Chinese characters. Use simple ASCII commands or `cmd /c` for reliability.
- **SCP does not work with Windows paths**: Use the HTTP server approach or `curl` transfers instead.
- **BITSAdmin fails without user login**: `bitsadmin /transfer` requires the user to be interactively logged in. Use `curl` instead.
- **Python SSL errors with PoYo API**: Use `curl` via `subprocess.run()` rather than Python `requests` for api.poyo.ai.

## Desktop Browser & App Interaction (from SSH)

When the remote Windows user asks you to open a website in their desktop browser:

### Launch a desktop browser

```bash
# Chrome (most common on cloud PCs)
terminal(background=true, command='"C:/Program Files/Google/Chrome/Application/chrome.exe" "https://example.com"')

# Edge
terminal(background=true, command='cmd.exe /c start msedge https://example.com')

# Internet Explorer (fallback if no other browser)
terminal(background=true, command='"C:/Program Files/Internet Explorer/iexplore.exe" "https://example.com"')
```

The user sees the browser window on their RDP/desktop and can interact with it directly.

### Desktop automation limitation — TWO DISTINCT FAILURE MODES

There are TWO separate failure modes. Know which one you're in.

#### Failure Mode A: RDP disconnected (no active display)

When the RDP session is **disconnected** (user is not connected via Remote Desktop), the Windows session has no active graphical display. This causes:

**Specific failure signals:**
- `pyautogui.screenshot()` → `OSError: screen grab failed`
- `pyautogui.moveTo()` reports success but `pyautogui.position()` stays at `(0, 0)` — no actual mouse movement
- `pyautogui.click()`/`pyautogui.write()` seem to succeed but have zero effect on the UI
- `SetForegroundWindow()` returns Windows error code 0 ("操作成功完成") — a lie, the window didn't actually get focus
- `win32gui.SetForegroundWindow()` → `(0, 'SetForegroundWindow', 'No error message is available')`
- **Chrome DevTools Protocol also fails**: Chrome starts but `--remote-debugging-port=9222` never opens (port shows CLOSED on all interfaces). Reason: Chrome's GPU/renderer processes can't initialize without a display, so the debug socket never binds.

**Root cause**: RDP disconnected → no desktop composition → no GDI/HWND surface for GUI operations → every GUI API either errors out or silently no-ops. This is NOT fixable from code — the display simply doesn't exist.

**What works from SSH even when RDP is disconnected:**
- Launching applications (they start but have no visible window)
- File operations, registry edits, service management
- Headless Chrome (via `--headless=new` flag) — if you don't need the user's login session
- Text-mode operations, `curl`, PowerShell scripts, git

**Fix**: Tell the user to reconnect RDP. Once they do, failure mode A resolves instantly — the display becomes available.

#### Failure Mode B: SSH process cannot set foreground window

Even when RDP is **connected**, PowerShell/Python desktop automation from SSH/background terminal sessions has limitations. Windows blocks background processes from:
- Setting foreground window focus (`SetForegroundWindow` returns `PyGetWindowException: Error code from Windows: 0`)
- Attaching to the console input thread (`AttachThreadInput` fails)

**What DOES work from SSH when RDP is connected:**
- `pyautogui.moveTo()` and `pyautogui.click()` — these send Windows input events that work regardless of which process owns the foreground
- `pyautogui.write()` — keyboard input
- `uiautomation` — UIA can find windows and interact with controls (but NOT with GPU-rendered web content in Chrome)
- Chrome DevTools Protocol — launch Chrome with CDP flags (see next section)
- Application launching (opens on the user's visible desktop)
- File operations, registry edits, service management

**Note**: When RDP is connected, you CAN use pyautogui for mouse/keyboard automation. The limitation is only on `SetForegroundWindow`. Disable `pyautogui.FAILSAFE = False` to avoid false positives from corner detection.

### Chrome DevTools Protocol (CDP) — Remote Browser Control

Use this for programmatic control of the desktop Chrome browser when RDP is active. Works via websocket connection, bypasses all GUI automation constraints.

#### Setup

```bash
# 1. Kill all existing Chrome processes first
# (Alternatively, kill only the main process to force Chrome to stop)
powershell.exe -Command 'Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force'

# 2. Launch Chrome with remote debugging port USING Python subprocess
# (bash/MSYS may mangle path arguments; use Python for reliability)
python -c "
import subprocess
chrome_path = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
user_data = r'C:\Users\$env:USERNAME\AppData\Local\Google\Chrome\User Data'
cmd = [
    chrome_path,
    '--remote-debugging-port=9222',
    '--remote-allow-origins=*',
    f'--user-data-dir={user_data}',
    '--no-first-run',
    'https://target-url.com'
]
subprocess.Popen(cmd)
"
```

#### Critical CDP flags

| Flag | Why |
|------|-----|
| `--remote-debugging-port=9222` | Opens the Debugging port |
| `--remote-allow-origins=*` | Required on Chrome 112+ to allow websocket connections |
| `--user-data-dir=<path>` | Must match the user's existing profile to preserve cookies/sessions |
| `--no-first-run` | Suppresses first-run dialogs that block page load |

#### Verification

```python
import urllib.request, json
resp = urllib.request.urlopen('http://localhost:9222/json/version', timeout=5)
data = json.loads(resp.read())
# data['webSocketDebuggerUrl'] gives the ws:// endpoint for puppeteer/selenium
```

#### CDP fails on disconnected RDP

If the user is NOT currently connected via RDP, the debug port will NOT open even though Chrome launches. See Failure Mode A above. The only solution is to ask the user to reconnect RDP.

### What DOES work from SSH (both RDP states):
- File operations, registry edits, service management
- System configuration via PowerShell
- `curl`, `git`, and other CLI tools

### QR-code-sharing pattern

For services that require QR code login (WeChat, Douyin, Jimeng AI, etc.):

1. Use your browser tool to navigate to the login page
2. Navigate to a lightweight subpage (not the main SPA entry) — e.g., for Jimeng use `/ai-tool/home` not the bare domain
3. Click through to the QR code display: 登录 → 抖音登录 → 同意协议
4. Take a screenshot with `browser_vision()` and share via `MEDIA:<screenshot_path>` in your response
5. Tell the user to scan quickly — QR codes have short expiry (~2-3 minutes)
6. **IMPORTANT**: Do NOT navigate away from the QR code page after the user scans. Check the current page state without refreshing. If you navigate, the session cookie may be lost.

### Chinese AI tool login pattern

Many Chinese AI image/video tools (Jimeng/即梦, Tongyi Wanxiang/通义万相, Kling/可灵) require Douyin (抖音) or WeChat QR code login. The workflow:
1. Open the tool in the user's desktop browser via `terminal(background=true)` with the chrome.exe path
2. User logs in themselves (scan QR code on their phone)
3. Once logged in, user directly operates the tool's UI while you guide them via chat

For generating prompts that the user pastes in: use English prompts for better results with Chinese AI tools (they handle English well and avoid prompt injection issues from Chinese-to-English translation).
