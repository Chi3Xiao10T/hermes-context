# CC Switch — 多 AI 编码工具订阅管理器

## 是什么

CC Switch（`cc-switch.exe`）是一个 **Tauri 桌面 GUI 应用**（类似 Electron 但更轻量），用于统一管理和切换多种 AI 编码工具的订阅/账号。

由 `ccswitch` 开发，当前版本 3.16.3。

## 支持的提供商

| 提供商 | app_type | 说明 |
|--------|----------|------|
| Claude Code | `claude` | Anthropic Claude Code 订阅 |
| Claude Desktop | `claude-desktop` | Claude 桌面版 |
| OpenAI Codex | `codex` | OpenAI Codex OAuth |
| Google Gemini | `gemini` | Google Gemini |
| Hermes | `hermes` | **Hermes Agent 自定义 provider**（如灵枢） |

## 安装位置

| 路径 | 说明 |
|------|------|
| `%LOCALAPPDATA%\Programs\CC Switch\cc-switch.exe` | 主程序 (34MB) |
| `%LOCALAPPDATA%\com.ccswitch.desktop` | 本地数据 |
| `%APPDATA%\com.ccswitch.desktop` | 漫游数据 |
| `%USERPROFILE%\.cc-switch\cc-switch.db` | **SQLite 数据库** |
| `%USERPROFILE%\.cc-switch\logs\cc-switch.log` | **运行日志** |
| 桌面快捷方式 | `ApplicationShortcutDesktop` |
| 开始菜单 | `ApplicationProgramsFolder\CC Switch` |

## 工作原理

### 代理模式（核心功能）

CC Switch 在本地启动一个 **HTTP 代理服务器**（默认端口 `15721`），支持三种提供商各自的代理配置：

```sql
-- proxy_config 表结构
app_type IN ('claude', 'codex', 'gemini')  -- 有 CHECK 约束，不支持 hermes 直接写
enabled           -- 代理开关
proxy_enabled     -- 同等开关（冗余）
listen_address    -- 127.0.0.1
listen_port       -- 15721
auto_failover_enabled  -- 自动故障切换
```

**工作流程：**
1. CC Switch 代理在 `127.0.0.1:15721` 监听
2. Hermes/Claude/Codex 将 API 请求指向该代理
3. 代理根据当前选中的 provider 转发到对应后端
4. 用户在 CC Switch GUI 中点一下即可切换

### 数据库激活代理

```python
import sqlite3
conn = sqlite3.connect(r"C:\Users\<user>\.cc-switch\cc-switch.db")
cursor.execute("UPDATE proxy_config SET enabled = 1, proxy_enabled = 1;")
conn.commit()
# 然后重启 cc-switch.exe 使配置生效
```

### 与 Hermes 的集成

CC Switch **启动时自动扫描** Hermes 配置，发现自定义 provider 后存入数据库：

```
[DEBUG][cc_switch_lib] Hermes provider 'lingshu' already exists in database, skipping
```

扫描完成后 Hermes provider 信息存储在：
- `providers` 表：`app_type='hermes'`，`id='lingshu'`
- `provider_endpoints` 表：URL 和 provider 映射
- `stream_check_logs` 表：连接健康检查记录

## 从 MSI 安装包分析

```python
import msilib
db = msilib.OpenDatabase(msi_path, msilib.MSIDBOPEN_READONLY)

# 获取产品信息
view = db.OpenView("SELECT `Property`, `Value` FROM `Property`")
# → ProductName, Manufacturer(ccswitch), ProductVersion(3.16.3)

# 查看安装的文件
view = db.OpenView("SELECT `File`, `FileName`, `Component_` FROM `File`")
# → cc-switch.exe (34MB, Tauri app)

# 查看功能特性
view = db.OpenView("SELECT `Feature`, `Title`, `Description` FROM `Feature`")
# → MainProgram: "Installs CC Switch."
# → Environment: PATH 环境变量
# → ShortcutsFeature: 快捷方式
```

程序启动后会：
1. 注入 AppHandle，启用事件推送
2. 插入默认模型定价数据（约 159 条）
3. 从各工具（Claude、Codex、Gemini、Hermes）导入已有的 provider
4. 注册 deep-link URL handler
5. 初始化 CopilotAuthManager + CodexOAuthManager
6. 显示主窗口

## 已验证的局限性

### ❌ 直接切换 Hermes provider 无效
修改 `config.yaml` 将 `provider` 切换为 `lingshu`（自定义 provider），重启 Hermes 后无法正常工作。原因是灵枢 API 的 `api_mode: anthropic_messages` 可能需要特殊的代理处理才能正确路由请求。用户确认「之前试过不行」。

### ❌ CC-Switch 代理不代理 Hermes
端口 `15721` 的代理服务器是 Claude/Codex/Gemini 专用的：
- `proxy_config` 表有 `CHECK(app_type IN ('claude','codex','gemini'))` 约束
- Hermes provider 虽然出现在 CC-Switch 数据库的 `providers` 表中，但只能用于**展示管理**，不能通过 CC-Switch 代理转发
- 测试结果：代理启动后 `GET /v1/models` → `{"models":[]}`，发送 chat completion 请求无响应

### ⚠️ 那 CC-Switch 的 Hermes 集成到底有什么用？
目前观察到的现象：
- CC-Switch **启动时自动扫描** Hermes 配置，将自定义 provider 信息存入数据库
- 数据库中记录了 provider 的 base_url、api_key、api_mode
- CC-Switch 可以**检测/监控** Hermes 配置，也可以测试连接（`stream_check_logs` 表记录可达性）
- 但 CC-Switch **不提供**对 Hermes provider 的代理转发或配置写入功能

**推测结论：** CC-Switch 对 Hermes 的支持目前是**只读/监控**级别的。可以在 GUI 中看到 Hermes provider 的状态和健康检查，但不能通过 CC-Switch 切换 Hermes 当前使用的模型提供商。Hermes 与 CC-Switch 的深层集成可能需要在 CC-Switch GUI 中手动操作（如点击「启用」按钮）。

### 正确做法总结
1. CC-Switch 代理端口 `15721` — 给 Claude Code 用的，不要试图把 Hermes 指向它
2. 直接改 `config.yaml` 切 provider — 用户确认试过不行
3. 如果 CC-Switch GUI 中有「启用 Hermes provider」按钮，可能需要在 GUI 中操作
4. 当前最可行的路径：保持 DeepSeek 默认，CC-Switch 用作 Claude/Codex 管理

## 相关路径备忘

| 项目 | 路径 |
|------|------|
| MSI 安装包 | `/tmp/CC Switch-3.16.3-updater-RPTAh5/CC Switch-3.16.3-installer.msi` (16MB) |
| 可执行文件 | `%LOCALAPPDATA%\Programs\CC Switch\cc-switch.exe` (34MB) |
| 数据库 | `%USERPROFILE%\.cc-switch\cc-switch.db` |
| 日志 | `%USERPROFILE%\.cc-switch\logs\cc-switch.log` |
