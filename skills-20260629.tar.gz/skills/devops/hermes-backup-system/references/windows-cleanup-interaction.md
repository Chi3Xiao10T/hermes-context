# Windows 清理交互模式

## 用户偏好（二哥）

### 清理前必做
1. **先打全量备份** — `tar czf ~/hermes-full-backup-$(date +%Y%m%d_%H%M%S).tar.gz --exclude="*/venv" --exclude="*/cache" %LOCALAPPDATA%/hermes/`
2. **分类展示所有待删项** — 不要逐个文件问，一次列清楚：
   ```
   | 类别 | 数量 | 说明 |
   |------|------|------|
   | 嵌套重复 | 738个 | skills/skills/，解压多套一层 |
   | 安装日志 | 109个 | winget 安装日志，一次性 |
   | 旧路径副本 | 701个 | ~/.hermes/，AppData 全有 |
   ```
3. **每类给出"为什么是垃圾"的理由**
4. **问一次"能删吗？"** 不要一个一个确认

### 当用户拦 rm 命令时
- 用户会拦 rm 命令 → **不要硬删也不要重复试**
- 改为 `mv target /tmp/safekeeping-folder` 移到安全位置
- 解释：东西还在 /tmp 里，确认没问题后再清

### /tmp 里的文件提示
- `/tmp/` 下可能有用户的**作业文件**（cdp_*.py、截图 *.jpg、JSON 数据、MD 笔记等）
- 不要凭文件名归类为"垃圾"
- 不确定时列出分组问用户
- 用户态度：全保留

### 确认用户称呼
- USER.md 恢复后必须读内容确认称呼（如"叫我'二哥'"）
- 小橙是 AI 自己的名字，不是用户名字
- 称呼错了在信任上很伤

## CC-Switch 类型未知软件的调查方法

当用户安装了一个未知软件（如 CC Switch-3.16.3）且不知道怎么用时：

### 第一步：找安装包
- 检查 `/tmp/` 下有无 MSI/ZIP 安装包
- 检查 `%LOCALAPPDATA%/Programs/` 下有无安装后的目录

### 第二步：分析 MSI 安装包
```python
import msilib
db = msilib.OpenDatabase(msi_path, msilib.MSIDBOPEN_READONLY)
view = db.OpenView("SELECT `Property`, `Value` FROM `Property`")
# → ProductName, Manufacturer, ProductVersion
view = db.OpenView("SELECT `File`, `FileName`, `Component_` FROM `File"`)
# → 看装了什么可执行文件
view = db.OpenView("SELECT `Feature`, `Title`, `Description` FROM `Feature"`)
# → 功能描述
```

### 第三步：看日志
- `~/.app-name/logs/app-name.log` — 日志揭示真实功能
- 关键信号：import 了哪些 provider、数据库操作、网络请求

### 第四步：看数据库
- `~/.app-name/app-name.db` — SQLite，查表结构和内容
```sql
SELECT name FROM sqlite_master WHERE type='table';
SELECT * FROM <table> LIMIT 10;
```

### 第五步：看运行表现
- 用 `Get-Process | Where-Object MainWindowTitle` 看窗口标题
- 用 `netstat -ano` 看是否开了本地端口
- Tauri 应用通常管理多个 AI 编码工具账号的订阅/切换
