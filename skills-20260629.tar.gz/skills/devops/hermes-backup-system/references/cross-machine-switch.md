# 跨机上下文同步

> 2026-06-27 实操记录：旧机→新机 Hermes 切换时，通过 GitHub 公开仓库传递会话上下文。

## 场景

用户有两台 Windows 机器：
- **旧机**（2核4G，无GPU，QQ Bot 日常）
- **新机**（有GPU，用于剪映/画图等重任务）

需要在机器间切换 Hermes 会话时，传递当前任务上下文 + 记忆 + 用户画像。

## 先决条件

- GitHub Token（`ghp_` 开头，40位）存 `~/.config/github-token`
- Token 只需 `repo` scope（不需要 gist）
- 上下文 repo 设为**公开**（新机无 token 也能拉 raw）

## 推送流程（旧机 → GitHub）

### 1. 写上下文文件

```python
# switch-context.md 内容模板
"""# 项目名 - 当前任务上下文

## 当前状态
- 已完成的工作
- 卡住的地方
- 4张待抠图层路径

## 需要做的
1. 剪映智能抠图
2. 合成动态漫
3. 配音

## 关键文件路径（新机上）
- 桌面/项目/图层/
- 桌面/项目/分镜/

## 环境
- 新机有GPU，装剪映
- Hermes 路径: C:\Users\Administrator\AppData\Local\hermes\hermes-agent\venv\
"""
```

### 2. 通过 API 上传（无需 git clone）

国内网络 git clone 经常超时，直接用 GitHub REST API PUT /contents/ 上传：

```python
import subprocess, json, os, base64

token_path = os.path.expanduser("~/.config/github-token")
with open(token_path) as f:
    token = f.read().strip()

def upload_file(repo, path, content, message="switch"):
    encoded = base64.b64encode(content.encode()).decode()
    result = subprocess.run([
        "curl", "-s", "-X", "PUT",
        f"https://api.github.com/repos/Chi3Xiao10T/{repo}/contents/{path}",
        "-H", f"Authorization: token {token}",
        "-H", "Accept: application/vnd.github+json",
        "-d", json.dumps({"message": message, "content": encoded})
    ], capture_output=True, text=True, timeout=30)
    return json.loads(result.stdout)

# 创建 repo（首次）
result = subprocess.run([
    "curl", "-s", "-X", "POST",
    "https://api.github.com/user/repos",
    "-H", f"Authorization: token {token}",
    "-H", "Accept: application/vnd.github+json",
    "-d", json.dumps({
        "name": "hermes-context",
        "private": True,
        "auto_init": True
    })
], capture_output=True, text=True, timeout=30)

# 设为公开
subprocess.run([
    "curl", "-s", "-X", "PATCH",
    f"https://api.github.com/repos/Chi3Xiao10T/hermes-context",
    "-H", f"Authorization: token {token}",
    "-d", json.dumps({"private": False})
], capture_output=True, text=True)

# 上传文件
upload_file("hermes-context", "context/switch-context.md", context_content)
upload_file("hermes-context", "memory/MEMORY.md", memory_content)
upload_file("hermes-context", "memory/USER.md", user_content)
```

### 3. 验证

```bash
curl -s https://raw.githubusercontent.com/Chi3Xiao10T/hermes-context/main/context/switch-context.md | head -20
```

## 拉取流程（新机 ← GitHub）

新机 Hermes 启动后，首次对话：

```bash
# 拉上下文
curl -sL https://raw.githubusercontent.com/Chi3Xiao10T/hermes-context/main/context/switch-context.md -o /tmp/ctx.md

# 拉记忆
curl -sL https://raw.githubusercontent.com/Chi3Xiao10T/hermes-context/main/memory/MEMORY.md -o /tmp/mem.md
curl -sL https://raw.githubusercontent.com/Chi3Xiao10T/hermes-context/main/memory/USER.md -o /tmp/user.md

# 注入记忆
# 然后用 memory action=add 写入
```

## 切换步骤（用户操作）

1. 旧机：关掉 Hermes（/stop 或关窗口）
2. 新机：`hermes run` 启动
3. 新机：发一条消息（如"继续"）
4. Agent 自动：curl GitHub → 注入记忆 → 恢复任务

## 二进制资产上传（图片等）

当跨机任务涉及图片/视频等二进制文件时，需一并上传：

```python
import urllib.request, urllib.parse, base64, json

# 中文文件名必须 URL-encode
remote_path = f"assets/{fname}"
encoded_path = urllib.parse.quote(remote_path, safe='/')

with open(local_path, "rb") as f:
    content = f.read()
encoded = base64.b64encode(content).decode()

data = json.dumps({"message": f"Add {remote_path}", "content": encoded}).encode()
req = urllib.request.Request(
    f"https://api.github.com/repos/Chi3Xiao10T/hermes-context/contents/{encoded_path}",
    data=data, headers={
        "Authorization": f"token {token}",
        "Accept": "application/vnd.github+json",
        "Content-Type": "application/json",
    }, method="PUT")
```

**注意：** `subprocess.run() + curl` 对大文件会触发 Windows `WinError 206 文件名或扩展名太长`（base64 payload 超过命令行长度限制）。>1MB 文件必须用 Python `urllib` 直发。

## CodeX 配置跨机迁移

> 2026-06-28：用户从旧机迁移 CodeX 到新机 GPU 机器。

CodeX 最小配置包（无需全量 `.codex/` 目录）：

```bash
cd ~/.codex && tar -czf codex_config.tar.gz config.toml auth.json installation_id version.json
```

四个文件说明：
| 文件 | 内容 |
|:-----|:-----|
| `config.toml` | 模型配置（provider, base_url, model, CUA 插件） |
| `auth.json` | API Key（`{"OPENAI_API_KEY": "sk-..."}`） |
| `installation_id` | CodeX 安装标识 |
| `version.json` | 版本信息 |

传输后解压到新机 `~/.codex/`，CodeX 会自动下载缺失的 runtimes/plugins。

## API Key 安全传输

终端和 read_file 会截断 API Key 显示为 `sk-xxx...xxx`。传输完整 Key 用 base64：

```bash
# 编码（旧机）
python -c "import json,base64; f=open('.codex/auth.json'); k=json.load(f)['OPENAI_API_KEY']; print(base64.b64encode(k.encode()).decode())"

# 解码（新机）
echo "c2stYjE1..." | base64 -d
```

## 踩坑记录

| 问题 | 根因 | 解决 |
|:-----|:-----|:-----|
| 建 gist 返回 404 | Token 只有 `repo` scope，无 `gist` scope | 改用 repo + PUT /contents/ API |
| `execute_code` 路径报错 | 沙箱用 Windows native 路径，terminal 用 MSYS 路径 | `os.path.expanduser("~/AppData/Local/...")` |
| git clone 超时 | 国内网络，git over HTTPS 不稳 | 完全绕过 git，用 curl + GitHub REST API |
| 新机无 token 无法拉私有 repo | 私有 repo 需要 auth | 上传后 patch repo 为 public |
| 中文文件名上传 400 | URL 中中文字符未编码 | `urllib.parse.quote(path, safe='/')` |
| curl 上传大文件 WinError 206 | base64 payload 超过 Windows 命令行 32K 限制 | >1MB 文件用 Python urllib，不用 subprocess+curl |

## 安全

- 上下文文件不含 token/密钥
- 记忆文件只含 token 路径（不含值）
- repo 公开仅存上下文，无敏感数据
- API Key 传输后清理临时文件（如 `codex_key.txt`）
