# state.db 会话新鲜度检查

恢复后，新机器上的 state.db **仅包含当前正在进行的会话**。所有历史会话只在 GitHub 备份仓库中。

## Python 查询

```python
import sqlite3, datetime

conn = sqlite3.connect(r"C:\Users\Administrator\AppData\Local\hermes\state.db")
c = conn.cursor()

# 会话总数
c.execute("SELECT COUNT(*) FROM sessions;")
print(f"会话数: {c.fetchone()[0]}")

# 消息时间范围
c.execute("SELECT MIN(timestamp), MAX(timestamp) FROM messages;")
start, end = c.fetchone()
if start:
    print(f"最早消息 (UTC): {datetime.datetime.utcfromtimestamp(start)}")
    print(f"最新消息 (UTC): {datetime.datetime.utcfromtimestamp(end)}")
    print(f"最早消息 (本地+8): {datetime.datetime.fromtimestamp(start)}")
    print(f"最新消息 (本地+8): {datetime.datetime.fromtimestamp(end)}")

# 按本地日期分组（UTC+8，中国时区）
c.execute("""
    SELECT DATE(timestamp, 'unixepoch', '+8 hours') as d, COUNT(*)
    FROM messages GROUP BY d ORDER BY d;
""")
for d, cnt in c.fetchall():
    print(f"  {d}: {cnt} 条消息")

# 会话标题和起始时间
c.execute("""
    SELECT id, title, started_at, message_count
    FROM sessions ORDER BY started_at DESC;
""")
for sid, title, started, count in c.fetchall():
    dt = datetime.datetime.fromtimestamp(started)
    print(f"\n会话: {title}")
    print(f"  开始: {dt}")
    print(f"  消息数: {count}")

conn.close()
```

## 预期结果（恢复后的典型状态）

```
会话数: 1
最早消息 (本地+8): 2026-06-18 02:38:45
最新消息 (本地+8): 2026-06-18 12:48:31

  2026-06-18: 404 条消息

会话: Hermes Agent Introduction
  开始: 2026-06-18 02:38:45
  消息数: 404
```

即：只有当前会话。所有历史在 GitHub 备份的 `chat-history.db.gz` 中。

## 汇报给用户的公式

> "GitHub 仓库最后提交: Backup **YYYYMMDD**（M月D日）。今天日期: YYYY年M月D日。未备份的数据范围: M月D日 ~ M月D日（N天）。包含: 这些会话中的记忆和技能变更可能未提交。"
