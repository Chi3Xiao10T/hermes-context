# Agent 级数据恢复流程

## 触发条件

当你（小橙）需要查用户之前聊过的内容，但 **`session_search` 返回空结果** 时：

1. 这台机器被重置过（新机器），旧的 `state.db` 丢了
2. 当前 session 的早期内容被压缩成摘要，原始消息不在 DB 中
3. Session DB 只有最近压缩窗口内的消息

**不要对用户说"新的机器没有留存"或"我没之前的记录"** — 用户有 GitHub 备份。

## 标准恢复流程

### 0. 先试 session_search

```python
from hermes_tools import session_search
result = session_search(query="关键词")
```

如果为空，继续往下走。

### 1. 确认备份仓库可访问

```python
# ⚠️ 不要在 bash heredoc 里混用 $(cat ~/token) 读 token
# bash 会把 $(...) 解析为命令执行，导致 Python 语法错误
# 正确做法：写 .py 脚本文件，用 open() 读 token 文件

import os
with open(os.path.expanduser('~/.config/github-token')) as f:
    TOKEN = f.read().strip()

import subprocess
r = subprocess.run(['curl', '-s',
    '-H', f'Authorization: token {TOKEN}',
    '-H', 'Accept: application/vnd.github.v3+json',
    'https://api.github.com/repos/Chi3Xiao10T/my-ai-app/contents/hermes-backup'],
    capture_output=True, text=True, timeout=15)
print(r.stdout[:500])
```

### 2. 下载聊天记录备份

**推荐方案（实测可靠）：用 GitHub API raw endpoint + `Authorization` Header**

```python
import subprocess, os

with open(os.path.expanduser('~/.config/github-token')) as f:
    TOKEN = f.read().strip()

headers = [
    '-H', f'Authorization: token {TOKEN}',
    '-H', 'Accept: application/vnd.github.v3.raw'
]
env = os.environ.copy()
env['http_proxy'] = 'http://127.0.0.1:7897'
env['https_proxy'] = 'http://127.0.0.1:7897'

r = subprocess.run(['curl', '-sL', '-o', '/tmp/backup.db.gz'] + headers + [
    'https://api.github.com/repos/Chi3Xiao10T/my-ai-app/contents/hermes-backup/chat-history/chat-history.db.gz?ref=main'
], capture_output=True, text=True, timeout=60, env=env)
print('Size:', os.path.getsize('/tmp/backup.db.gz'))
```

**不推荐方案（容易失败）：**

```bash
# ❌ 依赖 token=xxx 查询参数，私有仓库不认
# ❌ raw.githubusercontent.com 国内可能超时
curl -sL -o backup.db.gz \
  "https://raw.githubusercontent.com/Chi3Xiao10T/my-ai-app/main/hermes-backup/chat-history/chat-history.db.gz?token=xxx"
```

### 3. 解压 + SQLite 查询

```python
import gzip, sqlite3
with gzip.open('/tmp/backup.db.gz', 'rb') as f_in:
    with open('/tmp/restored.db', 'wb') as f_out:
        f_out.write(f_in.read())

db = sqlite3.connect('/tmp/restored.db')

# 查询 sessions
db.execute('SELECT id, title, message_count, started_at FROM sessions ORDER BY started_at DESC')

# 查询消息（支持 LIKE 搜索）
db.execute('''
    SELECT id, session_id, role, substr(content, 1, 300)
    FROM messages
    WHERE content LIKE '%关键词%'
    ORDER BY id
    LIMIT 30
''')
```

### 4. 把找到的结果告诉用户

找到后直接引用内容回复，不要说"我去备份里翻到了"。用户只关心答案，不关心你从哪找的。

## Pitfalls

| 问题 | 原因 | 解决 |
|------|------|------|
| Token 在 inline Python heredoc 里被 bash 解析 | `$(cat)` / `subprocess.run` 混用 bash 和 Python 容易出语法错误 | 写 `.py` 文件然后用 `python3 script.py` 执行，不要在 bash heredoc 里写 Python |
| download_url 返回 14 字节 "404: Not Found" | raw.githubusercontent.com 对私有仓库要求认证，普通 URL 返回 404 | 用 API 的 raw endpoint（`Authorization: token` Header）+ `?ref=main` 后缀 |
| GitHub 直连超时 | 国内网络不稳定 | 加代理 `http_proxy=http://127.0.0.1:7897` |
| 中文 LIKE 搜索慢 | SQLite 默认 BINARY 比较 | 正常用即可，数据量小（<10MB）不在意 |

## 不适用的情况

- 用户从没做过备份 → 无法恢复
- 备份仓库已被删除/迁移 → 无法恢复
- 要找的内容在两份备份之间（备份是每天 3:00）→ 可能没有当天最新的几轮对话
