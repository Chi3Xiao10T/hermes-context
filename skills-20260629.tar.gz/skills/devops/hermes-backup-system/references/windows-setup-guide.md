# 从 Linux 迁移到 Windows Hermes 桌面版 — 完整指南

> 用户原在 Linux（Debian/Ubuntu）上通过 Termius SSH 跑 Hermes + QQ Bot
> 现计划切换至 Windows 桌面版单跑

## 一、Windows 安装

### 推荐：桌面安装器（有 GUI）

去 https://hermes-agent.nousresearch.com/desktop 下载安装器双击运行。

### PowerShell 命令行装

```powershell
iex (irm https://hermes-agent.nousresearch.com/install.ps1)
```

装完启动：`hermes desktop`

### 安装器自动搞定
- Python 3.11
- Node.js v22
- ffmpeg
- ripgrep
- 全自动检测缺失依赖

### 装完后续

```powershell
herdesktop           # 启动桌面版
hermes model         # 选 LLM 模型和提供商
hermes tools         # 启用工具体系
hermes gateway setup # 配置 QQ Bot 等平台
```

### 注意事项

- **安装器需要管理员权限**运行 PowerShell
- 装完后可能需要 **重启 PowerShell** 才能识别 `hermes` 命令
- 如果 `hermes: command not found`，手动加 PATH：`$env:Path += ";$env:USERPROFILE\.local\bin"`

## 二、从备份恢复数据

### 一键恢复（推荐）

```powershell
iex (irm https://raw.githubusercontent.com/Chi3Xiao10T/my-ai-app/main/hermes-backup/scripts/restore-windows.ps1)
```

需以**管理员模式**运行 PowerShell。脚本自动：
1. 克隆备份仓库
2. 恢复 MEMORY.md + USER.md 到 `%USERPROFILE%\.hermes\memories\`
3. 恢复技能包到 `%USERPROFILE%\.hermes\skills\`
4. 恢复中文皮肤 zh.yaml
5. 恢复项目档案

### 手动恢复

```powershell
git clone https://github.com/Chi3Xiao10T/my-ai-app.git C:\temp\restore

# 记忆
copy C:\temp\restore\hermes-backup\memories\MEMORY.md %USERPROFILE%\.hermes\memories\
copy C:\temp\restore\hermes-backup\memories\USER.md %USERPROFILE%\.hermes\memories\

# 技能（取最新日期包）
tar xzf C:\temp\restore\hermes-backup\skills\skills-20260607.tar.gz -C %USERPROFILE%\.hermes\

# 中文皮肤
copy C:\temp\restore\hermes-backup\skins\zh.yaml %USERPROFILE%\.hermes\skins\
```

## 三、配置对比

| 配置项 | Linux 位置 | Windows 位置 |
|:----|:----|:----|
| 主配置 | `~/.hermes/config.yaml` | `%USERPROFILE%\.hermes\config.yaml` |
| API 密钥 | `~/.hermes/.env` | `%USERPROFILE%\.hermes\.env` |
| 记忆 | `~/.hermes/memories/` | `%USERPROFILE%\.hermes\memories\` |
| 技能 | `~/.hermes/skills/` | `%USERPROFILE%\.hermes\skills\` |
| 会话库 | `~/.hermes/state.db` | `%USERPROFILE%\.hermes\state.db` |
| 日志 | `~/.hermes/logs/` | `%USERPROFILE%\.hermes\logs\` |
| Token | `~/.config/github-token` | `%USERPROFILE%\.config\github-token` |

**config.yaml 和 config.yaml 可以跨平台直接复制使用**，内容格式完全一致。

## 四、QQ Bot 连接

与 Linux 完全一致：

```powershell
hermes gateway setup
```

选 QQ Bot → 扫码登录。网关代码跨平台，没有区别。

## 五、GitHub Token 配置

把 Linux 上的 token 复制过去：

```powershell
mkdir %USERPROFILE%\.config -Force
echo ghp_你的完整40位token > %USERPROFILE%\.config\github-token
```

同样**不能放 `.env`**，Hermes 会脱敏 `ghp_` 开头的值。

## 六、代理（Clash）

Clash Verge Rev 有 Windows 版，端口同样是 `7897`。

```powershell
$env:HTTP_PROXY = "http://127.0.0.1:7897"
$env:HTTPS_PROXY = "http://127.0.0.1:7897"
```

## 七、定时备份（替代 cron）

Linux 上用 cron 每天 3:00/4:00 跑备份。Windows 上改用 **任务计划程序**：

1. 打开「任务计划程序」
2. 创建基本任务 → 触发器选「每天」→ 操作选「启动程序」
3. 程序/脚本：`powershell.exe`
4. 参数：`-File "%USERPROFILE%\.hermes\scripts\mega-backup.ps1"`

需要先把 `mega-backup.sh` 改写为 PowerShell 版。

## 八、特别注意事项

### config.yaml BOM 问题
Notepad 编辑 config.yaml 会加 UTF-8 BOM 头，导致 Hermes 报 `No models provided` HTTP 400。  
**解决：** 用 `hermes config edit` 或 VS Code 保存为 UTF-8 without BOM。

### 换行键
Windows Terminal 拦截了 `Alt+Enter`（全屏切换），输入多行用 `Ctrl+Enter`。

### 媒体文件路径
Linux 的 `/tmp/` 对应 Windows 的 `%TEMP%`。如果脚本硬编码了 `/tmp/`，需要在 Windows 上改成 `$env:TEMP\`。

### 中文皮肤
`zh.yaml` 已在备份仓库 `hermes-backup/skins/` 中，可直接恢复。
