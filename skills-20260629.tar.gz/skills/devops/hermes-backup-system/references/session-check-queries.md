# 会话新鲜度查询（SQLite）

恢复后检查 state.db 会话日期范围，判断数据空窗期。

## 查询语句

```python
import sqlite3, datetime

conn = sqlite3.connect(r"C:\Users\Administrator\AppData\Local\hermes\state.db")
cursor = conn.cursor()

# 获取会话列表
cursor.execute("SELECT id, title, started_at, ended_at, message_count FROM sessions ORDER BY started_at DESC;")

# 按本地日期分组消息
cursor.execute("""
SELECT DATE(timestamp, 'unixepoch', '+8 hours') as d, COUNT(*)
FROM messages GROUP BY d ORDER BY d;
""")

# 消息时间范围
cursor.execute("SELECT MIN(timestamp), MAX(timestamp) FROM messages;")
```

## 通过 session_search 查历史

```python
# Discovery（关键词搜索）
session_search(query="CC-Switch OR 灵枢 OR 模型切换", limit=5)

# Browse（最近会话）
session_search()

# Scroll（展开单个会话）
session_search(session_id="xxx", around_message_id=123, window=10)
```

## 备份新鲜度判断

本地 state.db 只有当前会话，历史会话只在 GitHub 备份的 chat-history.db.gz 中。

```bash
cd /tmp/my-ai-app && git log --oneline --date=short | head -1
# 输出: 7398567 Backup 20260616  → 最新备到 6月16日
```

如果最新提交日期比今天早 >1 天，告诉用户数据空窗期并问要不要补备。
