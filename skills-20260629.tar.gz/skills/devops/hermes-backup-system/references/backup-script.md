# backup-chat.py — 每日 GitHub 备份脚本（当前使用）

位置：`~/.hermes/scripts/backup-chat.py`

## 功能

- 每天3点，压缩 `state.db` → Base64 → GitHub API blob → `chat-history/state-YYYYMMDD.db.gz`
- 同步记忆文件 `MEMORY.md` + `USER.md`（日期版永久保留 + 最新版覆盖）
- 同步 wiki 目录 `~/wiki/` 到 `hermes-backup/wiki/`（全量替换）
- 清理超30天的聊天记录（记忆永不清除）

## 依赖

- `~/.config/github-token` — GitHub 40位 `ghp_` 开头 token
- Python 3 + stdlib 即可（`urllib.request`, `base64`, `gzip`）
- 不需要代理（GitHub API 国内直连通）

## Token 读取顺序

```python
# 1. 优先 ~/.config/github-token（不受 Hermes 脱敏影响）
token_file = os.path.expanduser("~/.config/github-token")
if os.path.exists(token_file):
    raw = open(token_file).read().strip()
    if raw.startswith("ghp_") and len(raw) == 40:
        token = raw

# 2. 回退 .env（可能被脱敏为 ***）
env_path = os.path.join(HERMES_HOME, ".env")
# 循环匹配 "GITHUB_TOKEN" in line，strip 后校验格式
```

## 备份文件结构

```
hermes-backup/
├── chat-history/
│   ├── state-20260603.db.gz     ← 聊天，保留30天，旧的自删
│   └── state-20260604.db.gz
├── memories/
│   ├── MEMORY.md                ← 最新版（覆盖）
│   ├── USER.md                  ← 最新版（覆盖）
│   ├── MEMORY-20260603.md       ← 日期版（永久保留）
│   └── USER-20260603.md
└── wiki/
    ├── SCHEMA.md
    └── ...
```

## 关键设计点

| 决策 | 理由 |
|------|------|
| force push main | 简单直接，不产生分支噪声 |
| 一次commit完成所有文件 | 原子操作，要么全成功要么全不成功 |
| 聊天记录30天清理 | 节约仓库空间 |
| 记忆永不清除 | 累积知识，旧版本也有参考价值 |
| 记忆同时存日期版+最新版 | 恢复时直接拿 `MEMORY.md` 不用翻日期 |
| Token 不存 `.env` | 防 Hermes 脱敏截断 |
| Wiki 全量替换 | 每次备份重新上传全部 wiki 文件 |
| 树遍历先保留旧条目再替换 | 避免删除前一天备份时丢失其他仓库文件 |

## 版本历史

- 2026-06-03: 重写 Python 版：记忆按日期保存+永久保留，聊天按日期命名+30天清理，新增 wiki 备份
- 2026-06-03: 修复 token 读取问题（从 `~/.config/github-token` 读，不从 `.env`）

## 废弃的脚本

### backup-chat.sh

Shell 版备份脚本已不再使用（Python 版更简洁稳健），但仍保留在 GitHub 仓库 `hermes-backup/scripts/` 中供参考。

## 手动测试

```bash
cd ~/.hermes/scripts && python3 backup-chat.py
```

预期输出示例：
```
Compressed: 4983KB
Chat blob: 49061b8 → hermes-backup/chat-history/state-20260603.db.gz
Mem blob: 69ed61d → hermes-backup/memories/MEMORY-20260603.md
Mem blob: 69ed61d → hermes-backup/memories/MEMORY.md (latest)
...
✅ Backup done!
```
