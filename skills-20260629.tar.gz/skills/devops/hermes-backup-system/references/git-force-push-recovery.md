# 从 Force-Push 后的 Git 仓库恢复数据

## 场景

Hermes 备份脚本使用 `git push --force origin main` 推送备份文件。如果之前仓库中有其他项目文件（非 `hermes-backup/` 目录），force push 会覆盖分支指针，但 **旧 commit 对象不会立即被 GitHub 删除**（GitHub 保留 dangling objects 一段时间）。

## 恢复流程

### 1. 找到旧 commit SHA

通过 PushEvent 的 `before` 字段获取被覆盖的上一个 commit：

```python
# GitHub Events API
req = urllib.request.Request("https://api.github.com/repos/OWNER/REPO/events?per_page=30")
req.add_header("Authorization", f"token {token}")
events = json.loads(urllib.request.urlopen(req).read())

# 最早的 PushEvent 的 before 字段是被覆盖的旧 commit
for e in reversed(events):
    if e["type"] == "PushEvent":
        old_sha = e["payload"]["before"]  # 如 "efb3535e222dccc6fc22fcb02b810765a055bb93"
        break
```

### 2. 验证旧 commit 是否还在

```bash
curl -H "Authorization: token $TOKEN" \
  https://api.github.com/repos/OWNER/REPO/git/commits/$OLD_SHA
```

返回 `200` + tree SHA 表示可恢复。返回 `404` 说明已被 GC 清理。

### 3. 创建新分支恢复

```bash
# 从旧 commit 创建分支
curl -X POST -H "Authorization: token $TOKEN" \
  -H "Content-Type: application/json" \
  -d "{\"ref\":\"refs/heads/restore-old\",\"sha\":\"$OLD_SHA\"}" \
  https://api.github.com/repos/OWNER/REPO/git/refs

# 克隆恢复的分支
git clone -b restore-old --single-branch \
  https://user:token@github.com/OWNER/REPO.git /tmp/restored
```

### 4. 查看树结构

```python
curl -H "Authorization: token $TOKEN" \
  "https://api.github.com/repos/OWNER/REPO/git/trees/$TREE_SHA?recursive=1"
```

## 注意事项

| 问题 | 说明 |
|------|------|
| **时效性** | dangling commits 最终会被 GitHub GC。恢复越早越好 |
| **Events API 限制** | 只保留最近 300 条事件，超过的 PushEvent 会被丢弃 |
| **备份脚本设计** | 旧脚本（backup-chat.py v1）遍历当前 tree 时保留非 `hermes-backup/` 文件。如果第一次 force push 时已无旧文件，则旧数据永久丢失 |
| **预防措施** | 备份仓库与其他项目代码分离（单独仓库），或备份用独立分支 |

## 根因分析

备份脚本使用 `force push` 的原因是树重建逻辑简单可靠。但如果 repo 中混有项目代码：
1. 旧备份脚本读取当前 tree，过滤掉 `hermes-backup/` 外的文件
2. 添加新的 `hermes-backup/` 文件
3. force push → 理论上其他文件不变
但首次运行时如果旧 tree 中已无项目文件（或 API 调用失败），项目文件就会丢失。

**最佳实践：** 备份仓库与项目代码分仓库存储。
