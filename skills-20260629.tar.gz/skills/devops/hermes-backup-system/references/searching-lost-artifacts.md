# 搜索丢失内容 — 多备份来源逐层核查

> 当用户说"我有个东西/系统/框架之前弄过，现在找不到了"时，不要只查 state.db。按以下顺序翻所有备份来源。

## 核查层级（从快到慢，逐层深入）

### 第1层：当前系统

```python
# state.db session_search
session_search(query="关键词", limit=5)

# 当前技能目录
grep -rl "关键词" "$LOCALAPPDATA/hermes/skills/" 2>/dev/null

# 当前 wiki
grep -rl "关键词" "$LOCALAPPDATA/hermes/wiki/" 2>/dev/null

# 记忆
grep -rl "关键词" "$LOCALAPPDATA/hermes/memories/" 2>/dev/null
```

### 第2层：会话归档（sessions/chat-history.db.gz）

Hermes 会在 old sessions 被压缩时将消息归档到 `sessions/chat-history.db.gz`。这个文件包含**压缩前**的完整消息记录。

```python
import gzip, sqlite3, os, tempfile, shutil

src = os.path.join(os.environ['LOCALAPPDATA'], 'hermes', 'sessions', 'chat-history.db.gz')
if not os.path.exists(src):
    print("No session archive found — skip Layer 2")
else:
    dst = os.path.join(tempfile.gettempdir(), 'archive-search.db')
    with gzip.open(src, 'rb') as fi, open(dst, 'wb') as fo:
        shutil.copyfileobj(fi, fo)
    db = sqlite3.connect(dst)
    
    # 查会话列表
    c = db.execute('SELECT id, substr(id,1,40), source FROM sessions ORDER BY started_at DESC')
    
    # 查消息（LIKE 搜索）
    c = db.execute("SELECT substr(content,1,300) FROM messages WHERE content LIKE '%关键词%' ORDER BY timestamp DESC LIMIT 10")
    
    # 精确搜索（避免误匹配数字+中文的 SQL LIKE 陷阱）
    # 用"模块系统"而不是"%56模块%"——%56模块%会匹配"56"+"模块"在不同地方分别出现
    c = db.execute("SELECT substr(content,1,300) FROM messages WHERE content LIKE '%模块系统%' ORDER BY timestamp DESC LIMIT 10")
    
    db.close()
```

### 第3层：GitHub 技能/wiki 备份

当前 GitHub 备份仓库中有按日期的 skills 和 wiki 压缩包。关键认知：**如果目标内容从来没被保存成 skill 或 wiki 文件，那它在 GitHub 技能/wiki 备份里也是没有的。** 备份只备份已保存的内容，不备份"只在对话里提到过"的内容。

```python
import urllib.request, json, os

token = open(os.path.expanduser('~/.config/github-token')).read().strip()

# 先用 Tree API 看有什么备份文件（不用下载）
req = urllib.request.Request(
    'https://api.github.com/repos/Chi3Xiao10T/my-ai-app/git/trees/main?recursive=1',
    headers={'Authorization': f'token {token}', 'User-Agent': 'Python'}
)
with urllib.request.urlopen(req, timeout=30) as r:
    data = json.loads(r.read())

backup_files = [(item['path'], item['size']) for item in data.get('tree', [])
                if item['type'] == 'blob' and 'hermes-backup' in item['path']]
```

### 第4层：GitHub 聊天记录备份

如果第2层（本地会话归档）也没找到，查 GitHub 上的 `chat-history.db.gz`：

```python
# 下载
r = subprocess.run(['curl', '-sL', '-o', '/tmp/gh-chat.db.gz',
    '-H', f'Authorization: token {token}',
    '-H', 'Accept: application/vnd.github.v3.raw',
    'https://api.github.com/repos/Chi3Xiao10T/my-ai-app/contents/hermes-backup/chat-history/chat-history.db.gz?ref=main'],
    capture_output=True, text=True, timeout=60,
    env={**os.environ, 'http_proxy': 'http://127.0.0.1:7897', 'https_proxy': 'http://127.0.0.1:7897'})

# 解压 + SQLite 查询（同上第2层）
```

### 第5层：MEGA 历史 state.db 搜索（按日期查老对话）

**当第1-4层都查到"东西不存在"但用户坚持说"有！更早的！"时——不要急着下结论。** 用户可能是在 Hermes 安装之前或非常早期的对话中创建的，这些对话可能已被压缩并从本地归档中移除，但 MEGA 备份里还保留着每天独立完整的 `state-YYYYMMDD.db`。

MEGA 备份每天一个完整数据库文件，包含当时的所有会话。用它们搜索老对话中的关键词。

```python
import subprocess, sqlite3, os, tempfile

# 1. 先列出 MEGA 上有什么日期的 state.db
result = subprocess.run(['rclone', 'ls', 'mega:hermes-backup/'],
    capture_output=True, text=True, timeout=30,
    env={**os.environ, 'http_proxy': 'http://127.0.0.1:7897', 'https_proxy': 'http://127.0.0.1:7897'})

# 找到 state-YYYYMMDD.db 文件，按日期排序
state_files = [line for line in result.stdout.split('\n') if 'state-' in line and line.endswith('.db')]
# 选择日期范围（可能目标内容在较早的备份里）

# 2. 把目标日期的 state.db 拉到本地临时目录
rclone copyto mega:hermes-backup/state-20260609.db /tmp/search-db  # 替换为实际日期

# 3. 搜索（注意：MSYS /tmp ≠ Windows TEMP！Python 和 bash 看到的 /tmp 不同）
#    Windows: os.environ['TEMP'] 才是正确的临时路径
temp_dir = os.environ['TEMP']
db_path = os.path.join(temp_dir, 'search-db')

conn = sqlite3.connect(db_path)
c = conn.cursor()

# 查有多少会话
c.execute('SELECT COUNT(*) FROM sessions')
print(f"Sessions: {c.fetchone()[0]}")

# 精确搜索关键词（用复合词避免误匹配）
c.execute("SELECT COUNT(*) FROM messages WHERE content LIKE '%模块系统%'")
# 或搜索可能的关键词变化
for pattern in ['%模块系统%', '%56模块%', '%55模块%']:
    c.execute("SELECT s.id, s.source, substr(m.content,1,300) FROM messages m JOIN sessions s ON m.session_id=s.id WHERE m.content LIKE ? ORDER BY m.timestamp LIMIT 3", (pattern,))
    rows = c.fetchall()
    if rows:
        for sid, src, content in rows:
            print(f"[{src}] {sid[:30]}")
            print(content)

conn.close()
```

**⚠️ 重要注意事项：**
- **路径差异：** Windows 上 Python 的 `/tmp` 不等于 bash 的 `/tmp`。Python 读 `/tmp` → 实际是 `C:\Windows\Temp\`。bash 读 `/tmp` → 实际是 MSYS 的 `/tmp`。用 `os.environ['TEMP']` 获取 Windows 正确临时路径。
- **rclone 代理：** MEGA 在国内必须走代理。设 `http_proxy=http://127.0.0.1:7897`。
- **进程安全：** `subprocess.run()` 在 execute_code 中不可用。改为 `import subprocess` 然后用 subprocess.run() 或在 terminal() 中执行。
- **大文件超时：** state.db 通常 16-24MB，通过代理下载到 MEGA 约需 30-90 秒。设足够 timeout。

### 第6层：历史 skills tar.gz 快照（从备份恢复文件）

仅当确认目标内容之前存在过（用户说"之前保存过但丢了"）且第5层找到它在对话中确实存在过，才需要查。大文件（5MB+）通过代理下载慢。

```python
# GitHub Tree API 查看所有备份文件（含日期）
# MEGA 列出所有 skills-*.tar.gz
result = subprocess.run(['rclone', 'ls', 'mega:hermes-backup/'],
    capture_output=True, text=True, timeout=30)

# 找到需要的日期，下载
rclone copyto mega:hermes-backup/skills-20260609.tar.gz /tmp/check.tar.gz

# 解压到内存检查
import tarfile, gzip, io
with open('/tmp/check.tar.gz', 'rb') as f:
    raw = f.read()
with gzip.GzipFile(fileobj=io.BytesIO(raw)) as gz:
    with tarfile.TarFile(fileobj=gz) as tar:
        # 列出所有 SKILL.md
        skills = [m for m in tar.getmembers() if m.name.endswith('SKILL.md')]
        # 搜索特定 skill 名
        targets = [m for m in skills if '关键词' in m.name.lower()]
        # 直接提取
        for t in targets:
            fh = tar.extractfile(t)
            print(fh.read().decode('utf-8'))
```

**⚠️ 下载注意事项：**
- 通过 Clash 代理走 `raw.githubusercontent.com` 容易超时（exit 28 / exit 35）。用 GitHub API `download_url` + urllib 或 curl。如果超时，试 `unset HTTP_PROXY HTTPS_PROXY` 直连（有时直连 CDN 比走代理快）。
- 大文件下载到 `/tmp` 后需确认路径在 Windows 上是否正确（见第5层路径注意）。

## 判定规则

| 场景 | 结论 |
|------|------|
| state.db + session archive + GitHub chat backup + MEGA state 都搜不到 | 这东西从没在对话里讨论过，或者是在 Hermes 安装之前的旧对话 |
| 当前 skills/wiki 没有，但 MEGA 备份的 state.db 里找到了对话内容 | 东西确实存在过，但没被保存成文件。可以从对话提取内容重建 skill |
| GitHub/MEGA skills tar.gz 里有，但当前环境没有 | 技能被删了。从历史备份直接恢复 skill |
| MEGA state.db 找到了，当前 skills tar.gz 没有 | 内容在对话中讨论过但没落地。需要手动重建 skill 从对话提取内容 |

## 注意事项

- **SQL LIKE 陷阱：** `LIKE '%56%'` 会匹配任何包含数字"56"的内容。用更精确的关键词如"模块系统"。
- **代理设置：** GitHub API 直连在国内可能超时。确保设置 `http_proxy=http://127.0.0.1:7897`。raw.githubusercontent.com 直连有时可用（CDN），试 unset proxy。
- **Token 安全：** 不要在 bash heredoc 里用 `$(cat ~/.config/github-token)`。写 Python 脚本用 `open()` 读文件。
- **归档 DB 与实时 DB 不同：** `sessions/chat-history.db.gz` 是压缩前的旧数据快照，与当前 `state.db` 独立。查完删除临时解压文件。
- **MEGA 拉文件到临时目录后，用 `os.environ['TEMP']` 找到正确路径（Windows 差异）。**
- **判断依据：** 第5层找到对话内容 = 东西存在过但没保存。第6层找到 skill 文件 = 东西保存过但被删了。两者区别决定下一步行动。
