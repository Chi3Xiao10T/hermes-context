---
name: windows-terminal-troubleshooting
description: "Diagnose and fix common Windows terminal input and display issues — PowerShell keyboard not working, PSReadLine corruption, QuickEdit mode, RDP focus bugs, conhost quirks."
version: 1.0.0
author: Hermes Agent (user-taught)
platforms: [windows]
metadata:
  hermes:
    tags: [windows, terminal, powershell, psreadline, quickedit, rdp, troubleshooting]
    related_skills: [hermes-agent, remote-windows-setup]
---

# Windows Terminal Troubleshooting

Diagnose and fix common Windows terminal problems, especially on remote desktop / cloud VM setups where input quirks surface most often.

## Trigger

- User says "PowerShell 打不了字"/"只能粘贴不能输入键盘" ("can type in cmd but not PowerShell")
- User says "键盘敲了没反应" / "光标在闪但键盘没反应"
- User can paste into PowerShell but keyboard input is silently dropped
- PowerShell starts fine (shows prompt, cursor blinks) but ignores keystrokes

## Quick Diagnostic Flow

Start with the fastest checks, narrow from there.

```
Symptom: PowerShell opens but keyboard input doesn't work, paste works
├─ 1. Press Esc or Enter — recovers? → QuickEdit mode (see §QuickEdit)
├─ 2. Open NEW powershell window (Win+R → powershell) — works? → old window was a
│     hung process, just close it
├─ 3. Open cmd — works? → Yes → PowerShell-specific problem (see §PSReadLine)
│                                   → No → system-level input issue (RDP, conhost)
├─ 4. New powershell -noprofile — works? → $PROFILE has a bad module (see §Profile)
│                                         → No → PSReadLine corruption (see §PSReadLine)
└─ 5. ctrl+Break — recovers? → a blocking cmd (Read-Host, Out-GridView) was stuck
```

## PSReadLine Module Corruption

**Most likely cause** on this user's machine when:
- New PowerShell window still can't type
- `-noprofile` doesn't help (rules out $PROFILE)
- cmd.exe types fine

PSReadLine is a built-in module that handles keyboard input for PowerShell. When it's corrupted (version mismatch, broken update, partial install), stdin stops responding but the console window still renders correctly.

### Fix

```powershell
# Run from cmd.exe (since PowerShell can't take input):
powershell -Command "Install-Module PSReadLine -Force -AllowClobber -SkipPublisherCheck"
```

Then close ALL PowerShell windows and reopen. A fresh window loads the reinstalled module.

**Verification:** Open a new PowerShell window — keyboard input should work immediately.

**Side effect:** Console foreground color may reset (e.g. yellow instead of white). This is cosmetic — the default color scheme restored by the module reinstall. Fix with:

```powershell
[Console]::ForegroundColor = 'White'
```

Or via window Properties → Colors → Screen Text → pick white.

## QuickEdit Mode

**Symptom:** PowerShell works fine until you click inside the window with the mouse, then keyboard stops and only paste works.

QuickEdit is a legacy conhost feature: clicking = entering text selection mode. While selected, the console blocks keyboard input.

**Fix:** Right-click title bar → Properties → Options → uncheck "QuickEdit Mode" → OK.

**If using Windows Terminal:** Settings → Interaction → "Enable mouse input" toggle, or set "Mouse interaction mode" to something other than "Select text by clicking."

## Windows Terminal + RDP Focus Bug

On remote desktop (RDP) sessions, Windows Terminal has a known bug where clicking the window doesn't transfer keyboard focus even though the cursor appears to be blinking. The keyboard messages go to the invisible Win32 input layer instead of the terminal buffer.

**Fix:** Don't click the window. Use Alt+Tab to switch to it, or press Ctrl+Shift+T to open a new tab (which grabs focus).

## $PROFILE Issues

If `powershell -noprofile` fixes the typing problem, something in the user's profile script is blocking stdin during initialization.

**Common culprits:**
- oh-my-posh theme rendering (theme engine hangs on slow RDP)
- posh-git scanning repo status on startup
- zoxide / fd initializing
- Any `Invoke-WebRequest` or network call in the profile

**Fix:**
```powershell
# Backup and reset profile to isolate the problem
Rename-Item $PROFILE "$PROFILE.bak"
# Restart PowerShell — if it works, add modules back one by one
```

## Pitfalls

- **Do NOT** assume it's a PSReadLine problem without checking cmd first — if cmd also can't type, the issue is at the RDP or conhost level, not PowerShell
- **Do NOT** reinstall PSReadLine from within PowerShell when input is already broken — use cmd or the `-Command` flag
- **The $PROFILE is NOT the same as PSReadLine** — checking `-noprofile` tells you which layer to fix. Many people conflate them
- **Windows Terminal (wt.exe) is NOT the same as conhost.exe** — different input handling paths. Test in both to narrow the bug
- **Yellow font after PSReadLine reinstall** is cosmetic, not a warning/error — the default color scheme was restored by the module refresh
