---
title: Windows Desktop Automation
name: windows-desktop-automation
domain: devops
description: Control Windows desktop applications (especially Chrome) from Hermes via Python. Covers RDP session requirements, tool selection, coordinate mapping, and China-network workarounds.
---

# Windows Desktop Automation

Control the user's local desktop applications from Hermes terminal sessions.

## When to Switch Platforms (New Heuristic)
When a platform's model produces the wrong art style after 2-3 prompt iterations AND its reference-image / style-transfer feature doesn't change the output, **do not keep iterating**. The model's baked-in style bias (e.g. 即梦AI 图片5.0 Lite → 写实) cannot be overcome by prompt engineering alone. Signal: user says "换" more than once → switch platforms immediately.

Recommended fallback platforms for China users:
- **LiblibAI** (liblib.art) — SD-based, has "短剧漫剧" model category for animated drama styles. Requires registration.
- **通义万相** (tongyi.aliyun.com) — requires phone login.
- **文心一格** (yige.baidu.com) — requires Baidu account.

## Core Insight: RDP Session Requirement

The user's Hermes runs on a Windows cloud PC accessible via RDP. **Desktop GUI automation only works when the user is actively connected via RDP.** When disconnected:

| Tool | Disconnected | Connected |
|------|-------------|-----------|
| pyautogui (mouse/keyboard) | ❌ Screenshot fails, mouse stays at (0,0) | ✅ Mouse/keyboard work |
| pygetwindow | ⚠️ Finds window but can't activate | ✅ Full control |
| UIAutomation | ⚠️ Finds window, can't interact with web content | ⚠️ Same — Chrome web is GPU-rendered |
| CDP (`--remote-debugging-port`) | ❌ Port never opens | ❌ Chrome 149 blocks this by policy |
| Selenium WebDriver | ❌ Times out | ❌ Hangs without display |
| MSS (screenshot) | ❌ BitBlt fails | ❌ BitBlt fails in RDP |

**Confirm RDP is active** before attempting GUI control. The user will say "我连上了".

## Chrome Relaunch Technique (Preserving Login)

When you need to control Chrome but it wasn't started with debug flags:

1. Kill ALL Chrome processes:
```python
import subprocess
subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
# Or use PowerShell: Get-Process chrome | Stop-Process -Force
import time; time.sleep(3)  # wait for crashpad to also die
```

2. Relaunch with same user data dir (preserves cookies/sessions):
```python
import subprocess, pygetwindow as gw, time

chrome = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
user_data = r'C:\Users\Administrator\AppData\Local\Google\Chrome\User Data'

proc = subprocess.Popen(
    [chrome, f'--user-data-dir={user_data}', 'https://target-url.com'],
    creationflags=subprocess.CREATE_NEW_CONSOLE  # ensures visible window
)

# Wait for window to appear
for i in range(15):
    time.sleep(1)
    wins = gw.getWindowsWithTitle('target-title-keyword')
    for w in wins:
        if w.visible and w.width > 200:
            # Window found — proceed with automation
            break
```

**Key points**:
- Use `subprocess.Popen` with Python raw strings — NOT bash/MSYS paths
- `CREATE_NEW_CONSOLE` ensures the window appears in the user's session
- Same `--user-data-dir` preserves all cookies, logins, and session state
- Crashpad handler may restart Chrome without debug flags — kill all chrome.exe, wait 3s, verify count=0

## Window Discovery via pygetwindow (Primary Workaround for No Screenshots)

When `pyautogui.screenshot()` fails in RDP, **pygetwindow is your eyes**. Use it to enumerate all visible windows, find your target, and get its position/size.

### Discovery: List all windows

```python
import pygetwindow as gw
for title in gw.getAllTitles():
    if title.strip():
        w = gw.getWindowsWithTitle(title)[0]
        print(f'{title} | pos=({w.left},{w.top}) size={w.width}x{w.height} vis={w.visible}')
```

### Monitoring: Watch for new windows

```python
import time
prev = set()
for i in range(30):  # poll for 60 seconds
    time.sleep(2)
    current = {t for t in gw.getAllTitles() if t.strip() and len(t) > 2}
    new = current - prev
    if new:
        print(f'{i*2}s: NEW windows {new}')
        prev = current
```

### Blind Interaction: Click by position

When you can find the window but can't see its contents (no screenshot), use position-based clicking:

```python
import pyautogui
pyautogui.FAILSAFE = False  # required for blind operation

w = gw.getWindowsWithTitle('Target Title')[0]

# Click at computed positions within the window
cx = w.left + w.width // 2      # horizontal center
cy = w.top + w.height - 40      # near bottom (common button area)

pyautogui.moveTo(cx, cy, duration=0.3)
pyautogui.click()
time.sleep(1)

# Try common keys
pyautogui.press('enter')
pyautogui.press('tab')
pyautogui.press('escape')
```

**Pitfall**: `win.activate()` often returns success ("操作成功完成") but does NOT actually bring the window to foreground on cloud PCs. Instead, click on the window's title bar area to focus it:
```python
pyautogui.click(w.left + w.width//2, w.top + 10)  # title bar click = reliable focus
```

## Keyboard-Only Navigation Fallback

When coordinate mapping is unreliable (different viewport sizes between cloud browser and desktop):

```python
pyautogui.hotkey('ctrl', 'l')     # Focus address bar
for _ in range(8):
    pyautogui.press('tab')        # Tab through page elements
    time.sleep(0.15)
pyautogui.write('test')           # Check if input captured the text
pyautogui.hotkey('ctrl', 'a')     # Select all
pyautogui.typewrite(prompt, interval=0.008)
pyautogui.hotkey('ctrl', 'enter') # Submit (Alt+Enter also works on some platforms)
```

**Limitation**: Without visual feedback, the number of Tab presses is guesswork. Maximize window first for more predictable layout:
```python
w.maximize()
```

## Silent Software Installation

When you need to install Windows software from Hermes terminal without user interaction:

### NSIS-based installers (most Chinese software)
```bash
installer.exe /S
```
The `/S` flag enables silent install. The process returns immediately with exit code 0 on success.

### Inno Setup-based installers
```bash
installer.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-
```

### Finding the installer
Chinese software installers often land in `~/Downloads/` with names like `Jianying_<random>_installer.exe`. After download triggers from browser, check:
```python
import os
downloads = os.path.expanduser('~/Downloads')
exes = [f for f in os.listdir(downloads) if f.endswith('.exe')]
```

### Post-install verification
Check for new processes and installed directories:
```bash
tasklist | grep -i "keyword"
find "/c/Program Files" "/c/Users/$USER/AppData/Local" -maxdepth 3 -name "*Keyword*" -type d
```

## Recommended Approach

### Step 1: Get window handle
```python
import pygetwindow as gw
wins = gw.getWindowsWithTitle('即梦AI')
w = wins[0]
print(w.left, w.top, w.width, w.height)
```

### Step 2: Get element coordinates from cloud browser
Navigate the Hermes cloud browser to the same page. Use `browser_console` with JS:
```javascript
Array.from(document.querySelectorAll('[contenteditable], textarea, input'))
  .map(el => {const r=el.getBoundingClientRect(); return {tag:el.tagName, x:r.x, y:r.y, w:r.width, h:r.height}})
```
Add desktop window `(left, top)` offset to cloud browser coordinates.

### Step 3: Interact with pyautogui
```python
import pyautogui
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.3

# Focus window, then click, type, etc.
pyautogui.click(w.left + 300, w.top + 10)  # title bar to focus
pyautogui.click(desktop_x, desktop_y)       # target element
pyautogui.typewrite(text, interval=0.01)    # type text
pyautogui.hotkey('ctrl', 'a')               # select all
pyautogui.press('delete')
```

## Known Limitations
- **No screenshots in RDP**: `pyautogui.screenshot()` and `mss` fail (GDI BitBlt limitation). Use pygetwindow window enumeration for layout mapping.
- **CDP is COMPLETELY blocked on Chrome 149+**: `--remote-debugging-port` silently ignored even with `--remote-allow-origins=*`. Confirmed in both RDP-connected and disconnected states. `--remote-debugging-pipe` also fails. Chrome security policy — do NOT invest time here.
- **ChromeDriver download blocked**: Google CDN inaccessible from China. Chinese mirrors only have v113, far behind Chrome 149+.
- **Cloud PC has no GPU**: Creative tools like 剪映 (CapCut), Adobe Premiere, DaVinci Resolve, or any GPU-accelerated software will fail their environment check on startup. The 2-core 4GB cloud PC has no discrete GPU. Additionally, **Codex Desktop Computer Use requires GPU** — `CreateForMonitor` fails with no GPU. A 1GB VRAM GPU is sufficient. Fall back to online services (remove.bg, AI APIs) or CPU-only tools (moviepy, imageio, ffmpeg) for media processing.
- **Codex CLI Computer Use (CUA) is Unix-only, but Desktop GUI app works on Windows**: The CLI cannot access CUA (`remote-control` daemon errors on Windows), but the Codex Desktop GUI app (installed via `codex app`) has full Computer Use capability — screenshots, mouse, keyboard. The Desktop app needs to be launched and the user must paste the task into it (pyautogui keyboard input to Codex window was confirmed NOT to work). See `references/codex-cua-windows-findings.md` for full investigation history.
- **Codex Desktop 配置迁移**：跨机器迁移 Codex 时，必须使用最小化 config.toml（不含机专属运行时路径），否则新机无法启动。详见 `references/codex-config-transfer.md`。自定义 API（lingshuai.cc）需设 `wire_api = "responses"`，Computer Use 需要此接口。
- **The only way to get screenshots under RDP is VNC**: All GDI-based screen capture (PIL, mss, pyautogui) fails with BitBlt errors. VNC server running in the console session provides an independent capture path that bypasses RDP's GDI block. This has not been tested on this cloud PC (user declined install).
- **Coordinating with Hermes TTS**: If also sending voice output, coordinate timing — run GUI automation and TTS delivery in correct order so the user doesn't hear instructions before they see the action.
- **即梦AI specific**:
  - 图片5.0 Lite model is strongly biased toward 写实/realistic output — very hard to steer to 国漫/cartoon styles with prompts alone
  - "图像参考图" feature is **composition reference** (图生图), NOT style transfer — it copies content layout, not art style
  - Older models (4.5/4.1) may respond better to style instructions than 5.0 Lite
  - To get a specific art style, either use a different platform (LiblibAI etc.) or upload a style reference to a tool that supports true style transfer

## Pitfalls
- **Killing Chrome loses login state**: Use `--user-data-dir=<same path>` to preserve profile cookies.
- **Orphan processes**: `taskkill` may leave crashpad-handler. Wait 3s and verify.
- **MSYS path issues**: Use Python raw strings (`r'C:\\path'`) for Windows paths, not bash forward-slash paths.
- **Chrome window title**: Use partial match on keyword, not full title.
- **`win.activate()` silently fails**: On cloud PCs, `gw.getWindowsWithTitle('...')[0].activate()` returns success ("操作成功完成") but does NOT bring the window to foreground. Workaround: click the title bar area. `pyautogui.click(w.left + w.width//2, w.top + 10)` reliably focuses the window.
- **Electron/CEF apps hide native controls**: Apps like 剪映 (Electron), VS Code, Discord render their UI in an embedded browser canvas. `win32gui.EnumChildWindows()` returns zero or very few controls. Buttons and inputs are NOT accessible via win32gui — you MUST use pyautogui position-based clicking. pygetwindow can still find the top-level window and get its rect.
- **Resource-heavy apps freeze the terminal**: When GPU-accelerated or multi-process apps run on the 2-core 4GB cloud PC (剪映 spawns 3+ processes), the terminal/bash session may become entirely unresponsive — even `echo "hello"` times out. Execute commands via `execute_code` instead of `terminal` when this happens, or kill the app first with `taskkill /f /im <process>.exe`.
- **pyautogui typing into Codex Desktop window fails silently**: Even when the Codex window is found and focused via `SetForegroundWindow`, `pyautogui.typewrite()` does not actually inject text. The keystrokes are lost — window is focused but input isn't received. Workaround: write the prompt to a `.txt` file on the desktop, have the user copy-paste it into Codex manually. UI trees with dozens of panels, context menus, and non-standard controls. Without screenshots, pyautogui has no way to locate buttons. Only attempt blind automation on apps with simple, predictable layouts (single-purpose dialogs, login screens, etc.). For complex editors, either use VNC to gain visibility, or switch to an online API / CLI-based alternative.
- **Codex CLI Computer Use (CUA) is Unix-only**: Codex CLI v0.141.0 ships with a full CUA runtime but the `remote-control` daemon errors with `app-server daemon lifecycle is only supported on Unix platforms`. On Windows, CUA tools are only in the desktop GUI app. See `references/codex-cua-windows-findings.md` for full filesystem paths, config details, and every approach tried. Do not invest time in `codex exec` or `codex remote-control start` on Windows for desktop automation.
- **Silent install may not be truly silent**: Some Chinese installers (e.g. 剪映's `JianyingProInstallerDownloader`) download additional payload and then launch a secondary installer. The `/S` flag may work on the secondary installer but not the downloader. Check for new windows appearing after launch.
- **剪映 environment check on GPU-less cloud PCs**: When the cloud PC has no discrete GPU, 剪映 shows an \"环境检测\" (Environment Check) warning popup that blocks entry. The popup is an Electron overlay — win32gui cannot enumerate its buttons, and blind pyautogui clicking is unreliable. The user must manually dismiss it via RDP. Once dismissed, 剪映 may still be too heavy for 2-core 4GB machines, freezing the terminal session entirely.
- **CodeX Desktop 不适合精确UI操作**：CodeX 能打开应用、下载文件、截屏，但点击剪映的具体按钮（智能抠图、羽化滑块等）极不可靠——定位偏移、找不到元素。**结论**：CodeX 做粗活（素材准备），人手做精细活（剪映操作）。不要让 CodeX 反复尝试点击小按钮——浪费时间且激怒用户。
- **剪映智能抠图需VIP**：2026-06-28 验证，预览可看效果但导出需要付费会员。非会员需用 remove.bg 等在线替代方案，或用 GPU 机器上的本地抠图工具。

## Verification
Ask the user what they see — this is the only verification method without screenshots.
