# Chrome GUI Automation — Session Debug Log (2026-06-23)

## Problem
Control user's desktop Chrome (即梦AI) from Hermes to generate images. Cloud browser is geoblocked/empty for jimeng.jianying.com.

## What Was Tried

### ❌ pyautogui (RDP disconnected)
- `screenshot()` → OSError "screen grab failed"
- `moveTo()` reports success but cursor stays at (0,0) — RDP disconnected = no active display

### ✅ pygetwindow
- Finds window: `即梦AI - 一站式AI创作平台 - Google Chrome`
- Gets rect: (30, 30, 1132x892)
- `activate()` → fails with error code 0 (no permission to SetForegroundWindow)

### ⚠️ UIAutomation (uiautomation)
- Can find window and call `SetActive()` without error
- But Chrome web content is in GPU/D3D surface — child controls limited to 2 panes, no input fields visible

### ❌ CDP (Chrome DevTools Protocol)
- Launched with `--remote-debugging-port=9222 --remote-allow-origins=*`
- Port stays CLOSED — Chrome 149 silently ignores the flag (policy/security)
- Also tried `--remote-debugging-pipe` → same result

### ❌ Selenium WebDriver (RDP disconnected)
- `webdriver.Chrome()` hangs/timeout after 60s
- webdriver-manager lock file issue: `.wdm-lock-chromedriver-win64` stuck from previous run

### ❌ Selenium + Headless (RDP disconnected)
- Even with `--headless=new` and temp user data dir → hangs

### ❌ Chromedriver download
- Google CDN inaccessible from China
- npmmirror mirror only has up to v113 (user has Chrome 149)

### ❌ Cloud browser (Hermes built-in)
- jimeng.jianying.com loads blank page — geoblocked or captcha
- Not logged in (shows "登录" button in snapshot)

## Session 2: 2026-06-24 — 即梦AI Image Generation, Style Transfer Failure

### Goal
Generate character design (陈漠) for 短剧《万界中介》 in a specific 国漫 animation style matching a reference image.

### Attempts

#### ❌ 即梦AI 图像参考图 (style reference upload)
- Uploaded a 国漫 animation screenshot as reference image
- The "图像参考图" feature treats it as **composition reference** (图生图), NOT style transfer
- Generated 4 panels of the character but in the model's default style, NOT the reference style
- No "风格参考/角色参考/构图参考" selector appeared — 即梦AI's reference feature is single-purpose

#### ❌ Prompt engineering on 图片5.0 Lite
- Tried multiple prompt variants: "赛璐璐", "国漫动态漫", "平涂上色", "日本动漫角色立绘", "二次元"
- Result: Q版/chibi style (big head, small body) — NOT the standard-proportion 国漫 style user wanted
- 图片5.0 Lite has a strong 写实 bias that can't be overcome with prompts alone

#### ❌ Chrome CDP (even with RDP connected)
- Launched with `--remote-debugging-port=9222 --remote-allow-origins=*`
- Port stayed CLOSED even when RDP was actively connected
- Chrome process was running with the correct flags (confirmed via Get-CimInstance)
- Conclusion: **Chrome 149+ completely blocks remote debugging** regardless of RDP state
- Also tried `--remote-debugging-pipe` → same result

#### ❌ 通义万相
- Loaded in cloud browser
- Requires phone number + SMS verification — unusable without user's credentials
- Same for 文心一格 (Baidu account required)

#### ⚠️ 即梦AI model alternatives (suggested but not tested this session)
- 图片4.5: "强化一致性，风格与图文响应" — likely better at following style instructions
- 图片4.1: "更专业的创意、美学" — older model, less 写实 bias
- Switching to these was proposed but user wanted to change platforms

### What Worked

#### ✅ Chrome relaunch preserving login state
```python
import subprocess, pygetwindow as gw, time

# Kill all Chrome
subprocess.run(['taskkill', '/F', '/IM', 'chrome.exe'], capture_output=True)
time.sleep(3)

# Relaunch with same user data
chrome = r'C:\Program Files\Google\Chrome\Application\chrome.exe'
user_data = r'C:\Users\Administrator\AppData\Local\Google\Chrome\User Data'
proc = subprocess.Popen(
    [chrome, f'--user-data-dir={user_data}', 'https://jimeng.jianying.com/ai-tool/home'],
    creationflags=subprocess.CREATE_NEW_CONSOLE
)
# Window appears at (30, 30) with size 1132x892
```

#### ✅ pyautogui mouse control (RDP connected)
- `pyautogui.moveTo(230, 130)` → actual mouse position confirms move worked
- `pyautogui.click()` → real clicks
- `pyautogui.typewrite()` → real keystrokes
- Still no screenshot capability

#### ✅ Window maximize
```python
w = gw.getWindowsWithTitle('即梦AI')[0]
w.maximize()  # → -8,-8 2096x1018 on 2080x1050 display
```

### Alternative Platform Identified
**LiblibAI** (liblib.art) has a "❤️🔥短剧漫剧·视频特效" model category — specifically designed for animated short drama style. Requires registration (phone/WeChat).

### Lesson
When a platform's model has an inherent style bias (即梦AI 图片5.0 Lite → 写实), prompt engineering alone cannot produce a fundamentally different art style. Reference image upload for style transfer only works if the platform explicitly supports it (Midjourney --sref, SD ControlNet, etc.). Switch platforms rather than over-investing in prompt iteration.

## What Worked

### ✅ pyautogui (RDP connected)
- MoveTo works and reports correct coordinates
- Click works
- `typewrite()` works
- **Screenshot still fails** (GDI BitBlt limit in RDP)

### ✅ Coordinate mapping via cloud browser JS
1. Navigate cloud browser to same page (even if blank?)
2. Actually it loaded fine this time — script elements visible
3. Execute JS to get element positions:
```js
Array.from(document.querySelectorAll('[contenteditable], textarea, input'))
  .map(el => {const r=el.getBoundingClientRect(); return {x:r.x, y:r.y, w:r.width, h:r.height, text:el.textContent?.slice(0,30)}})
```
4. Result for 即梦AI input box: `{x:253, y:228.73, w:900, h:96}`
5. Desktop coords = cloud_browser_coords + window_offset(30,30)
6. Click at approx (380, 330) to reach input area, (1110, 380) for generate button

### Key Commands
```python
import pyautogui, pygetwindow as gw
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0.3
w = gw.getWindowsWithTitle('即梦AI')[0]
pyautogui.click(w.left + 300, w.top + 10)  # focus
pyautogui.click(w.left + 350, w.top + 300) # input area
pyautogui.hotkey('ctrl', 'a');
pyautogui.press('delete')
pyautogui.typewrite(prompt, interval=0.01)
```

## Environment
- Windows 10, 2-core 4GB
- Chrome 149.0.7827.155
- RDP session (Session 2), console session (Session 3)
- Network: China-only (Google/GitHub blocked)
- Hermes runs from git-bash/MSYS (not cmd/PowerShell)
