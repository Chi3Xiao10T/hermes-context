# 剪映 Cloud PC Install — Session Log (2026-06-27)

## Goal
Install 剪映专业版 (CapCut Pro) on a 2-core 4GB cloud PC with no GPU, to use smart cutout (智能抠图) for character layer separation.

## Environment
- Windows 10, 2-core, 4GB RAM, NO GPU
- RDP connected (screenshots fail via GDI, pyautogui keyboard/mouse work)
- China network only

## Install Path
1. Navigated to capcut.cn, clicked "立即下载"
2. Downloader: `Jianying_758238552714_installer.exe` → `~/Downloads/`
3. First attempt: `/VERYSILENT /SUPPRESSMSGBOXES /NORESTART /SP-` → GUI popped up (Inno Setup flags wrong for NSIS installer)
4. Second attempt: `/S` (NSIS silent) → returncode=0 ✅
5. Installed to: `C:\Users\Administrator\AppData\Local\JianyingPro\Apps\10.9.0.14199\`
6. Main executable: `JianyingPro.exe` (spawns 3+ processes)

## The Blocker: Environment Check (环境检测)
After install, 剪映 auto-launched with a modal popup "环境检测" that blocked entry.

### Automated dismissal: FAILED
- Clicking center of window + Enter → nothing
- Tab then Enter → nothing
- Escape → nothing
- Clicking at 6 different positions within the window → nothing
- `win32gui.EnumChildWindows()` → returned ZERO controls (剪映 is Electron, UI rendered in web canvas, no native Windows child controls)
- `pygetwindow` could find the window and get its rect, but no way to locate internal buttons

### Manual dismissal: SUCCESS
The user, connected via RDP and able to SEE the screen, manually clicked the dismiss button.

### Root cause
Cloud PC has **no GPU**. The "环境检测" popup warns about missing hardware but has a "仍然启动" (Start Anyway) or dismiss button that allows proceeding. 剪映 CAN run on GPU-less cloud PCs, but the initial popup must be dismissed manually from RDP.

## Attempted GUI Automation: FAILED
After dismissal, 剪映's main editor loaded. Attempted blind pyautogui automation:
- Ctrl+I, Ctrl+O → no file dialog appeared
- Alt+F menu → no popups detected
- Clicking various positions → no response detected
- No way to verify state without screenshots

**Conclusion**: Automating 剪映's complex editor blindly without screenshots is infeasible. The editor has dozens of controls, panels, and context menus.

## Resource Exhaustion Warning
When 剪映 runs on the 2-core 4GB cloud PC:
- Spawns 3+ processes consuming significant CPU/RAM
- **Terminal tool becomes unresponsive** — even `echo "hello"` times out
- After `taskkill /f /im JianyingPro.exe`, terminal responsiveness returns
- Use `execute_code` instead of `terminal` when 剪映 is running

## Working Alternatives for Cutout on Cloud PC
- **remove.bg API** — online AI cutout, 50 free/month
- **Python moviepy + color key** — only for solid-color backgrounds  
- **User runs 剪映 on local machine** — they can see and interact
- **Codex desktop GUI** — user controls via Codex CUA on desktop
- **VNC screenshot workaround** — bypass RDP GDI limitation (not tested)
