# CodeX 跨机器配置迁移

## 问题
首次安装 CodeX 桌面版时，`config.toml` 包含机器专属路径（运行时、marketplace、pipe GUID），直接复制到新机导致 CodeX 找不到运行环境，无法启动。

## 解决方案：最小化 config.toml

旧机打包只包含核心配置，不含路径：

```toml
model_provider = "custom"
model = "gpt-5.5"

[model_providers.custom]
name = "custom"
wire_api = "responses"
requires_openai_auth = true
base_url = "https://api.lingshuai.cc"

[plugins."computer-use@openai-bundled"]
enabled = true

[plugins."browser@openai-bundled"]
enabled = true
```

## 迁移步骤

1. **旧机**：只打包 `config.toml`（最小版）+ `auth.json`
2. **传输**：GitHub 私有仓库（`Chi3Xiao10T/hermes-context`）或 QQ 文件
3. **新机**：安装 CodeX 桌面版后，将两个文件放入 `C:\Users\Administrator\.codex\`
4. **首次启动**：CodeX 自动下载 marketplace 和 Computer Use 运行时
5. **消除权限弹窗**：config.toml 加 `[projects.'c:\\users\\administrator'] trust_level = "trusted"`

## 必须删除的路径（新机不兼容）

旧机 config.toml 中以下内容绝对不能复制到新机：

- `notify` 中指向 `C:\Users\...\runtimes\cua_node\...` 的路径
- `[mcp_servers.node_repl]` 整个 section（运行时路径不同）
- `[mcp_servers.node_repl.env]` 里的 `NODE_REPL_NODE_PATH`、`CODEX_CLI_PATH` 等
- `[marketplaces.openai-bundled]` 的 `source` 路径
- `SKY_CUA_NATIVE_PIPE_DIRECTORY`（每机 GUID 不同）

## 自定义 API 配置关键点

- `wire_api = "responses"` — Codex Computer Use 需要 OpenAI Responses API，普通 Chat Completions API 不行
- `base_url` 可用 lingshuai.cc（国内中转）
- `model = "gpt-5.5"` — lingshuai 上的模型名
- `requires_openai_auth = true` — 使用 OpenAI 兼容认证头
