# Codex Computer Use (CUA) on Windows — Findings

**Date**: 2026-06-27 (updated after MCP investigation)
**Codex Version**: v0.141.0
**OS**: Windows 10 (cloud PC, 2-core 4GB, no GPU)

## Summary

Codex Computer Use is **NOT available from CLI on Windows**. Full CUA runtime is installed but only accessible through the Codex desktop GUI app. The MCP server mode (`codex mcp-server`) loads node_repl but without desktop screenshot/mouse/keyboard capabilities.

## Installed CUA Runtime

The desktop app ships with a complete Computer Use stack:

```
C:\Users\Administrator\AppData\Local\OpenAI\Codex\
├── bin\
│   └── 330bd0cba6496126\
│       └── codex.exe              (desktop GUI app)
└── runtimes\
    └── cua_node\
        └── a89897d3d9baa117\
            └── bin\
                └── node_modules\
                    ├── playwright\        (browser automation)
                    ├── sharp\             (image processing)
                    ├── pixelmatch\        (screenshot diffing)
                    ├── tesseract.js\      (OCR)
                    ├── @napi-rs/canvas\   (canvas rendering)
                    ├── @oai/sky\          (OpenAI CUA framework)
                    └── pngjs\             (PNG encoding/decoding)
```

## Config Details

From `~/.codex/config.toml`:

```toml
model_provider = "custom"
model = "gpt-5.5"
base_url = "https://api.lingshuai.cc"

[mcp_servers.node_repl]
type = "stdio"
command = '...\\node_repl.exe'
startup_timeout_sec = 120

[mcp_servers.node_repl.env]
BROWSER_USE_AVAILABLE_BACKENDS = "chrome,iab"
SKY_CUA_NATIVE_PIPE = "1"
SKY_CUA_NATIVE_PIPE_DIRECTORY = '\\.\pipe\codex-computer-use-f0894781-905e-463d-933b-2ab19d346ad6'
```

The native pipe is for inter-process communication between the desktop GUI app and the CUA runtime. The CLI cannot access this pipe — it's only alive when the desktop app is running.

## Model Requirements for CUA

Computer Use requires a **multimodal model** that can:
- See/understand screenshots
- Output mouse coordinates and keyboard commands

| Model | Works with CUA? |
|-------|:--:|
| GPT-5.5 (current) | ✅ |
| GPT-4o, GPT-5 | ✅ |
| Claude 3.5 Sonnet, Claude 4 | ✅ |
| DeepSeek V3, R1, V4 | ❌ (text-only) |
| Gemini 2.5 Flash/Pro | ⚠️ (can see images but no CUA API) |

Switching from GPT-5.5 to DeepSeek would **break** Computer Use entirely — DeepSeek cannot understand screenshots.

## Attempted Approaches (All Fails)

### 1. `codex exec` with Computer Use prompt
```
codex exec "Use Computer Use to take a screenshot..."
```
→ Responds: "I don't have a Computer Use / desktop-control tool"
Even with `-s danger-full-access` + `--dangerously-bypass-approvals-and-sandbox`.

### 2. `codex remote-control start`
→ Error: "codex app-server daemon lifecycle is only supported on Unix platforms"
This is compiled into the Rust binary `codex.exe` — cannot be patched via JS.

### 3. `codex app-server proxy`
Same limitation — requires the daemon which only works on Unix.

### 4. `codex mcp-server` (PARTIALLY WORKS — JS only, no desktop)
Starts Codex as an MCP server over stdio. node_repl IS loaded successfully:
```
mcp_startup_complete → ready: ["node_repl"], failed: [], cancelled: []
```

But node_repl in MCP mode **does NOT expose desktop control**. Available helpers:
```
cwd, emitImage, env, homeDir, requestMeta, setResponseMeta, tmpDir, write
```

Available NPM packages (within node_repl):
- ✅ `sharp` — image processing
- ✅ `pngjs` — PNG read/write
- ❌ `screenshot-desktop` — Module not found
- ❌ `@nut-tree/nut-js` — Module not found
- ❌ `robotjs` — Module not found
- ❌ `node-window-manager` — Module not found

The MCP server's `codex` tool accepts these parameters:
```
prompt, model, cwd, approval-policy, sandbox, config, base-instructions, developer-instructions, compact-prompt
```
- `approval-policy` values: `untrusted`, `on-failure`, `on-request`, `never`
- `sandbox` values: `read-only`, `workspace-write`, `danger-full-access`

**MCP Protocol for `codex` tool invocation** (Python stdin pipe):
```python
# Step 1: Initialize
send({"jsonrpc":"2.0","id":1,"method":"initialize",
      "params":{"protocolVersion":"2024-11-05","capabilities":{},
                "clientInfo":{"name":"hermes","version":"1.0"}}})
# Step 2: Send initialized notification
send({"jsonrpc":"2.0","method":"notifications/initialized"})
# Step 3: Call codex tool
send({"jsonrpc":"2.0","id":2,"method":"tools/call",
      "params":{"name":"codex","arguments":{
          "prompt":"...", "sandbox":"danger-full-access",
          "approval-policy":"untrusted"}}})
```

**Streaming output format**: Events arrive as `codex/event` method with msg types:
- `agent_message_content_delta` — incremental text output (delta field)
- `item_started` / `item_completed` — message lifecycle
- `mcp_tool_call_begin` / `mcp_tool_call_end` — MCP tool invocation with results
- `task_completed` — session finished
- `token_count` — usage stats

Sessions are logged at: `~/.codex/sessions/YYYY/MM/DD/rollout-*.jsonl`

**Piping gotcha on Windows**: `printf ... | cmd //c codex.cmd mcp-server | head` — pipe breaks when `head` closes. For sustained sessions, redirect to file or use Python subprocess with thread-based streaming. MSYS `printf` also chokes on `\U` in paths — use Python `mcp_client.py` to emit JSON instead.

## What DOES Work

- **Codex desktop GUI app** (`codex.exe` at `AppData\Local\OpenAI\Codex\bin\...` or launched via `codex app`) — launches full GUI with CUA capability. **Confirmed working on Windows 10 cloud PC** (2026-06-27). The app starts and renders correctly even on 2-core 4GB no-GPU machines. The user can paste a task prompt directly into the GUI and the agent will use Computer Use tools (screenshots, mouse, keyboard) to complete desktop automation tasks.

### Interacting with the Desktop App (File Paste Workaround)

pyautogui keyboard input does NOT reach the Codex Desktop window even when focused. Workaround:

1. Write task prompt to a `.txt` file on the desktop:
```python
with open(r'C:\Users\Administrator\Desktop\codex_task.txt', 'w') as f:
    f.write(prompt)
```
2. User opens the file, copies text, pastes into Codex GUI, presses Enter
3. Codex runs autonomously with full CUA from there
- **codex mcp-server with node_repl** — JS execution, image processing (sharp, pngjs), file system ops, but NO desktop screenshot/mouse/keyboard

## CUA Desktop App Troubleshooting\n\n### Error: \"Package subpath ... is not defined by exports\"\n\nWhen the CUA plugin initializes on Windows, it imports subpath modules from `@oai/sky`:\n```\nPackage subpath './dist/project/cua/sky_js/src/targets/windows/internal/computer_use_client_base.js'\nis not defined by \"exports\" in ...\\@oai\\sky\\package.json\n```\n\n**Root cause**: `@oai/sky/package.json` only exports the root entry point (`\".\": \"./dist/...\"`), blocking all subpath imports. The files exist on disk but Node refuses to load them.\n\n**Fix** — add wildcard export:\n```json\n\"exports\": {\n    \".\": \"./dist/project/cua/sky_js/src/index.js\",\n    \"./*\": \"./*\"\n}\n```\n\nPackage path:\n```\nC:\\Users\\Administrator\\AppData\\Local\\OpenAI\\Codex\\runtimes\\cua_node\\a89897d3d9baa117\\bin\\node_modules\\@oai\\sky\\package.json\n```\n\nAfter editing, restart the Codex Desktop app for changes to take effect.

### CUA Requires GPU — `CreateForMonitor` Failure

Even with the exports fix and the CUA plugin enabled, Computer Use will fail on GPU-less machines:

```
activate_window timed out
Screenshot capture failed: IGraphicsCaptureItemInterop.CreateForMonitor failed
window capture timed out: timed out waiting on channel
```

Windows Graphics Capture API (`CreateForMonitor`) requires a **DirectX 11 compatible GPU** with WDDM 2.0 driver. The cloud PC (2-core 4GB, no discrete GPU) cannot meet this requirement. A 1GB VRAM GPU is sufficient — the requirement is compatibility, not capacity.

**This is a hard blocker**: without a GPU, Codex Desktop CUA cannot take screenshots. The only remaining desktop automation options are:
- pyautogui keyboard/mouse when RDP is connected (no visual feedback)
- VNC server in console session (bypasses RDP GDI, but also needs GPU for graphics capture)
- Online APIs (remove.bg, etc.) for image processing tasks\n\n### CUA Plugin Not Enabled by Default\n\nEven with the Desktop app installed, the Computer Use plugin may NOT be active. The user must:\n1. Open Codex Desktop GUI\n2. Go to **插件** (Plugins) section\n3. Find and enable the Computer Use / CUA plugin\n4. Restart the app if needed\n\n## Recommendations

1. If you need Codex CUA on Windows: user must open the desktop GUI app
2. For automated desktop control: VNC server to bypass RDP GDI, then pyautogui with visual feedback
3. For image processing (background removal etc.): online APIs (remove.bg) or CPU-only tools (moviepy, ffmpeg, sharp via node_repl)
4. Do NOT try `codex exec` or `codex remote-control start` on Windows for desktop automation — these are confirmed dead ends
