# Clash 订阅格式参考

## 两种订阅格式

### 1. Base64 编码的 SS/SSR 链接（无 User-Agent 时的默认返回）

```bash
# 不加 User-Agent 时，订阅可能返回 base64 编码的 ss:// 链接
curl -sL "订阅URL" | base64 -d

# 输出示例：
# ss://Y2hhY2hhMjAtaWV0Zi1wb2x5MTMwNTpmYWtl@1.1.1.1:1080#提示信息
```

**特征：** 节点是假的（`1.1.1.1:1080`），内容为提示文字要求用户换 Clash 客户端。

### 2. Clash YAML 格式（加 User-Agent 后）

```bash
# 必须加 Clash UA 才能拿到真实配置
curl -sL -A "clash-verge/v2.5.1" -o config.yaml "订阅URL"
# 或
curl -sL -A "clash-verge-rev/2.5.1" -o config.yaml "订阅URL"
```

**特征：** 开头为 `mixed-port:`、`proxies:` 等标准 Clash 字段。

## 验证方法

```bash
# 查看文件头判断格式
head -5 config.yaml

# 如果是 Clash YAML，应该看到类似：
# mixed-port: 7897
# allow-lan: false
# mode: rule
# log-level: info
# external-controller: '127.0.0.1:9097'

# 如果是 base64，应该看到字母数字混合的密文
```

## 常见问题

- 不同的订阅商对 UA 要求不同，可尝试 `clash-verge/v2.5.1`、`clash-verge-rev/2.5.1`、`ClashMeta/2.5.1`
- 部分订阅商还支持 `?flag=clash` 或 `?format=clash` 参数
- 配置中 `proxies` 字段包含真实节点信息，敏感勿泄露
