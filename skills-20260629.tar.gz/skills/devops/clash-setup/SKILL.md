---
name: clash-setup
description: "完整部署 Clash Verge Rev（verge-mihomo 核心）代理：Linux（systemd + 订阅获取 + 端口7897）或 Windows（已安装的 Clash Verge 目录 + 服务管理）。不设全局代理。"
trigger: 用户要求配置代理/梯子/翻墙 或 重装系统/换设备后。目标方案硬性固定为 Clash Verge Rev —— 不要问用户"用 Clash 还是 V2Ray"，直接按此技能部署。
---

## 第一原则：不干扰正在运行的 Hermes

**做任何修改代理环境的操作前，先确认不会影响运行中的 Hermes 实例。** 修改代理配置可能导致网络中断，影响 Hermes 网关的 WebSocket 连接和 QQ Bot 在线状态。

---

# Clash Setup

在 Linux（Ubuntu）上部署 Clash Verge Rev 代理，用户已有订阅链接。

## 前提

- 用户已提供 Clash 订阅链接
- 系统为 Ubuntu/Debian

## 步骤

### 1. 安装 clash-verge

从 GitHub Releases 下载 `.deb` 包并安装：

```bash
# 找最新版本
curl -sL "https://api.github.com/repos/clash-verge-rev/clash-verge-rev/releases/latest" | grep "browser_download_url.*amd64.deb" | cut -d '"' -f 4

# 下载指定版本
wget "https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v2.5.1/Clash.Verge_2.5.1_amd64.deb"

# 安装
sudo dpkg -i Clash.Verge_2.5.1_amd64.deb
```

### 2. 获取订阅配置

订阅链接需加 Clash User-Agent 才能拿到真实节点：

```bash
curl -sL -A "clash-verge/v2.5.1" -o /tmp/clash-config.yaml "订阅链接URL"
```

验证是否是 Clash YAML 格式（看开头是否有 `mixed-port`、`proxies` 等字段）。

### 3. 放置配置文件

```bash
mkdir -p ~/.local/share/io.github.clash-verge-rev.clash-verge-rev
cp /tmp/clash-config.yaml ~/.local/share/io.github.clash-verge-rev.clash-verge-rev/config.yaml
```

### 4. 创建 systemd 服务（替代 clash-verge-service）

先停掉自带的 clash-verge-service，改用直接跑核心：

```bash
sudo systemctl stop clash-verge-service
sudo systemctl disable clash-verge-service
```

创建 `/etc/systemd/system/verge-mihomo.service`：

```
[Unit]
Description=Verge Mihomo Core (Clash)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/bin/verge-mihomo -d /root/.local/share/io.github.clash-verge-rev.clash-verge-rev
Restart=always
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now verge-mihomo
---

## 验证配置

```bash
# 测试配置文件
verge-mihomo -t -f ~/.local/share/io.github.clash-verge-rev.clash-verge-rev/config.yaml

# 检查端口
ss -tlnp | grep verge

# 应该看到:
# - 127.0.0.1:7897 (代理端口)
# - 127.0.0.1:9097 (管理端口)
# - 127.0.0.1:5335 (DNS端口)
```

### 6. 测试代理通不通

```bash
curl -x http://127.0.0.1:7897 -sL -o /dev/null -w "%{http_code}" https://www.google.com
# 返回 200 即成功
```

---

# Windows 部署

在 Windows 上 Clash Verge Rev 通过桌面安装程序部署，核心和 GUI 是分开的。

## 安装路径

| 组件 | 路径 |
|------|------|
| 安装目录 | `C:\Program Files\Clash Verge\` |
| 核心程序 | `C:\Program Files\Clash Verge\verge-mihomo.exe` |
| GUI 程序 | `C:\Program Files\Clash Verge\clash-verge.exe` |
| Windows 服务 | `C:\Program Files\Clash Verge\resources\clash-verge-service.exe` |
| 配置文件 | `%APPDATA%\io.github.clash-verge-rev.clash-verge-rev\config.yaml` |
| 即 | `C:\Users\<user>\AppData\Roaming\io.github.clash-verge-rev.clash-verge-rev\config.yaml` |

## 启动核心（无 GUI 模式）

在管理员 PowerShell 或 git-bash 中：

```bash
# 直接启动（前台，会占用终端）
"/c/Program Files/Clash Verge/verge-mihomo.exe" -d "$APPDATA/io.github.clash-verge-rev.clash-verge-rev"

# 验证配置
"/c/Program Files/Clash Verge/verge-mihomo.exe" -t -d "$APPDATA/io.github.clash-verge-rev.clash-verge-rev"
```

## 验证代理是否运行

```bash
# 检查 7897 端口
netstat -ano | grep 7897

# 测试代理
curl -x http://127.0.0.1:7897 -s --max-time 10 -o /dev/null -w "%{http_code}" https://www.google.com
```

## 启动 GUI

用户双击桌面上的 `clash-verge.exe` 即可启动 GUI 版。GUI 运行后才会启动核心。

## 检查节点配置模式

Clash 支持三种模式：Rule（规则）、Global（全局）、Direct（直连）。查看当前模式：

```bash
grep 'mode:' "$APPDATA/io.github.clash-verge-rev.clash-verge-rev/config.yaml"
```

- `mode: rule` — 按规则分流（中国网站直连，国外走代理）—— 推荐
- `mode: global` — 所有流量走代理
- `mode: direct` — 所有流量直连

## 代理环境变量的陷阱

**关键坑：** Windows 上的 git-bash 终端会从系统环境变量继承 `http_proxy`/`https_proxy`。当 Clash 没在运行（7897 端口无监听）但环境变量设置了代理时：

| 症状 | 原因 |
|------|------|
| curl exit code 7 / Connection refused | Clash 没跑，但请求试图连 127.0.0.1:7897 |
| Python `APIConnectionError` | OpenAI SDK 使用 proxy env 发请求 |
| `WinError 10061` | 目标计算机积极拒绝（代理端口未监听） |
| **只有部分命令失败** | 有的工具读取 proxy env，有的不读 |

**诊断：**
```bash
echo "http_proxy=$http_proxy"
echo "https_proxy=$https_proxy"
netstat -ano | grep 7897  # 检查 Clash 是否监听
```

**修复：** 要么启动 Clash，要么清掉环境变量：
```bash
unset http_proxy https_proxy HTTP_PROXY HTTPS_PROXY
```

**注意：中国国内站点（lingshuai.cc、阿里云等）应该直连，不要走代理。** 走代理反而会被拦截或返回 401。因此操作国内站点前务必先 unset proxy。

---

# 全局规则

无论 Linux 还是 Windows，Clash 配置遵循以下规则：

1. **不设全局系统代理** — 不写 /etc/profile.d/proxy.sh，不设 HTTP_PROXY 系统环境变量
2. **需要时手动加代理** — 命令行加 `-x http://127.0.0.1:7897` 或临时 `export HTTP_PROXY=http://127.0.0.1:7897`
3. **先直连再代理** — 中国网站直接连，不通再加代理
4. **大小写都要设** — HTTP_PROXY + HTTPS_PROXY + http_proxy + https_proxy

## proxychains4：让不支持 -x 的工具走代理

很多 TCP 工具（如 `bore`、`ssh -R`、`git` 原生命令等）不支持 `-x` 参数，无法直接通过 HTTP/SOCKS 代理。用 `proxychains4` 可以劫持其 TCP 连接走 SOCKS5 代理。

### 安装（国内镜像）

```bash
# 从阿里云镜像下载 .deb（不要走 GitHub，被墙）
curl -sL --max-time 20 \
  "https://mirrors.aliyun.com/ubuntu/pool/universe/p/proxychains-ng/proxychains4_4.17-1_amd64.deb" \
  -o /tmp/proxychains.deb
dpkg -i /tmp/proxychains.deb

# 缺 libproxychains 依赖时同样从镜像装
curl -sL --max-time 20 \
  "https://mirrors.aliyun.com/ubuntu/pool/universe/p/proxychains-ng/libproxychains4_4.17-1_amd64.deb" \
  -o /tmp/libproxy.deb
dpkg -i /tmp/libproxy.deb
```

**注意：** dpkg 报错是正常的，库文件已到位即可。验证：

```bash
find /usr/lib -name "libproxychains*"
# → /usr/lib/x86_64-linux-gnu/libproxychains.so.4
```

### 配置

```yaml
# ~/proxychains.conf
strict_chain
proxy_dns
tcp_read_time_out 15000
tcp_connect_time_out 8000
[ProxyList]
socks5 127.0.0.1 7897
```

### 用途：bore 隧道穿透

用 `bore` 暴露本地开发服务到公网，通过 proxychains 绕过 GFW：

```bash
# 暴露本地 8080 端口到公网
proxychains4 -f ~/proxychains.conf bore local 8080 --to bore.pub

# 输出示例：
# connected to server remote_port=56555
# listening at bore.pub:56555
# → 公网访问 http://bore.pub:56555/
```

同理适用于任何 TCP 工具：`ssh -R`、`rsync`、自定义 TCP 客户端等。

### 验证

```bash
# 走 proxychains 访问公网
proxychains4 -f ~/proxychains.conf curl -s --max-time 10 \
  "http://bore.pub:56555/" | head -3
```

### 坑：GitHub 二进制下载

在 GFW 环境下，GitHub Releases 的二进制下载会 SSL 错误（exit 35）。解决方案：

- **gh-proxy.com**：`curl -sL "https://gh-proxy.com/https://github.com/.../binary"` — 实测可用
- **阿里云镜像**：apt 包走 `mirrors.aliyun.com`
- **npmmirror**：npm 包走 `registry.npmmirror.com`
- **不要用 GitHub 直连** — 大概率 SSL timeout (exit 35)
- 如果 `gh-proxy.com` 返回 HTML 而非二进制，换时间重试

### 坑：proxychains 找不到 lib

```bash
# 症状
proxychains4 ...
# → couldnt locate libproxychains.so.4

# 解决：单独装 libproxychains4 包（见上方安装步骤）
# 库文件位置：/usr/lib/x86_64-linux-gnu/libproxychains.so.4
```

如果 `LD_LIBRARY_PATH` 能工作但裸命令不行，检查：

```bash
# dpkg 装完后运行试试
LD_LIBRARY_PATH=/usr/lib/x86_64-linux-gnu proxychains4 -f /root/proxychains.conf curl ...
```

## 场景：用户说"我进不去桌面" / "你安装在桌面版上"

Clash Verge 默认是桌面 GUI 程序（依赖 GTK/X11）。当用户 SSH 远程连接（通过 Termius 等）时，无法直接运行 GUI。

**不要尝试启动 GUI 或安装桌面环境。** 直接用 headless 方案：

1. 已安装 clash-verge 的情况下，直接 `dpkg -L clash-verge` 找核心工具
2. 核心是 `/usr/bin/verge-mihomo`（静态链接，无需 GUI）
3. 停掉 `clash-verge-service`（它只会在有 GUI 时才启动核心）
4. 创建独立的 verge-mihomo systemd 服务（见第 4 步）
5. 测试代理：`curl -x http://127.0.0.1:7897 https://www.google.com`

## 恢复步骤（重装系统后）

1. 装 clash-verge（dpkg -i）
2. 获取订阅配置（curl 加 User-Agent）
3. 放置 config.yaml
4. 创建 verge-mihomo systemd 服务
5. 启动并验证

## 推送技能/配置到 GitHub 备份

```bash
# 从 ~/.config/github-token 读取 token
git clone "https://Chi3Xiao10T:$(cat ~/.config/github-token)@github.com/Chi3Xiao10T/my-ai-app.git" /tmp/backup-push 2>/dev/null || {
  # 走代理
  git clone "https://Chi3Xiao10T:$(cat ~/.config/github-token)@github.com/Chi3Xiao10T/my-ai-app.git" /tmp/backup-push -c http.proxy=http://127.0.0.1:7897 -c https.proxy=http://127.0.0.1:7897
}
cp -r ~/.hermes/skills/devops/clash-setup /tmp/backup-push/hermes-backup/skills/
cd /tmp/backup-push
git add -A && git commit -m "update clash-setup skill"
git push
rm -rf /tmp/backup-push
```

## 校验节点是否可用（代理失效排查）

Clash 正常运行但某些网站走代理超时时，不要急着重新拉取订阅。先排查：

```bash
# 看日志
journalctl -u verge-mihomo --no-pager -n 20 | grep -E "error|timeout|dial"

# 单独测某节点（走代理）
curl -x http://127.0.0.1:7897 -s --connect-timeout 5 -o /dev/null -w "%{http_code}" https://www.google.com
```

常见情况：
- 部分节点超时但至少一个能用 → 正常，Clash 会自动切到可用节点
- 所有节点 `i/o timeout` → 代理服务器临时不可达，等几分钟重试
- Google 200 但 YouTube 000 → 不必担心，重试一次即可（间歇性）

## 注意事项

- 订阅链接返回的裸数据可能是 base64 编码的 SS 链接（而非 Clash YAML），详见 [订阅格式](references/subscription-format.md)
- GitHub token 存储和脱敏绕坑详见 [token 存储参考](references/token-storage.md)
- verge-mihomo 是静态链接的，直接可执行，不需要额外依赖
- 配置文件放在 `-d` 指定的目录下的 `config.yaml`，不是在 `profiles/` 子目录
- 开机自启由 systemd 保证
- **不要依赖 `clash-verge-service`** — 它是 GUI 端的 IPC 服务器，不会自动启动核心。必须停掉它，改用 `verge-mihomo` 的独立 systemd 服务
- `-d` 参数必须用**绝对路径**，不认 `~`——写成 `/root/.local/...` 而非 `~/.local/...`

## 维护操作

### 重新拉取订阅配置

如果代理节点集体超时（`dial tcp ...:4430: i/o timeout`），可能是订阅节点变动或临时故障。重新拉取配置并重启：

```bash
# 重新获取配置
curl -sL -A "clash-verge/v2.5.1" -o ~/.local/share/io.github.clash-verge-rev.clash-verge-rev/config.yaml "订阅链接URL"

# 验证
verge-mihomo -t -f ~/.local/share/io.github.clash-verge-rev.clash-verge-rev/config.yaml

# 重启
systemctl restart verge-mihomo
```

如果订阅商限制了刷新频率，可能需要等几分钟再试。

### 查看节点连接日志

所有节点返回 `i/o timeout` 时，先看日志再决定是否刷新订阅：

```bash
journalctl -u verge-mihomo --no-pager -n 30 | grep -E "error|timeout|fail|dial"
```

如果显示 `dial tcp ...:4430: i/o timeout`（所有节点都超时），说明代理服务器暂时不可达或线路问题，不必急着重新拉取订阅。可以稍后再试或切换其他节点组（Tuic 等）。

### 改用其他节点（通过管理 API）

```bash
# 查询当前节点
curl -s http://127.0.0.1:9097/proxies | python3 -m json.tool | head -50

# 切换代理组默认节点
curl -s -X PUT -d '{"name":"🇯🇵9日本大版集群-电信/移动(AnyTLS)"}' \
  http://127.0.0.1:9097/proxies/BV用户后台!
```

### 坑：clash-verge-service 不启动核心

`clash-verge-service` 是 GUI 端的 IPC 接口，它监听 Unix socket 等待 GUI 发指令后才启动核心。在无桌面的纯 CLI 环境，它永远显示 "Desired state does not require core restore"，核心不会运行。

**正确做法：** 直接 `systemctl stop clash-verge-service && systemctl disable clash-verge-service`，然后用自己的 verge-mihomo systemd 服务。
- `clash-verge-service` 是 GUI 端 IPC 服务器，**不会自动启动核心**。直接用 `verge-mihomo` 的 systemd 服务代替
