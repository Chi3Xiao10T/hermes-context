---
name: mega-backup
description: 将 Hermes 聊天记录 + 记忆 + Wiki + Skills 每日备份到 MEGA 云盘，通过 rclone + Clash 代理实现国内可访问
category: devops
---

# MEGA 备份方案

MEGA 是 Hermes 双保险备份体系的**异地冷备层**，与 GitHub 备份独立运行。

## 每天 4:00 备份内容

| 内容 | 路径 | 方式 |
|------|------|------|
| state.db | `mega:hermes-backup/state-YYYYMMDD.db` | copyto（每日独立文件，永久） |
| wiki | `mega:hermes-backup/wiki-YYYYMMDD.tar.gz` | copyto（先 tar.gz 压缩，每日独立，永久） |
| skills | `mega:hermes-backup/skills/` | copy（仅最新版） |
| memories | `mega:hermes-backup/memories/` | copy（仅最新版，与GitHub双保险） |

**2026-06-03 更新：**
- Wiki 改为按日期压缩包保存（`tar czf wiki-YYYYMMDD.tar.gz`），永久保留。之前用 `copy` 同步最新版的方式不符合用户对知识库全量永久保留的要求
- 新增 memories/ 备份。之前缺失，现在与 GitHub 形成双保险
- 使用 `copy` 而非 `sync`。`sync` 需要先列出远程目录树再逐文件比对，在国内通过代理连接 MEGA 时非常慢，曾导致 cronjob 120秒超时。`copy` 仅上传变化文件，全量备份约 15 秒。且 `copy` 不删除远程已有文件
- 移除了直连尝试（已验证直连不可用），改为直接走代理

## 前提

- Clash 代理已运行（MEGA 在国内被墙，端口 7897）
- MEGA 账号（2073427031@qq.com，20GB 免费空间）
- rclone 已配置（远程名 `mega`）

## 安装 & 配置

```bash
# 安装 rclone
export HTTP_PROXY=http://127.0.0.1:7897 HTTPS_PROXY=http://127.0.0.1:7897
curl -sL https://downloads.rclone.org/rclone-current-linux-amd64.deb -o /tmp/rclone.deb
dpkg -i /tmp/rclone.deb

# 配置 MEGA（非交互式）
rclone config create mega mega user 邮箱@qq.com pass $(rclone obscure "密码")

# 测试
rclone lsd mega:
```

## 备份脚本（当前版本，2026-06-03）

`~/.hermes/scripts/mega-backup.sh`：

```bash
#!/usr/bin/env bash
# MEGA 备份
set -e

RCLONE_CONFIG="$HOME/.config/rclone/rclone.conf"
PROXY="HTTP_PROXY=http://127.0.0.1:7897 HTTPS_PROXY=http://127.0.0.1:7897"
TODAY=$(date +%Y%m%d)

# 1. state.db → 独立文件，永久保留
env $PROXY rclone --config "$RCLONE_CONFIG" copyto "$HOME/.hermes/state.db" "mega:hermes-backup/state-$TODAY.db"

# 2. memories → 最新版同步
env $PROXY rclone --config "$RCLONE_CONFIG" copy "$HOME/.hermes/memories" "mega:hermes-backup/memories"

# 3. wiki → 按日期压缩包，永久保留（重要！用户要求知识库全量永久保留）
tar czf /tmp/wiki-$TODAY.tar.gz -C "$HOME" wiki/
env $PROXY rclone --config "$RCLONE_CONFIG" copyto "/tmp/wiki-$TODAY.tar.gz" "mega:hermes-backup/wiki-$TODAY.tar.gz"
rm -f /tmp/wiki-$TODAY.tar.gz

# 4. skills → 最新版同步
env $PROXY rclone --config "$RCLONE_CONFIG" copy "$HOME/.hermes/skills" "mega:hermes-backup/skills"
```

⚠️ `state.db` 用 `copyto`（覆盖指定文件），`wiki` 先 `tar czf` 压缩再用 `copyto` 推独立日期文件。`copy` 仅上传变化文件，不删远程已有内容。

## cronjob

```bash
cronjob action=create name="MEGA聊天记录备份" schedule="0 4 * * *" script=mega-backup.sh no_agent=true deliver=origin
```

## 冲突说明

本 skill 与 `hermes-backup-system` 功能重叠，以 `hermes-backup-system` 为最新权威文档。本 skill 仅保留了 MEGA 配置安装的独立参考。

## Pitfalls

| 问题 | 原因 | 解决 |
|------|------|------|
| 120s 超时 | `sync` 先列出远程树再比对，通过代理到 MEGA 非常慢 | 换 `copy`（仅上传变化文件），全量备份约 38s |
| 直连超时 | MEGA 在国内被墙 | 必须走 Clash 代理（HTTP_PROXY=127.0.0.1:7897） |
| cronjob no_agent 脚本超时 | 默认 120s 限制 | 脚本需优化到 60s 内完成；坏的做法是堆四个 sync 串行，好的做法是 copy + 只传变化 |

## 注意事项

- MEGA 免费账户 20GB，state.db 仅 ~4-5MB，够用数年
- MEGA 已被墙，所有操作必须走代理（Clash 端口 7897）
- 恢复时：`rclone copyto mega:hermes-backup/state-YYYYMMDD.db ~/.hermes/state.db`
