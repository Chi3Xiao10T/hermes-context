---
name: firecrawl-setup
description: 配置 Firecrawl 为 Hermes 的搜索/网页抓取后端，含 API Key 写入和三项 web 后端设置
trigger: 用户提供 Firecrawl API Key 或 恢复备份后 Key 丢了需要重配
---

# Firecrawl 搜索后端配置

配置 Firecrawl 作为 Hermes 的 Web 搜索后端（替代 DDGS 等默认搜索）。

## 结构说明

Hermes 的 `web:` 配置节有三个后端字段：

```yaml
web:
  backend: firecrawl        # 通用搜索后端（默认 fallback）
  search_backend: firecrawl  # 搜索专用
  extract_backend: firecrawl # 网页抓取专用
```

- 旧配置可能保留 `backend: ddgs`（DuckDuckGo），用户可能已不再使用 DDGS
- 设 `backend: firecrawl` 后，搜索和抓取都默认走 Firecrawl

## 步骤

### 1. 写入 API Key

```bash
hermes config set web.backend firecrawl
```

但 Key 需要写入 `~/.hermes/.env`：

```bash
# 直接替换 .env 中的占位符
python3 -c "
with open('/root/.hermes/.env', 'r') as f:
    content = f.read()
content = content.replace('FIRECRAWL_API_KEY=***', 'FIRECRAWL_API_KEY=用户提供的Key')
with open('/root/.hermes/.env', 'w') as f:
    f.write(content)
"
```

### 2. 设置三项后端

```bash
hermes config set web.backend firecrawl
hermes config set web.search_backend firecrawl
hermes config set web.extract_backend firecrawl
```

### 3. 验证

```bash
curl -s -X POST https://api.firecrawl.dev/v1/search \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer 用户Key" \
  -d '{"query":"测试","limit":1}'
```

返回 `{"success":true,...}` 即成功。

## 坑

### Key 丢失问题

Firecrawl API Key（`fc-` 开头，如 `fc-bb9cbaaf57c54bd98c8cb27e66e47259`）存在 `~/.hermes/.env` 里。这个文件被 `.gitignore` 排除，**不会出现在 GitHub 备份中**。

换机器或恢复备份后，Key 会变成 `***` 占位符，需要用户重新提供。

**解决方案：** 无完美的自动方案。每次迁移都需要用户从 Firecrawl 控制台（https://www.firecrawl.dev/app/api-keys）获取 Key。

### 手动写入 Key

```bash
python3 -c "
with open('/root/.hermes/.env', 'r') as f:
    content = f.read()
content = content.replace('FIRECRAWL_API_KEY=***', 'FIRECRAWL_API_KEY=用户提供的Key')
with open('/root/.hermes/.env', 'w') as f:
    f.write(content)
"
```

### 验证

```bash
curl -s -X POST https://api.firecrawl.dev/v1/search \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer 用户Key' \
  -d '{"query":"测试","limit":1}'
```

返回 `{"success":true,...}` 即成功。

### 三项后端都要设

只设 `backend: firecrawl` 不一定够——如果 `search_backend` 或 `extract_backend` 有旧值（如 `ddgs`），DDGS 仍是默认搜索后端。三项都设才能彻底替换。

### Firecrawl 浏览器插件 ≠ Web 搜索后端

Firecrawl 有两个独立插件：
- `plugins/web/firecrawl/` — Web 搜索/抓取（本技能涉及）
- `plugins/browser/firecrawl/` — 云浏览器（不同的配置项，需要额外的消费额度）

两者共享同一个 API Key 但功能互不干扰。

## 关联技能

- `clash-setup/references/token-storage.md` — Key 存储的通用避坑指南
- `github-models-vision` — GitHub Models 视觉方案（也用到了类似的三项后端配置模式）
