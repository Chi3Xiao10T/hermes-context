---
name: tailscale-cross-platform-ssh
description: 通过 Tailscale 组网打通 Linux → Windows 云电脑的 SSH 连接，用于远程部署工具（Blender 等）
category: devops
---

# Tailscale 跨平台 SSH 组网

## 适用场景
- Linux 机器（Hermes 主控）需要远程控制一台 **Windows 云电脑**（有/无显卡）
- 云电脑在 NAT 内网，没有公网 IP，无法直接 SSH
- 需要在 Windows 上远程安装/运行 Blender 等图形工具

## 前置条件
- 两台机器都能访问互联网
- Linux 有 root/sudo
- Windows 账户有管理员权限

## 步骤

### 1. Windows 端：安装 OpenSSH 服务器

以管理员身份打开 PowerShell，依次执行：

```powershell
# 安装 OpenSSH 服务器
Add-WindowsCapability -Online -Name OpenSSH.Server~~~~0.0.1.0

# 启动服务并设为开机自启
Start-Service sshd
Set-Service -Name sshd -StartupType 'Automatic'

# 防火墙放行 22 端口
New-NetFirewallRule -DisplayName 'OpenSSH Server (sshd)' -Direction Inbound -Protocol TCP -LocalPort 22 -Action Allow
```

**注意：** 如果 Windows 没有"可选功能"UI 选项（部分精简版/国产云桌面），命令行是唯一途径。

### 2. 两台机器：安装 Tailscale

**Linux：**
```bash
curl -fsSL https://tailscale.com/install.sh | sh
systemctl start tailscaled
tailscale up
# 打开输出的 URL 登录
```

**Windows：**
- 浏览器打开 https://tailscale.com/download/windows
- 下载安装，登录时建议用 GitHub（国内 QQ 邮箱可能收不到验证码）

### 3. 确认组网成功

```bash
tailscale status
# 应看到两台机器的 Tailscale IP（100.x.x.x 格式）
```

### 4. Linux 端：生成 SSH 密钥并传给 Windows

```bash
# 生成密钥（如果还没有）
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""
cat ~/.ssh/id_ed25519.pub
```

### 5. Windows 端：安装 SSH 密钥（⚠️ 管理员账户特殊路径）

**重要：Windows 管理员账户（Administrators 组成员）的 SSH 密钥不放在用户目录！**  
默认路径 `%USERPROFILE%\.ssh\authorized_keys` 会被 OpenSSH 忽略。必须使用系统路径：

```powershell
$pubkey = "ssh-ed25519 AAAA... 你的公钥内容"
$keyPath = "C:\ProgramData\ssh\administrators_authorized_keys"
$pubkey | Set-Content -Path $keyPath -Encoding ASCII -NoNewline
icacls $keyPath /inheritance:r /grant "SYSTEM:(R)" /grant "Administrator:(R)"
Restart-Service sshd
```

**⚠️ 权限设置是关键** — 仅允许 SYSTEM 和 Administrator 读取，否则 OpenSSH 会拒绝该密钥。

### 6. 测试连接

```bash
ssh -o StrictHostKeyChecking=no Administrator@<windows-tailscale-ip>
```

## 已知坑点

### Linux 端
- Tailscale 安装脚本依赖 apt，如果系统有 broken packages（如 proxychains4），需先 `apt --fix-broken install -y`
- Tailscale 国内访问 pkgs.tailscale.com 可能慢但能通，不需要代理

### Windows 端
- **IP Helper 服务**：Tailscale 需要 `iphlpsvc` 服务运行。如果提示禁用，在 `services.msc` 中找到 IP Helper，设为自动并启动
- **Windows 认证**：SSH 默认用当前 Windows 用户（Administrator），用户名必须匹配
- **⚠️ 密钥位置**：管理员账户密钥在 `C:\ProgramData\ssh\administrators_authorized_keys`，不是用户目录 `%USERPROFILE%\.ssh\authorized_keys`
- **密钥权限**：`administrators_authorized_keys` 文件必须 `icacls ... /inheritance:r /grant "SYSTEM:(R)" /grant "Administrator:(R)"`，否则 OpenSSH 拒读
- 部分国产云桌面可能精简了可选功能组件，但 Add-WindowsCapability 命令行仍可正常工作
- **编码问题**：SSH 输出中文时 PowerShell 的编码可能导致乱码。用 `if exist`、`echo DONE` 等英文关键词检测输出

### 网络问题：下载Tailscale安装包

Windows上安装Tailscale常见两个坑：

**坑1：`0x80070643` — exe引导器安装失败**
用MSI直装绕过：
```powershell
msiexec /i "$env:USERPROFILE\Downloads\tailscale-setup-latest.msi" /quiet /norestart
```

**坑2：`tailscale-setup-latest.msi` 404（最新版没有`-latest`重定向）**
用版本号直链，走ghfast代理下载：
```
https://ghfast.top/https://pkgs.tailscale.com/stable/tailscale-setup-1.98.4-amd64.msi
```
或下载完整exe（内嵌所有MSI包）：
```
https://ghfast.top/https://pkgs.tailscale.com/stable/tailscale-setup-full-1.98.4.exe
```
版本号查：`https://pkgs.tailscale.com/stable/` 看文件列表。

## 后续动作示例
连接成功后即可远程操作 Windows 云电脑：
- 安装 Blender（`winget install BlenderFoundation.Blender` 或手动下载）
- 通过 SSH 执行 PowerShell 命令管理 Windows
- 使用 `scp` 或 `rsync` 在机器间传输文件
