# 2026年6月 政府审计数据收集记录（2026-06-04 核实版）

## ⚠️ 重要更正

2026-06-04 用 browser_vision 重新核实了雅安审计数据，发现之前的数据有误（特别是张家山、陆家坝、康藏路）：
- **张家山公园**：之前误报审减25.9%，实际审定价=中标价=4,229.79万（审减0%）
- **陆家坝公园**：之前只记了合同价，漏掉了中标价（3,766.54万）
- **城后路道路**：之前数据来自新闻稿而非完整公告，已核实为完整公告数据
- 用 **中标价 vs 审定价** 替代了之前不统一的"中标/合同"字段

## 数据来源 & 爬取方法

**入口**: https://sjj.yaan.gov.cn/xinwen/list/8640516e-9834-430e-8872-df5de16e70a6.html
**页数**: 4页（审计结果公示栏目）
**访问方法**: browser_navigate 直连（Firecrawl被屏蔽）
**内容提取**: browser_vision（iframe内嵌的正文vision能读，snapshot读不到）
**已核实项目**: 见 SKILL.md 主数据表

### 核实后的种子数据库JSON

完整18条种子数据存于 `/root/my-ai-app/data/seed_projects.json`，含：
- id, name, city, type, bid_price, contract_price, submitted_price, audit_price, bid_to_audit_ratio, source, year

**利润分析器工具**: `scripts/profit_analyzer.py` — CLI工具，支持stats/estimate/interactive模式
**快捷命令**: `profit stats` 或 `profit estimate 房建 8000000`

## 关键术语

| 术语 | 含义 | 利润影响 |
|------|------|---------|
| 中标价 | 中标签约价，合同基础 | 收入基准 |
| 合同价 | 正式合同金额，通常=中标价 | 收入基准 |
| 送审价 | 施工完报的结算，含签证 | 施工方期望值 |
| 审定价 | 审计核准的最终金额 | 实际到手收入 |
| 签证 | 合同外变更（增项/减项） | 正向=加钱，负向=减钱 |
| 中标→审定差额 | (审定-中标)/中标 | 实际落袋偏离中标的比例 |
