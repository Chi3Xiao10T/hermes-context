# 利润分析器 CLI 工具说明

## 位置
- 脚本: `/root/my-ai-app/scripts/profit_analyzer.py`
- 种子数据: `/root/my-ai-app/data/seed_projects.json`
- 快捷命令: `profit` (软链接至 /usr/local/bin/profit)

## 用法

```bash
# 查看统计概览（按项目类型）
profit stats

# 预估一个800万房建项目的审定价区间
profit estimate 房建 8000000

# 交互模式（输入类型→中标价→成本→输出利润预估）
profit
```

## 代码结构

```python
load_seed_data()   → 读取 JSON 种子库
compute_stats()    → 按 type 分组计算均值/标准差
estimate()         → 输入中标价+类型，输出3档区间(±1σ)
calc_profit()      → 输入成本，计算利润
show_all_types()   → 打印统计表
interactive()      → 交互式输入
main()             → CLI 入口，支持 stats/estimate/无参数
```

## 新增项目

直接编辑 `data/seed_projects.json`，添加新的项目对象。格式：

```json
{
  "id": 13,
  "name": "项目全称",
  "city": "城市",
  "type": "项目类型（与现有类型保持一致）",
  "bid_price": 中标价,
  "contract_price": 合同价,
  "submitted_price": 送审价,
  "audit_price": 审定价,
  "bid_to_audit_ratio": (审定价-中标价)/中标价,
  "source": "来源审计局",
  "year": 年份
}
```

注意：`type` 字段必须与已有类型匹配才能被统计。已用类型：房建、房建专项、房建附属、市政道路、桥梁、公路、公园绿化。
