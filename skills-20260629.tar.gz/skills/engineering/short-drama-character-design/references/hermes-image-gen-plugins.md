# Hermes 内置图片生成插件（未配置）

Hermes Agent 源码中自带了3个图片生成后端插件，但**当前环境均未配置 API Key**：

## 插件列表

| 插件 | 路径 | 需要Key | 模型 |
|------|------|---------|------|
| **openai** | `plugins/image_gen/openai/plugin.yaml` | `OPENAI_API_KEY` | gpt-image-2 |
| **krea** | `plugins/image_gen/krea/plugin.yaml` | `KREA_API_KEY` | Krea 2 Large/Medium |
| **xai** | `plugins/image_gen/xai/plugin.yaml` | `XAI_API_KEY` | grok-imagine-image |

## 可用性

- 登录本机 `.env` 和 `auth.json` 确认：**以上3个Key均未配置**
- 只有 `DEEPSEEK_API_KEY` 和 `custom:lingshu` 的 API Key 已配
- 如果未来用户提供了任一 Key，可用 `hermes tools` 启用对应插件

## 启用方法（参考）

```bash
# 先配 Key 到 .env
echo "OPENAI_API_KEY=sk-xxx" >> ~/AppData/Local/hermes/.env
# 或通过 auth.json
hermes auth add openai --api-key sk-xxx

# 检查工具
hermes tools
# image_gen 类的后端需在 tools.image_gen.backend 配置
```

> 注：当前 `hermes-agent` skill 中有详细的 tools/image_gen 配置说明，需要时再查。
