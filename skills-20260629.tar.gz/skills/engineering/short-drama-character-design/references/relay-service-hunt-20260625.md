# GitHub 中转站搜索结果（2026-06-25 更新）

## 搜索方式

GitHub API 搜索关键词：
- `gpt-image-2 中转 api` — 找到 whataicc 和 Token173 的专门仓库
- `gpt-image-1 中转` / `gpt-image-2 中转` — AI中转站推广仓库
- `AI中转站` / `大模型中转` / `中转API` — 中转站导航项目
- 中转站聚合评测站：relayradar.dev, relaypulse.top, hvoy.ai

## 发现的中转站

| 中转站 | API地址 | 支持模型 | 当前状态 | 费用 |
|--------|---------|---------|---------|------|
| 神马聚合中转 | api.whatai.cc | gpt-image-1 ✅ | ❌ 已停新注册 | 2元≈1刀，按量 |
| Token173 | token173.com | gpt-image-2 ✅ | ❌ 全网超时，服务器已挂 | 2元≈1刀，按量 |
| Token云桥 | api.0029.org | gpt-image-2 ✅ 生成+编辑 | ✅ 可注册但需充值 | 最低¥100 |
| DDShub | ddshub.cc | 仅文本 ❌ | ✅ 可达 | 按量 |
| Pincc | v2.pincc.ai | 仅文本 ❌ | ❌ 区域限制 | 按量 |
| Unity2 | unity2.ai | 仅文本 ❌ | ✅ 可达 | 按量/包月 |
| kocodex | kocodex.link | 仅文本 ❌ | ✅ 可达 | 按量/包月 |
| fenno | api.fenno.ai | 仅文本 ❌ | ✅ 可达 | 按量/包月 |
| Theta API | api.aithauma.com/v1 | 仅文本 ❌ | ✅ 可达 | 按量 |
| **一步API** | yibuapi.com | gpt-image-2 ✅ 生成+编辑 ✅ | ✅ **已验证可用的中转** | **~¥0.06/张（默认组），¥0/最低充值** |
| **Atlas Cloud** | atlascloud.ai | gpt-image-2 ✅ 生成+编辑 ✅ | ✅ 全功能平台 | ✅ **$0.004/张起，按量付费无需套餐** |
| **img.222250.xyz** | img.222250.xyz | GUI壳，需自配后端 | ✅ 已注册 | N/A（纯前端壳） |

## 新发现

### 一步API (yibuapi.com) — 已验证可用的低价gpt-image-2中转

**已验证（2026-06-26）**：真实gpt-image-2模型，非蒸馏套壳。

**验证方法**：生成含中文文字的图片（"你好世界"）→ 正确渲染中文 ✓

#### 接入信息
- **官网**：https://yibuapi.com
- **API端点**：`https://yibuapi.com/v1/chat/completions` （⚠️ 不是 `api.yibuapi.com`，带`api.`前缀解析失败）
- **模型名**：`gpt-image-2`
- **API格式**：OpenAI chat completions 格式

#### 分组与价格
| 分组 | 倍率 | 实测单价 | 说明 |
|------|:----:|:--------:|------|
| **default（推荐）** | 2× | **~¥0.06/张** | 接近官价，已验证是真货 |
| 官方融合 | 3.5× | ~¥0.105/张 | 更贵，不是官方通道 |

**充值**：最低¥0充值（可以设置额度限制）。用户充了¥2（设置default组限制¥1），实测可用。

#### 生成调用格式（OpenAI chat completions）
```json
POST https://yibuapi.com/v1/chat/completions
{
  "model": "gpt-image-2",
  "messages": [{"role": "user", "content": "你的提示词"}],
  "n": 1
}
```

#### 编辑调用格式（关键发现！gpt-image-2支持编辑）
```json
POST https://yibuapi.com/v1/chat/completions
{
  "model": "gpt-image-2",
  "messages": [
    {
      "role": "user",
      "content": [
        {"type": "text", "text": "Edit this image: [描述要改的内容]"},
        {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,[图片base64]"}}
      ]
    }
  ],
  "n": 1
}
```
- 编辑功能走的是 **chat completions 端点**传入图片，不是独立的 `/v1/images/edits`
- 返回内容是一个图片URL（如 `![image](https://oss.filenest.top/uploads/xxx.png)`）
- 结果图片托管在 filenest.top，下载时需要加 User-Agent 和 Referer 头

#### 已验证的编辑效果
| 编辑内容 | 效果 | 
|----------|------|
| 换衣服颜色（红→黑） | ✅ 准确 |
| 添加/移除物体（加账本、去现金） | ✅ 准确 |
| Q版→正常比例 | ✅ 生成4宫格渐进过渡图 |
| 保持人物姿势和背景 | ✅ 基本一致 |

#### 已验证的不可编辑内容
- ❌ Q版→正常比例只能出渐进过渡图，不能一步到位改成纯正常比例单图
- ❌ 无法精准控制面部表情/五官（gpt-image-2渲染风格天生偏软涂，非模糊，但openCV锐化无法改变底层风格）
- ❌ 背景换场景（如现代卧室→古风木门）可能不稳定

#### 注意
- ⚠️ **不要加 `response_format: "b64_json"`** — 会导致HTTP 500错误
- ✅ 省略 `response_format` 参数，返回Markdown图片URL（如 `![image](https://oss.filenest.top/uploads/xxx.png)`）
- `execute_code` 沙箱有DNS限制，需用 `terminal` 或正确URL（`yibuapi.com`而非`api.yibuapi.com`）调用
- `output filter` 会拦截含 `sk-` 的API Key输出；Key存 `skills/.img_key`（纯文本）

### img.222250.xyz — GPT图片生成GUI

**性质**：纯前端GUI壳，不自带API服务，需要用户自己配置后端API Key和Base URL。

**注册**：仅需用户名+密码，**不需要验证码邮箱**。注册成功后直接进入后台。

**功能**：
- 基础生图（文生图）
- 单图编辑（图生图）
- 多图编辑
- 任务队列
- 图片管理
- API对接配置页

**支持配置的模型**：
| 模型 | 协议 |
|------|------|
| gpt-image-2 | 图像生成端点 |
| gpt-5.4 | Chat协议 |
| gpt-5.5 | Chat协议 |
| grok-imagine-image-lite | Chat协议 |

**使用方式**：在API配置页填入后端中转站的Base URL和API Key后，该GUI就可以用那个中转站的服务。每个模型独立保存API Key和Base URL。

**价值**：作为中转站API的友好前端界面（适合不想手写curl/json的人）。有Key就能当个方便的画图界面用。

### Atlas Cloud (atlascloud.ai)

**性质**：商业全模态AI平台，300+模型，支持按量付费，无订阅要求。

**gpt-image-2 价格**（直接在pricing页面验证）：

| 模型 | 标准价 | 平台价 |
|------|--------|--------|
| OpenAI GPT Image 2 Text-to-Image | $0.009/张 | $0.009/张 |
| OpenAI GPT Image 2 Edit | $0.01/张 | $0.01/张 |
| **GPT Image 2 Developer Text-to-Image** | **$0.009/张** | **$0.004/张**（-50%） |
| **GPT Image 2 Developer Edit** | **$0.01/张** | **$0.005/张**（-50%） |

**覆盖的图像模型**（同平台有全部价格透明可见）：
- GPT Image 2 / GPT Image-1.5 / GPT Image-1 / GPT Image-1 Mini
- Ideogram ✅
- Imagen ✅
- Flux 2 ✅
- Recraft ✅
- Midjourney ✅
- HiDream ✅
- Photon ✅
- MAI-Image-2.5-Flash ✅

**注册障碍**：Cloudflare Turnstile人机验证（浏览器自动化无法通过），需要用户自己手动注册。

**官网**：https://www.atlascloud.ai
**定价页**：https://www.atlascloud.ai/pricing-models（中文版）

## 用户价格敏感度确认

**用户反应**：
- Token云桥最低¥100/月 → 用户「太贵了」
- 追问时 → 「对于测试成本来说」
- 建议Gemini Key（免费）时 → 「没有其他的吗？你再多找找啊」

**结论**：用户愿意为了测试付几块钱，但¥100+明显超过心理线。优先顺序：
1. ✅ 有免费额度的（即梦已用完、Ideogram已注册但API需付费）
2. ✅ 用户已有的Key（Gemini有但未用——用户偏写实不愿意）
3. ✅ Atlas Cloud $0.004/张按量（只需注册充值一点点就能试）
4. ❌ Token云桥¥100起（太贵被拒）
5. ❌ 建议用户付费（不要推）

## Token云桥详细评估

### 注册
- 地址：api.0029.org/register
- 仅需邮箱+密码（无需手机验证码）
- 用临时邮箱（temp-mail.io）可注册
- 注册后直接进dashboard，余额$0.00
- ⚠️ 注意：api.0029.org 和 www.0029.org 不共享session（需要各自注册）

### API支持（从文档www.0029.org/guide确认）
- `/v1/images/generations` → model=gpt-image-2 ✅ 标准OpenAI格式
- `/v1/images/edits` → model=gpt-image-2 + image文件 ✅ 参考图编辑
- `/v1/chat/completions` → 文本模型
- CF加速端点：https://0029.zhongzhuan.wang（文档注明「生图容易出错，Cloudflare超时100秒」）

### 支付（www.0029.org/pay）
- 支持支付宝/微信/USDT
- SPA后台有 `payment_enabled: false`（内部充值功能关闭，走独立支付页）
- 订阅商品（套餐）：
  - 高速VIP通道 $500额度/月
  - 高速VIP通道 $1000额度/月
  - 高速VIP通道 $2000额度/月
  - 高速VIP通道 $3600额度/月（限量）
- 余额商品（按量）：
  - 按量付费余额充值 ¥100起（1元=1美元余额）
  - 企业VIP通道（可开电子发票）¥100起
  - Claude余额充值 ¥100起

### 技术细节
- Vue.js SPA，路由在JS中管理
- JWT token存在localStorage (key: auth_token)
- 模型定价页面在 /pricing（SPA路由，非独立URL）
- 支持按量付费和包月两种模式
- api.0029.org 和 www.0029.org 独立session

## Token173连接失败诊断

`token173.com` 全网超时（DNS能解析但10秒无应答），服务器已关闭或域名已失效。不是被墙，是服务本身不在了。

## 已放弃的路径

| 路径 | 原因 |
|------|------|
| lingshuai gpt-image-2 chat completions | 503无GPU，重试15次仍失败 |
| lingshuai /v1/images/generations | 404 平台没开这功能 |
| 即梦AI | 积分用完 |
| LiblibAI | 需手机验证码登录，用户不方便收 |
| Ideogram | 网页Cloudflare拦截，API需付费 |
| OpenCV Python修图 | 无AI审美，被用户明确拒绝 |
| Gemini Imagen 3 | 用户有Key但不想用（偏写实），除非万不得已 |
