# Python纯算法抠图备选方案

当 rembg/onnxruntime 在Windows上因DLL问题不可用时的降级方案。

## 背景

rembg 依赖 onnxruntime，在 Windows 某些环境下即使安装了 VC++ Redist (v14.32+) 仍会报：
```
ImportError: DLL load failed while importing onnxruntime_pybind11_state: 
动态链接库(DLL)初始化例程失败。(WinError 1114)
```
transparent-background 同样因 torch DLL 问题不可用。

## 已尝试的算法及效果

| 算法 | 依赖 | Q版卡通效果 | 结论 |
|------|------|:----------:|------|
| 洪水填充（flood-fill from corners） | PIL only | ❌ 0% | 背景非纯色，完全无效 |
| 边缘检测+Sobel+morphology | scikit-image | ⚠️ 8~50% 透明 | 边缘误检严重，保留率不稳 |
| K-means聚类（scipy.cluster.vq.kmeans2） | scipy | ⚠️ 15~59% | 背景色和角色色混入同簇 |
| Random Walker分割 | scikit-image | ❌ 内存溢出 | 大图(1345×492)矩阵运算OOM |
| **颜色距离+自适应容差** ✅ | PIL+numpy+scipy | ✅ 效果可调 | **当前最佳备选** |

## 正选方案：颜色距离+自适应容差

### 原理

从图片四角采样背景色，计算每个像素到背景色的欧氏距离，小于容差的标记为背景（alpha=0），其余保留。自动调节容差确保前景保留率不低于阈值。

### 核心代码

```python
from PIL import Image
import numpy as np
from scipy import ndimage
from skimage import morphology as morph

def color_distance_remove_bg(src_path, dst_path, bg_colors, tolerance=35, min_fg_pct=10):
    """
    bg_colors: list of (R,G,B) tuples — 从四角采样
    tolerance: 颜色距离阈值，越小越保守
    min_fg_pct: 前景最低保留百分比，低于此值自动放宽容差
    """
    img = Image.open(src_path).convert("RGBA")
    arr = np.array(img).astype(float)
    h, w = arr.shape[:2]
    rgb = arr[:, :, :3]
    
    # 背景掩码
    bg_mask = np.zeros((h, w), dtype=bool)
    for bc in bg_colors:
        dist = np.sqrt(np.sum((rgb - np.array(bc))**2, axis=2))
        bg_mask |= (dist <= tolerance)
    
    fg_mask = ~bg_mask
    
    # 自适应容差：确保至少保留 min_fg_pct% 的前景
    while fg_mask.sum() / fg_mask.size * 100 < min_fg_pct and tolerance < 200:
        tolerance += 10
        bg_mask = np.zeros((h, w), dtype=bool)
        for bc in bg_colors:
            dist = np.sqrt(np.sum((rgb - np.array(bc))**2, axis=2))
            bg_mask |= (dist <= tolerance)
        fg_mask = ~bg_mask
    
    # 保留中心连通区域
    labeled, n_comp = ndimage.label(fg_mask)
    if n_comp > 1:
        center_label = labeled[h//2, w//2]
        if center_label > 0:
            fg_mask = (labeled == center_label)
    
    # 轻量形态学清理
    fg_mask = morph.binary_closing(fg_mask, morph.disk(2))
    fg_mask = ndimage.binary_fill_holes(fg_mask)
    
    result = arr.copy()
    result[:, :, 3] = (fg_mask * 255).astype(np.uint8)
    Image.fromarray(result.astype(np.uint8)).save(dst_path, "PNG")
    return fg_mask
```

### 调参经验

- **tolerance=25~35**：保守，适合背景色和角色色差异大的图
- **min_fg_pct=10~15**：防止自适应容差过度放宽
- **背景色采样**：从四角取3~5个像素的RGB，覆盖暗区和亮区
- 背景复杂（双色/渐变）时需多采几个角点颜色
- 如果某个图层几乎没抠（如手臂98%保留），说明该图层的背景色和角色色太接近，需降低tolerance或换算法

## 绿底合成验证法

**问题**：vision_analyze 看不到 PNG 的 alpha 透明通道，透明区域在视觉模型中渲染为黑色/白色。

**解决**：将抠图结果合成到亮绿色背景上发送给用户肉眼判断。

```python
bg = Image.new("RGBA", img.size, (0, 255, 0, 255))
comp = Image.alpha_composite(bg, img)
comp.save("绿底版.png", "PNG")
```

**使用时机**：每次抠图完成后，同时生成原版透明PNG（给QQ直接发送）和绿底版（用于vision_analyze验证）。

## 已知局限

- **颜色距离法**：当角色色和背景色接近时（如浅肤色 vs 米色墙壁），抠图效果差
- **中心连通法**：假设角色在图像中心——不满足此假设时需手动调整
- **无半透明支持**：当前算法只产生全透/全不透明的硬边
- **不适用写实照片**：照片级背景复杂度远超此算法的处理能力
