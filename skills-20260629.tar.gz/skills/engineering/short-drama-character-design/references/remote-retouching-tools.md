# 远程修图工具链（2026-06-24验证）

## 从PC修图的可行性诊断

### 环境概览
- 云电脑：2核4G Windows 10，无独显
- 网络：Clash Verge Rev代理 (127.0.0.1:7897)
- Hermes工具：browser（走系统代理✅）、curl（走环境变量代理✅）、Python

### 🔴 关键教训：不要断言「浏览器不走代理」

**2026-06-24 被用户纠正**：
- 我说了「浏览器不走代理，所有外部网站连不上」— ❌ 这是错的
- 实际：**浏览器走系统代理**（Clash Verge Rev配置的代理），liblib.art ✅ 可打开
- 某些站点超时的原因是：代理节点不覆盖该站点，或该站点有更深层封锁（如Cloudflare验证）
- ✅ 正确的做法：先用 `curl -s --max-time 10 <url>` 测试可达性，再用浏览器确认。**从\"浏览器不走代理\"→\"代理路线不覆盖该站点\"**

### LiblibAI登录工作流（通过浏览器）

**已验证可行**（2026-06-24）：

有两种登录方式：

#### 方式A：微信扫码登录（默认）
1. 浏览器打开 `https://www.liblib.art/login`
2. 默认显示微信QR码，标题「微信一键登录」
3. 截取QR码 → 通过 MEDIA: 路径发送给用户
4. 用户用微信扫一扫登录
5. ⚠️ **QR码有效期很短**（约1-2分钟）—— 每次发码前必须重新 navigate 到 login 页面获取新码
6. 用户扫码后页面自动跳转（无需我操作）
7. ⚠️ 如扫码后无反应、或多次过期 → 切到手机号登录

#### 方式B：手机号+验证码登录（备选）
1. 浏览器打开 `https://www.liblib.art/login`
2. 点击「其他登录方式」按钮（@e5）→ 切换到手机号登录界面
3. 标题变为「登录」+ 提示「如未注册，验证后自动登录」
4. 页面元素：
   - `@e7`：手机号输入框
   - `@e8`：验证码输入框
   - `@e12`：获取验证码按钮
   - `@e11`：登录按钮
   - `@e5`/`@e6`：返回其他登录方式
5. 填入手机号 → 点击「获取验证码」→ 用户手机收到短信
6. 用户发回验证码 → 填入 → 点击登录
7. ✅ 手机号首次使用会自动注册，无需额外注册步骤

#### 登录后
- 页面跳转到LiblibAI首页/创作页
- 可以使用「创作」→「图片生成」选短剧漫剧模型修图
- ⚠️ 浏览器工具不能处理文件上传对话框（点击上传按钮会打开系统文件选择器），依赖文件上传的操作无法通过浏览器直接完成

### 浏览器可达性（通过Clash代理）

| 站点 | 状态 | 说明 |
|------|------|------|
| liblib.art (LiblibAI) | ✅ 可到达 | **有专门的短剧漫剧分类**，需登录后使用 |
| ideogram.ai | ❌ 403 | Cloudflare人机验证拦截，代理节点IP被标记 |
| api.ideogram.ai | ✅ 可达 | 返回401/402（需API Key+付费） |
| ideogram.ai /edit, /remix | ✅ 端点存在 | 返回401（需API Key），不是404——说明功能支持 |
| api.replicate.com | ✅ 200 | 可达，需API Key |
| api.stability.ai | ✅ 307 | 可达，需API Key |
| clipdrop.co | ❌ 超时 | 被GFW深度屏蔽 |
| pixlr.com/cn | ❌ 超时 | 代理不覆盖 |
| canva.com | ❌ 超时 | 代理不覆盖 |
| tongyi.aliyun.com/wanxiang | ❌ 超时 | 代理不覆盖 |
| seaart.ai | ❌ 超时 | 代理不覆盖 |
| krea.ai | ❌ 超时 | 被GFW深度屏蔽 |
| baidu.com & 其他国内站点 | ❌ 000 | 走代理反而连不上——代理路由规则不覆盖国内站点，对国内站应走直连而非代理 |
| api.lingshuai.cc /v1/images/generations | ❌ 404 "Images API not supported" | 该端点不存在于lingshuai/Kiro平台——只有这个端点不可用 |
| api.lingshuai.cc /v1/chat/completions + model=gpt-image-2 | ✅ **当有GPU时可用** | 返回503 "No available accounts" = GPU容量满，临时。不返回这个就是正常可用。**这是gpt-image的正确通道** |

### Python修图可行性

| 方案 | 结果 | 原因 |
|------|------|------|
| Pillow + 网格扭曲瘦身 | ⚠️ 基础可用 | 能变形但效果丑，背景也会跟着变形 |
| OpenCV GrabCut + 区域缩放 | ⚠️ 基础可用 | 能抠图+单独缩放前景，但抠图精度低、边缘生硬 |
| rembg (AI抠图) | ❌ onnxruntime DLL崩溃 | import onnxruntime报DLL初始化错误。修复尝试：重命名typing.py.bak可解PIL冲突但onnxruntime本身DLL损坏 |
| rembg[cpu] 安装 | ⚠️ 能安装但运行崩溃 | onnxruntime 1.27.0 + rembg 2.0.76 安装成功但无法导入 |

**Python修图像限总结**：
- ✅ 能做：裁剪、缩放、调色、简单滤镜
- ⚠️ 能试但效果差：GrabCut抠图、网格变形瘦身
- ❌ 做不了：高质量精修（需AI模型或专业工具）

### curl走代理调API

环境变量代理追踪：`https_proxy=http://127.0.0.1:7897`（MSYS/bash中生效）

关键限制：所有API调用都需要用户提供API Key。用户没有Replicate/Stability AI的Key。

**连通性诊断方法论**：
1. 先跑 `curl -v --max-time 10 <url>` 看代理能否建立隧道（`HTTP/1.1 200 Connection established`=代理通了）
2. 再跑 `curl -s --max-time 10 <url> -o /dev/null -w "%{http_code}"` 看实际响应码
3. 响应码含义：000=连不上（DNS/路由问题），200=OK，307=重定向（通常可访问），401/403=需要认证/被拦截，404=端点不存在，421=错误端点

## CC-Switch 数据库访问（API Key 提取）

**路径**：`~/.cc-switch/cc-switch.db`

**⚠️ 进程锁**：CC-Switch 运行时数据库被独占锁定，直接 sqlite3.connect() 会报 `unable to open database file`

**✅ 正确访问模式**：
```python
import sqlite3, json, os, shutil

src = os.path.expanduser('~/.cc-switch/cc-switch.db')
dst = src.replace('.db', '-tmp.db')
shutil.copy2(src, dst)  # 复制副本再连接

db = sqlite3.connect(dst)
db.row_factory = sqlite3.Row

# 查 providers
row = db.execute("SELECT settings_config FROM providers WHERE name='CCl'").fetchone()
if row:
    sc = json.loads(row[0])
    api_key = sc.get('api_key', '')

# 查模型定价
pricing = db.execute("SELECT * FROM model_pricing").fetchall()

db.close()
os.remove(dst)  # 用完删除副本
```

**重要 providers**：
| name | app_type | base_url | 说明 |
|------|----------|----------|------|
| CCl | hermes | https://api.lingshuai.cc | 当前 Hermes 使用的代理，key=sk-b7f4b63...(67 chars) |
| Hermes | hermes | https://api.lingshuai.cc | 同CCl，另有一个thinking模型配置 |
| my001 | hermes | https://api.lingshuai.cc | 同端点，未启用 |
| codex-official | codex | https://api.deepseek.com/v1 | DeepSeek 官方API |
