# 参考视频像素分析法

用于判断短视频的制作方式（动态漫 vs 逐帧动画 vs 实拍）。

## 原理

- **动态漫/Live2D**：同一场景内，角色脸部区域帧间变化 ≈0%
- **逐帧动画**：脸部每帧都有微变化，帧间差异 5-15%
- **实拍**：每帧都有自然噪声，差异均匀分布全画面

## 步骤

### 1. 获取视频源

```javascript
// 浏览器 console
document.querySelector('video').src
// 或
document.querySelector('video').currentSrc
```

### 2. 下载

```bash
curl -L -o "video.mp4" "<视频URL>" -H "User-Agent: Mozilla/5.0"
```

### 3. 逐帧分析

```python
import cv2
import numpy as np

cap = cv2.VideoCapture('video.mp4')

# 读连续10帧
frames = []
for _ in range(10):
    ret, f = cap.read()
    if not ret: break
    frames.append(f)
cap.release()

# 逐对比较
for i in range(len(frames)-1):
    diff = cv2.absdiff(frames[i], frames[i+1])
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    
    h, w = gray.shape
    # 关键区域
    face = gray[50:200, 400:600]      # 根据画面调坐标
    body = gray[200:450, 300:700]
    bg   = gray[100:400, 900:1100]
    
    for name, region in [('face',face),('body',body),('bg',bg)]:
        pct = np.sum(region > 25) / region.size * 100
        label = 'STATIC' if pct < 1 else 'MOVING' if pct > 5 else 'SLIGHT'
        print(f'{name}: {pct:.1f}% [{label}]')
```

### 4. 判定

| 脸部变化 | 身体变化 | 结论 |
|:--:|:--:|------|
| <1% | 5-10% | **动态漫/Live2D图层动画** |
| 5-15% | 10-30% | 逐帧2D动画 |
| <1% | <1% | 纯静态图+镜头 |
| >15% 均匀 | >15% 均匀 | 镜头运动或场景切换 |

## 已验证案例

- **红果短剧《我能预知未来》**(2026-06-27)：face=0.0%, body=8.3%, bg=1-8% → 动态漫
- content_type 标记为 `motion_comic`，确认分析正确
