# 占位纯色背景生成

B计划需要纯色背景但剪映官方素材没有静态背景时，自备PNG导入。

## 方案1：纯Python（无PIL，零依赖）

```python
import struct, zlib

width, height = 1080, 1920  # 9:16竖屏
r, g, b = 90, 90, 95        # 冷灰色（办公室）
# r, g, b = 70, 60, 50      # 暗色（地下室）
# r, g, b = 240, 235, 220   # 暖黄（车内）

raw = b''
for y in range(height):
    raw += b'\x00'
    raw += bytes([r, g, b]) * width

compressed = zlib.compress(raw)

def chunk(chunk_type, data):
    c = chunk_type + data
    crc = struct.pack('>I', zlib.crc32(c) & 0xffffffff)
    return struct.pack('>I', len(data)) + c + crc

png = b'\x89PNG\r\n\x1a\n'
png += chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 2, 0, 0, 0))
png += chunk(b'IDAT', compressed)
png += chunk(b'IEND', b'')

with open('背景_冷灰.png', 'wb') as f:
    f.write(png)
```

## 方案2：PIL/Pillow（更简洁）

```python
from PIL import Image
img = Image.new('RGB', (1080, 1920), (90, 90, 95))
img.save('背景_冷灰.png')
```

## 对应场景配色

| 场景 | RGB | 色感 |
|------|-----|------|
| 办公室 | (90, 90, 95) | 冷灰 |
| 公交车内 | (240, 235, 220) | 暖黄 |
| 地下室 | (50, 45, 40) | 暗色 |
| 街道外景 | (180, 185, 190) | 中灰 |
