# 巴中市住建局材料信息价抓取

## 数据源
- **URL**: `https://zfcxjsj.cnbz.gov.cn/ztzl/bzsjzclscxxj/`
- **发布日期**：每月更新（2026年3月数据于2026-05-06发布）
- **覆盖地区**：巴中市区、平昌县、通江县、南江县
- **数据规模**：每次约334条材料价格

## 表格结构
```
序号 | 材料名称 | 规格型号 | 单位 | 是否含税 | 
平昌县 | 通江县 | 南江县 | (可能还有巴中市区)
```

## 提取方法
```python
import urllib.request, re

url = 'https://zfcxjsj.cnbz.gov.cn/ztzl/bzsjzclscxxj/23920638.html'
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
resp = urllib.request.urlopen(req, timeout=15)
html = resp.read().decode('utf-8')

rows = re.findall(r'<tr[^>]*>(.*?)</tr>', html, re.DOTALL)
for row in rows[1:]:
    cells = re.findall(r'<td[^>]*>(.*?)</td>', row, re.DOTALL)
    if len(cells) >= 8:
        texts = [re.sub(r'<[^>]+>', '', c).strip() for c in cells[:8]]
        # texts = [序号, 材料名称, 规格型号, 单位, 是否含税, 平昌县, 通江县, 南江县]
```

## 关键材料价格参考（南江县 2026-03）
| 材料 | 价格 |
|------|------|
| 热轧光圆钢筋 HPB300 Φ6～10 | ¥3,185.84/t |
| 螺纹钢 HRB400E Φ16～25 | ¥2,831.86/t |
| 普通水泥 42.5R 袋装 | ¥274.34/t |
| 中砂 | ¥108/m³ |
| 碎石 5～20mm | ¥180/m³ |
| 普通商品砼 C30 | ¥510/m³ |
| 普通商品砼 C25 | ¥495/m³ |

## URL模式
- 当期数据：`https://zfcxjsj.cnbz.gov.cn/ztzl/bzsjzclscxxj/{文章ID}.html`
- 索引页：`https://zfcxjsj.cnbz.gov.cn/ztzl/bzsjzclscxxj/`
- 劳动价格：`https://zfcxjsj.cnbz.gov.cn/ztzl/bzsjzclscxxj/23920639.html`（2026年第一季度）
